package com.mycompany.arraylista;
import com.mycompany.tienda.Transferencia;
import com.mycompany.tienda.Tarjeta;
import com.mycompany.tienda.Paypal;
import com.mycompany.tienda.Producto;
import com.mycompany.tienda.MenuInicio;
import java.util.ArrayList; // librería para el uso de los arraylist
import java.util.HashMap;
import java.util.InputMismatchException;  //libreria para utilizar el try-catch
import java.util.Map;
import java.util.Scanner; // librería para leer datos desde el teclado

public class ArrayListA { //clase
    static int opcion;    //opcion de tipo entero para el menu
    static int opcionC;
    static int persona;
     
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {    //nuestro main
          MenuInicio menuInicioVentana=new MenuInicio();
        menuInicioVentana.setVisible(true);
        
        Scanner sc = new Scanner(System.in);     
        ArrayList<Producto> productos = new ArrayList<>();   //creacion de una instancia de nuestra clase
        ArrayList<Producto> cesta = new ArrayList<>();  //cesta para los productos del comprador

        
            do{
                try{

                        switch (persona) {
                            case 1 -> {
                                do{
                                System.out.println("Introduce el numero segun la accion que se desea hacer: ");   //mensaje inicial
                                //ciclo do-while para que nos siga apareciendo el menu a menos que seleccionemos salir

                                try{  //validar entrada de datos en nuestro menu
                                    System.out.println(" 1. Agregar productos al inventario.");
                                    System.out.println(" 2. Eliminar productos por nombre.");
                                    System.out.println(" 3. Modificar productos.");
                                    System.out.println(" 4. Buscar productos por nombre.");
                                    System.out.println(" 5. Mostrar todos los productos en el inventario.");
                                    System.out.println(" 6. Salir del menu de Vendedor. ");
                                    opcion=sc.nextInt();   //lee nuestra opcion ingresada
                                    sc.nextLine();
                                }catch(InputMismatchException ex){  //cerrar try y poner la excepcion
                                    System.out.println("Solo puedes ingresar numeros, NO letras ni otro caracter "+ex);
                                    sc.next();
                                }//en caso de que se ingrese una letra-caracter aparece ese mensaje y regresa al menu
                                switch (opcion) {  //casos dependiendo de la opcion elegida
                                    case 1 -> {   //caso 1 agregar productos al inventario
                                        String nombre;
                                        double precio;
                                        int cantidad;    //declaramos nuestras variables
                                        while (true) {   //validamos nombre, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {   //validar entrada de datos
                                                System.out.print("Ingrese el nombre del producto: ");
                                                nombre = sc.nextLine();
                                                if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) {   //valida que el nombre solo tenga letras
                                                    throw new IllegalArgumentException("El nombre solo puede tener letras!! ");
                                                }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                break; // Sale del ciclo si el nombre es valido
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage());   //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }

                                        while (true) {  //validamos precio, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {    //validar entrada de datos
                                                System.out.print("Ingrese el precio del producto: ");
                                                String precioStr = sc.nextLine();   //almacenamos el valor de precio en tipo string antes de convertirlo a double
                                                if (!precioStr.matches("\\d+(\\.\\d+)?")) {  // Validar que el precio sea un numero valido
                                                    throw new IllegalArgumentException("El precio solo puede tener numeros.");
                                                }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                precio = Double.parseDouble(precioStr);   //metodo estatico que convierte cadena de texto a tipo double(numerico)
                                                break; // Sale del ciclo si el precio es valido
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage());//sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }

                                        while (true) { //validamos cantidad, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {  //validar entrada de datos
                                                System.out.print("Ingrese la cantidad del producto: ");
                                                String cantidadStr = sc.nextLine(); //almacenamos el valor de precio en tipo string antes de convertirlo a double
                                                if (!cantidadStr.matches("\\d+")) { // Validamos que la cantidad sea un numero entero válido
                                                    throw new IllegalArgumentException("La cantidad solo puede tener numeros enteros.");
                                                } //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                cantidad = Integer.parseInt(cantidadStr);
                                                break; // Sale del ciclo si la cantidad es válida
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage()); //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }
                                        // se agrega el nuevo producto a la lista
                                        productos.add(new Producto(nombre, precio, cantidad));
                                        System.out.println("Producto agregado exitosamente.");
                                        System.out.println(); // Imprime espacio
                                    }

                                    case 2 -> { // eliminar productos por nombre
                                        String eliminar;
                                        while (true) { //validamos eliminar, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try { //validar entrada de datos
                                                System.out.print("Ingrese el nombre del producto que quieres eliminar: ");
                                                eliminar = sc.nextLine();
                                                if (!eliminar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { // Valida que el nombre solo contenga letras
                                                    throw new IllegalArgumentException("Error!! El nombre solo puede tener letras."); //excepción si el nombre no es válido
                                                }
                                                break; //si no lanza excepcion, el nombre es valido, el bucle se acaba
                                            } catch (IllegalArgumentException e) {
                                                System.out.println(e.getMessage()); //Se muestra el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar el producto

                                        for (int i = 0; i < productos.size(); i++) { //busca el producto
                                            if (productos.get(i).getNombre().equalsIgnoreCase(eliminar)) {
                                                Producto productoEliminado = productos.remove(i); //elimina el producto
                                                System.out.println("Producto eliminado " + productoEliminado);
                                                encontrado = true; //producto encontrado
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }

                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto para eliminar."); //mensaje de error
                                        }

                                        System.out.println(); //imprime espacio
                                    }

                                    case 3 -> { //modificar productos
                                        String nuevoNombre = ""; //declaracion de variables
                                        double nuevoPrecio = 0;
                                        String modificar = "";
                                        int nuevaCantidad = 0;

                                        while (true){ //bucle para que el usuario escriba el nombre del producto hasta que ingrese tipo de dato correcto
                                            try {
                                                System.out.print("Ingrese el nombre del producto a modificar: ");
                                                modificar = sc.nextLine(); //reasignamos valor con lo que ingrese el usuario
                                                if (modificar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch con mensaje de error
                                                }
                                            } catch (InputMismatchException error) { //sino cacha el error
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) { //busca el producto por su nombre
                                            if (productos.get(i).getNombre().equalsIgnoreCase(modificar)) {
                                                Producto productoModificar = productos.get(i);

                                                while (true) { //bucle para que el usuario ingrese datos validos
                                                    try {
                                                        System.out.print("Ingrese el nuevo nombre: "); //modifica el nombre
                                                        nuevoNombre = sc.nextLine(); //asigna nuevoNombre a lo que ingrese el usuario
                                                        if (nuevoNombre.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                            break; //sale del bucle whie
                                                        } else {
                                                            throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                        }
                                                    } catch(InputMismatchException error){ //sino cacha el error e imprime mensaje
                                                        System.out.println(error.getMessage()); //imprime el dato de error
                                                    }
                                                }

                                                while (!encontrado) { //definimos encontrado como false anteriormente. Este ciclo hace que se repita hasta que el usuario ingrese dato correcto
                                                    try { //try catch para validar dato double
                                                        System.out.print("Ingrese el nuevo precio: "); //modifica el precio
                                                        nuevoPrecio = sc.nextDouble();
                                                        encontrado = true; //si ingresa un dato correcto encontrado se establece en true, sale del bucle while y se deja de repetir
                                                    } catch(InputMismatchException err) { //para detectar error de dato
                                                        System.out.println("Dato incorrecto. Ingresa numeros unicamente");
                                                        sc.next(); //limpia el buffer
                                                    }
                                                }

                                                encontrado = false;
                                                while (!encontrado){ //bucle while se ejecuta mientras !encontrado, true
                                                    try { //try catch para validar dato double
                                                        System.out.print("Ingrese la nueva cantidad: "); //modifica la cantidad
                                                        nuevaCantidad = sc.nextInt();
                                                        encontrado = true; //si ingresa un dato correcto sale del bucle while y se deja de repetir
                                                    } catch(InputMismatchException err) {
                                                        System.out.println("Dato incorrecto. Ingresa numeros unicamente");
                                                        sc.next(); //limpia el buffer
                                                    }
                                                }

                                                //actualiza el producto
                                                productoModificar.setNombre(nuevoNombre);
                                                productoModificar.setPrecio(nuevoPrecio);
                                                productoModificar.setCantidad(nuevaCantidad);
                                                System.out.println("Producto modificado: " + productoModificar);
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto a modificar."); //mensaje de error
                                        }
                                        System.out.println();//imprime espacio
                                    }

                                    case 4 -> { //buscar productos por nombre
                                        String buscar = ""; //declaracion de variable
                                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                                            try { //try catch para validar datos e imprimir mensaje de error
                                                System.out.print("Ingrese el nombre del producto a buscar: ");
                                                buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                                                if (buscar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                }
                                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) {
                                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto deseado.");
                                        }
                                        System.out.println();//imprime espacio
                                    }
                                    case 5 ->  { //mostrar todos los productos en el inventario
                                        if(productos.isEmpty())
                                                System.out.println("Aun no hay ningun producto, intente mas tarde");
                                        else{
                                        System.out.println("El numero de productos agregados es: " + productos.size());
                                        for (int i = 0; i < productos.size(); i++) {
                                            System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                                        }
                                        }
                                        System.out.println();//imprime espacio
                                        break;
                                    }


                                    case 6 -> {
                                    System.out.println("Esto ha sido todo en el menu del vendedor:)");
                                    }

                                    default -> System.out.println("Opcion no valida, por favor intente de nuevo.");

                                }
                            }while(opcion!=6);

                            }
                            case 2-> {
                                 do{//ciclo do-while para que nos siga apareciendo el menu a menos que seleccionemos salir
                                System.out.println("Introduce el numero segun la accion que se desea hacer: ");   //mensaje inicial 

                                    try{  //validar entrada de datos en nuestro menu
                                        System.out.println("1. Buscar productos por nombre.");
                                        System.out.println("2. Mostrar todos los productos en el inventario.");
                                        System.out.println("3. Agregar producto a la cesta.");
                                        System.out.println("4. Mostrar carrito de compras");
                                        System.out.println("5. Pagar.");
                                        System.out.println("6. Salir del menu del Comprador.");
                                        opcionC=sc.nextInt();  //lee nuestra opcion ingresada
                                        sc.nextLine();
                                    }catch(InputMismatchException ex){  //cerrar try y poner la excepcion
                                        System.out.println("Solo puedes ingresar numeros, NO letras ni otro caracter "+ex);
                                        sc.next();    //en caso de que se ingrese una letra-caracter aparece ese mensaje y regresa al menu
                                    }
                                switch (opcionC) {
                                    case 1 -> { //buscar productos por nombre
                                        String buscar = ""; //declaracion de variable
                                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                                            try { //try catch para validar datos e imprimir mensaje de error
                                                System.out.print("Ingrese el nombre del producto a buscar: ");
                                                buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                                                if (buscar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                }
                                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) {
                                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto deseado.");
                                        }
                                        System.out.println();//imprime espacio
                                    }

                                    case 2 -> { //mostrar todos los productos en el inventario
                                    if(productos.isEmpty()){
                                                System.out.println("Aun no hay ningun producto, intente mas tarde");
                                    }else{
                                        System.out.println("El numero de productos agregados es: " + productos.size());
                                            for (int i = 0; i < productos.size(); i++) {
                                                System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                                            }
                                        }
                                        System.out.println();//imprime espacio
                                    }

                                    case 3->{
                                        System.out.print("Ingrese el nombre del producto que desea agregar a la cesta: ");
                                        String nombreProducto = sc.nextLine();
                                        boolean encontrado = false;
                                        for (Producto p : productos) {
                                            if (p.getNombre().equalsIgnoreCase(nombreProducto)) {
                                                cesta.add(p);
                                                System.out.println("Producto agregado a la cesta.");
                                                encontrado = true;
                                                break;
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("Producto no encontrado.");
                                        }
                                    }

                                    case 4->{ //mostrar carrito de compras
                                    if(cesta.isEmpty()){ //si eseta vacia indica
                                            System.out.println("Cesta vacia, comience a agregar productos!!");
                                        }else{
                                            double total = 0;
                                            System.out.println("Resumen de la compra: ");
                                            Map<Producto, Integer> cantidadesSelec = new HashMap<>();
                                            for(Producto p : cesta){ //recorre el arraylist 
                                                System.out.println("Ingresa las piezas que quieres de cada producto. " +p.getNombre()+ ": ");
                                                int cantidadSelec = sc.nextInt();
                                                sc.nextLine();  //limpiar buffer
                                                cantidadesSelec.put(p, cantidadSelec);
                                            }
                                            for(Producto p : cesta){ //recorre el arraylist
                                                int cantidad = cantidadesSelec.get(p);
                                                double subtotal = p.getPrecio() * cantidad;
                                                total += subtotal;
                                                System.out.println(p.toString() + "\nPiezas seleccionadas: " +cantidad + "\nSubtotal: $" +subtotal);
                                            }
                                            System.out.println("Monto total a pagar: $" + total);
                                        }    
                                    } //
                                            
                                            
                                    case 5->{
                                        if(cesta.isEmpty()){
                                            System.out.println("Cesta vacia, comience a agregar productos!!");
                                        }else{
                                            double total = 0;
                                            System.out.println("Resumen de la compra: ");
                                            Map<Producto, Integer> cantidadesSelec = new HashMap<>();
                                            for (Producto p : cesta) {
                                                int cantidadSelec;
                                                while (true) { // bucle para asegurar una cantidad válida
                                                    System.out.println("Ingresa las piezas que quieres de " + p.getNombre() + ": ");
                                                    cantidadSelec = sc.nextInt();
                                                    sc.nextLine(); // limpiar buffer
                                                    if (cantidadSelec <= Integer.parseInt(p.getcantidadStr())) {
                                                        cantidadesSelec.put(p, cantidadSelec);
                                                        break; // salir del bucle al obtener una cantidad válida
                                                    } else {
                                                        System.out.println("No puede agregar mas productos de los que tenemos en existencia. Intente nuevamente.");
                                                    }
                                                }
                                            }

                                            for(Producto p : cesta){
                                                int cantidad = cantidadesSelec.get(p);
                                                double subtotal = p.getPrecio() * cantidad;
                                                total += subtotal;
                                                
                                                p.reducirCantidad(cantidad); //restar la cantidad comprada del inventario
                                                
                                                System.out.println(p.toString() + "\nPiezas seleccionadas: " +cantidad + "\nSubtotal: $" +subtotal);

                                            }

                                            System.out.println("Monto total a pagar: $" + total);

                                            boolean opcValido = false;
                                            while(!opcValido){
                                                System.out.println("Seleccione el metodo de pago:");
                                                System.out.println("1. Tarjeta");
                                                System.out.println("2. Transferencia");
                                                System.out.println("3. Paypal");
                                                System.out.println("4. Ya pague!! Regresar al menu de comprador");
                                                int pagop = sc.nextInt();
                                                sc.nextLine();
                                                switch (pagop){    
                                                    case 1 -> { //pago con tarjeta
                                                        Tarjeta tarjeta = new Tarjeta("Nombre", 0, "Fecha", 0, "Correo", 0.0); //instanciar con sus atributos vacios
                                                        tarjeta.pedirDatos(); //pide datos al usuario
                                                        tarjeta.realizarPago(); //confirmacion del pago
                                                        break;
                                                    }

                                                    case 2 -> { //pago con transferencia
                                                        Transferencia transferencia = new Transferencia("Nombre", 0, "Fecha", 0, "Correo", 0.0); //instanciar con sus atributos vacios
                                                        transferencia.pedirDatos();
                                                        transferencia.realizarPago();
                                                        break;
                                                    }    
                                                    case 3 -> { //pago con PayPal
                                                        Paypal paypal = new Paypal("Correo", 0.0); //instanciar con sus atributos vacios
                                                        paypal.pedirDatos();
                                                        paypal.realizarPago();
                                                        break;
                                                        }
                                                    case 4 ->{
                                                        opcValido = true;
                                                        System.out.println("Gracias por su pago! Regresando al menu de comprador:)");
                                                    }
                                                    default -> System.out.println("Metodo de pago no valido, selecciona una opcion del menu");

                                                }
                                            }
                                            cesta.clear();
                                        }  
                                    }
                                    case 6 ->{ //salir
                                        System.out.println("Esto ha sido todo del menu del comprador");
                                    }
                                    default -> System.out.println("Opcion no valida, por favor intente de nuevo.");
                                }
                                }while(opcionC !=6);
                            }

                            case 3->{
                                System.out.println("Nos vemos, vuelve pronto!! espero te haya gustado");
                                System.exit(0); // Finaliza el programa completamente
                            }

                            default -> System.out.println("Opcion no valida, ingrese de nuevo");    

                        }
                }catch (InputMismatchException e) {
                    System.out.println("Solo puedes ingresar numeros, intenta nuevamente.");
                    sc.nextLine(); // limpiar el buffer para evitar bucle infinito en caso de error
                }
            }while(persona!=3);
}

}