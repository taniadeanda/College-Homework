package com.mycompany.diarioimagenes; //package com.mycompany.diarioimagenes;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Diseno extends javax.swing.JFrame {
    Nodo actual = null, inicio = null, fin = null;     //Crear los punteros
    String temporalrutaimagen;    // Manejo de las rutas para cargar imagene

    public Diseno() {
        initComponents();
    }

    boolean listaVacia(){     //Revisa si la lista esya vacio 
       return inicio==null;        //Forma corta de checar si esta vacia
    }
    
      void cargarImagen(){
        try{// Buscar imagenes
        JFileChooser exploradorImagen = new JFileChooser();
        exploradorImagen.addChoosableFileFilter(new FileNameExtensionFilter("imagen","jpg","png"));
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile();
        temporalrutaimagen =auxFile.getAbsolutePath();
        JFoto.setIcon(new javax.swing.ImageIcon(temporalrutaimagen));
        setImagenLabel(JFoto, temporalrutaimagen);
        }catch(NullPointerException e){
        JOptionPane.showMessageDialog(null,"Error al cargar el archivo de imagen");
        }
    }
    
    private void setImagenLabel(JLabel label, String imagePath){ // Crear un ImageIcon a partir de la ruta de la imagen
        ImageIcon imagen = new ImageIcon(imagePath);
        // Redimensionar la imagen para que se ajuste al tamaño del JLabel
        ImageIcon icono = new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH));
         // Establecer la imagen redimensionada en el JLabel
        label.setIcon(icono);
        // Repintar el JLabel para asegurarse de que la imagen se actualice
        label.repaint();
    }
    
    void InsertarInicio(){ //VALIDAR que el usuario haya llenado todos los campos de texto para que pueda insertar
    Nodo nuevo = new Nodo(temporalrutaimagen, Fecha.getText(), Fecha.getText(),Descripcion.getText(), Emoji.getText(), null, null); //String rutaarchivo, String nombre, String fecha, String descripcion, String emoji, Nodo anterior, Nodo siguiente 
    if(listaVacia()){
         JOptionPane.showMessageDialog(null, "Primer Nodo Creado con Exito", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo;
         fin = nuevo;
     }else{ //Conecetar los enlaces al nuevo nodo 
         nuevo.setSiguiente(inicio);
         inicio.setAnterior(nuevo);
         JOptionPane.showMessageDialog(null, "Nuevo Nodo Insertado por el Inicio Exitosamente", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo; //Recorre el inico al nuevo nodo
       } 
    }
    
    /*void Mostrar() { //no se USA porque tenemos actualizarVisor();
    if (listaVacia() || inicio == null) {  // Validar si la lista está vacía
        JOptionPane.showMessageDialog(null, "No hay elementos en la lista", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;  // Salir de la función si no hay elementos
    }
    Nodo chalan = inicio;
    int contador = 1;
    do {
        System.out.println("Posicion " + contador + ": " + chalan.getInterprete()); // Revisa el nombre correcto del método
        InterpreteVisual.setText( chalan.getInterprete());
        chalan = chalan.getSiguiente();
        contador++;
    } while (chalan != null && chalan != inicio);  // Validar `null` en listas no circulares
    }*/
    
    void actualizarVisor(){ 
        // Actualizar los campos de texto con los valores del nodo actual
        Fecha.setText(actual.nombre);
        //jMelodia.setText(actual.nombreMelodia);
        if (listaVacia()) {
        // Si la lista está vacía, mostrar un mensaje en el JLabel
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        } else {
            AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al tamaño del JLabel
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnArchivo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnInsertarInicio = new javax.swing.JButton();
        btnRetrocederTodo = new javax.swing.JButton();
        JFoto = new javax.swing.JLabel();
        btnRetroceder = new javax.swing.JButton();
        btnAvanzar = new javax.swing.JButton();
        btnAvanzarTodo = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Jlabel = new javax.swing.JLabel();
        NombreVisual = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Emoji = new javax.swing.JLabel();
        Descripcion = new javax.swing.JTextField();
        Fecha = new javax.swing.JTextField();
        cmtNombre2 = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        btnArchivo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnArchivo.setText("Buscar Archivo");
        btnArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchivoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel1.setText("Imagen");

        btnInsertarInicio.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnInsertarInicio.setText("Insertar");
        btnInsertarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarInicioActionPerformed(evt);
            }
        });

        btnRetrocederTodo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnRetrocederTodo.setText("|<");
        btnRetrocederTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederTodoActionPerformed(evt);
            }
        });

        JFoto.setBackground(new java.awt.Color(51, 255, 255));
        JFoto.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        JFoto.setText("FOTO");
        JFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnRetroceder.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnRetroceder.setText("<<");
        btnRetroceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederActionPerformed(evt);
            }
        });

        btnAvanzar.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnAvanzar.setText(">>");
        btnAvanzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarActionPerformed(evt);
            }
        });

        btnAvanzarTodo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnAvanzarTodo.setText(">|");
        btnAvanzarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarTodoActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 24)); // NOI18N
        jLabel4.setText("DIARIO DE IMÁGENES");

        Jlabel.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Jlabel.setText("Nombre:");
        Jlabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        NombreVisual.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        NombreVisual.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel7.setText("Descripción");

        jLabel8.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel8.setText("Fecha");

        Emoji.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Emoji.setText("Emoji");

        Descripcion.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescripcionActionPerformed(evt);
            }
        });

        Fecha.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaActionPerformed(evt);
            }
        });

        cmtNombre2.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        cmtNombre2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmtNombre2ActionPerformed(evt);
            }
        });

        Nombre.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Emoji, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmtNombre2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnInsertarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(66, 66, 66)
                                .addComponent(btnArchivo))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addGap(66, 66, 66)
                                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JFoto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnRetrocederTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRetroceder)
                        .addGap(70, 70, 70)
                        .addComponent(btnAvanzar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAvanzarTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Jlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(NombreVisual, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(33, 52, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRetrocederTodo)
                            .addComponent(btnRetroceder)
                            .addComponent(btnAvanzar)
                            .addComponent(btnAvanzarTodo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NombreVisual, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Jlabel, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(22, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(Fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Emoji)
                            .addComponent(cmtNombre2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnArchivo)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addComponent(btnInsertarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivoActionPerformed
       cargarImagen();
    }//GEN-LAST:event_btnArchivoActionPerformed

    private void btnRetrocederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederActionPerformed
    if (actual == null) {
        System.out.println("Error: 'actual' es null, no se puede retroceder.");
        return;
    }
    if (actual.getAnterior() != null) {
        actual = actual.getAnterior(); // Retrocedemos
    } else {
        actual = fin; // Si estamos en el inicio, saltamos al final (lista circular)
    }
    actualizarVisor();
    NombreVisual.setText(actual.getNombre());
    System.out.println("Nombre: " + actual.getNombre());
    }//GEN-LAST:event_btnRetrocederActionPerformed

    private void btnInsertarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarInicioActionPerformed
        InsertarInicio();         //Llamamos la funcion de insettar por el inicio
    }//GEN-LAST:event_btnInsertarInicioActionPerformed

    private void btnRetrocederTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederTodoActionPerformed
    if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
    }
    if (inicio != null) {
        actual = inicio; // Nos aseguramos de que 'actual' empiece desde el inicio
        Fecha.setText(actual.nombre);
        JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
        NombreVisual.setText(actual.getNombre());
        actualizarVisor(); //para que lo muestre
    } else {
        System.out.println("Error: 'inicio' es null.");
    }
    }//GEN-LAST:event_btnRetrocederTodoActionPerformed

    private void btnAvanzarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarTodoActionPerformed
        if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
        }
        if (fin != null) {
            actual = fin; // Nos aseguramos de que 'actual' empiece desde el final
            Fecha.setText(actual.nombre);
            JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
            NombreVisual.setText( actual.getNombre());
            actualizarVisor(); //para que la imagen tmbn se actualice
        } else {
            System.out.println("Error: 'fin' es null.");
        }
    }//GEN-LAST:event_btnAvanzarTodoActionPerformed

    private void btnAvanzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarActionPerformed
    if (listaVacia()) {
        System.out.println("Error: La lista está vacía, no se puede avanzar.");
        return;
    }
    if (actual == null) {
        actual = inicio;  // Si 'actual' es null, lo inicializamos en 'inicio'
    } else {
        actual = actual.getSiguiente();  // Avanzamos al siguiente nodo
        if (actual == null) {  
            actual = inicio;  // Si llegamos al final, volvemos al inicio (lista circular)
        }
    }
    actualizarVisor();
    NombreVisual.setText(actual.getNombre());
    System.out.println("Nombre: " + actual.getNombre());
    }//GEN-LAST:event_btnAvanzarActionPerformed

    private void DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescripcionActionPerformed

    private void FechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaActionPerformed

    private void cmtNombre2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmtNombre2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmtNombre2ActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseno().setVisible(true);
            }
        });
    }
     // Método para ajustar el tamaño de la imagen
    
void AjustarImagen(JLabel lbl, String ruta) {
    // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(ruta);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    lbl.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    lbl.repaint();
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Descripcion;
    private javax.swing.JLabel Emoji;
    private javax.swing.JTextField Fecha;
    private javax.swing.JLabel JFoto;
    private javax.swing.JLabel Jlabel;
    private javax.swing.JTextField Nombre;
    private javax.swing.JLabel NombreVisual;
    private javax.swing.JButton btnArchivo;
    private javax.swing.JButton btnAvanzar;
    private javax.swing.JButton btnAvanzarTodo;
    private javax.swing.JButton btnInsertarInicio;
    private javax.swing.JButton btnRetroceder;
    private javax.swing.JButton btnRetrocederTodo;
    private javax.swing.JTextField cmtNombre2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
