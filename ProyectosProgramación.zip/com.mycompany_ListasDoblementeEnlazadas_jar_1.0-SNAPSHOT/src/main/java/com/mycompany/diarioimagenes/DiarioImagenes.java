package com.mycompany.diarioimagenes; //package com.mycompany.diarioimagenes;
public class DiarioImagenes {

    public static void main(String[] args) {
         new Diseno().setVisible(true);
    }
}
