package com.mycompany.juegoxo;

public class JuegoXO { //formulario

    public static void main(String[] args) {
    new Formulario().setVisible(true);
    }
}
