package com.mycompany.practica5;

public class Automovil {
            
    public Automovil(String marca, int puertas, String modelo) {
        this.marca = marca;
        this.puertas = puertas;
        this.modelo = modelo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public int getPuertas() {
        return puertas;
    }

    public String getModelo() {
        return modelo;
    }
protected String marca; 
protected int puertas; 
protected String modelo;

public void mostrarDatos(){
    System.out.println("Mostrando datos del transporte"+" Modelo "+this.modelo+ "N puertas" + this.puertas+"Marca "+this.marca);
    }
}
