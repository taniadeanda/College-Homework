package com.mycompany.practica5;
public class Carro extends Automovil { //creacion clase hijo, nombre extends nombre padre sintaxis
    int velocidades;
    String color;

    public void setVelocidades(int velocidades) {
        this.velocidades = velocidades;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getVelocidades() {
        return velocidades;
    }

    public String getColor() {
        return color;
    }

    //constructor
    public Carro(String modelo, int puertas, String marca, int velocidades, String color) {
        //se agregan otros parametros modificando a la clase padre
    super(modelo, puertas, marca); //manda a llamar metodos originales de clase padre
    this.velocidades = velocidades;
    this.color = color;
    }
    
    void mostrarCarro(){
        System.out.println("Velocidades"+ velocidades+"Color"+color);
    }
    
}
