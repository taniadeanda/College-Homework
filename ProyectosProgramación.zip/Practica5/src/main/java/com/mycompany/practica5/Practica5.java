
//HERENCIA: Característica de la programación orientada a objetos. Permite que una clase (hijo) herede atributos y metodos de otra clase (clase padre) ayudando a reutilizar código.
//Al crear la clase se pone la palabra extends y el nombre de la clase padre. Sintexis class<NmbreClaseHijo>

package com.mycompany.practica5;
import java.util.Scanner;
public class Practica5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Carro ferrari = new Carro("Ferrari", 4, "Ferrari", 5," Rojo vibrante");
        ferrari.mostrarCarro();
        ferrari.mostrarDatos();
    }
}
