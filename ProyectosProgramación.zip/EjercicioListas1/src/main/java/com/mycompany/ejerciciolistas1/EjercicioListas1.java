package com.mycompany.ejerciciolistas1;
public class EjercicioListas1 { //clase principal
    //instanciar clase nodo
    static Nodo nuevo, cabeza; //
    //en C para punteros se usa *puntero
    //puntero es como "siguiente", la direccion de memoria siguiente que apunta
    
    static boolean listaVacia(){
        return cabeza == null; //es lo mismo que...
        /*if (cabeza==null)
            return true;
        else 
            return false;*/
    }
    /*
    static boolean listaLlena() {
        return cabeza != null;
    }
    
    static void insertarInicio(){   
    }    
    
    static void insertarCualquierParte(){
    }*/
    
    static void insertarFinal(int n){ //algoritmo LiFo, con parametros de numero
        nuevo = new Nodo(n, null); //instanciacion de objeto nuevo en el constructor nuevo con n (nodo) y direccion de memoria null
        if(listaVacia()) {
            cabeza = nuevo; //el inicio se recorre al siguiente nodo vacio
            } else {
                Nodo chalan = cabeza; //auxiliar o comodin
                while(chalan.getPuntero() != null) {//recorre la lista. puntero es el "siguiente"
                chalan = chalan.getPuntero(); //toma el valor que esta en puntero y avanza para recorrer la lista
               
                }
                chalan.setPuntero(nuevo); //apunta la memoria del puntero de chalan al nuevo (nodo)
                //chalan.puntero = nuevo;
                System.out.println("Nodo insertado exitosamente");
        }
    }
    
    static void mostrar(){
        if(listaVacia()){
            System.out.println("Tu lista esta vacía. No hay nada para imprimir. Agrega elementos");
        } else {
        Nodo chalan = cabeza;
        int i = 1;
        while(chalan!=null){ //mientras tenga elementos
            System.out.println("numero:"+i+" dato:"+chalan.getValor()+"dirección de memoria: "+chalan.getPuntero()); //imprimelo de chalan valor y su direccion de memoria
            i++; //aumentar contador
            chalan = chalan.getPuntero();
        }
        }
    }
    
    static void eliminar(){ //eliminar PRIMERO elemento cabeza
        if(listaVacia()) {
           System.out.println("Tu lista esta vacía. No hay nada para eliminar. Agrega elementos");
        } else { //no tiene tamaño porque es dinámica
            System.out.println("Nodo eliminado "+cabeza.getValor()); //el nodo que se borra (el numero que quieres borrar o el dato)
            cabeza=cabeza.getPuntero(); //guarda la direccion de memoria que tiene cabeza para después mover su direccion de memoria a otro y que se recorra
        }
    }
    
    /*static void eliminarUltimo(){
        Nodo chalan = cabeza; //auxiliar o comodin que guarda la direccion de memoria
        if(listaVacia()) {
           System.out.println("Tu lista esta vacía. No hay nada en el ultimo elemento para eliminar. Agrega elementos");
        } //no tiene tamaño porque es dinámica   
        else if (chalan.getPuntero()== null){ //si la direccion de memoria de chalan esta vacia se sale
                    break;
                } else { //si no eliminalo
                    //chalan.puntero
                    chalan.siguiente = null; //para eliminarlo asignale la direccion de memoria null
                    System.out.println("Último nodo eliminado "+cabeza.getValor()); //get valor da los DATOS del nodo, como el número
                    //mostrar que se haya eliminado??
                    System.out.println("Tu nueva lista con el ultimo nodo eliminado es ");
                    mostrar();
                }   
            }
        } //el chalan debe de estar antes del fin
    }*/
    static void eliminarUltimo() {
    if (listaVacia()) {
        System.out.println("Tu lista está vacía. No hay nada en el último elemento para eliminar. Agrega elementos");
    } else if (cabeza.getPuntero() == null) { // Si solo hay un elemento
        System.out.println("El único nodo " + cabeza.getValor() + " ha sido eliminado");
        cabeza = null; // La lista se vacía
    } else {
        Nodo chalan = cabeza;
        while (chalan.getPuntero().getPuntero() != null) { // Encuentra el penúltimo nodo
            chalan = chalan.getPuntero();
        }
        System.out.println("Último nodo " + chalan.getPuntero().getValor() + " eliminado");
        chalan.setPuntero(null); // Elimina el último nodo
        /*System.out.println("Tu nueva lista con el último nodo eliminado es:");
        mostrar();*/
    }
}
    
    static void buscar(int n){ //imprimir en que posicion esta y asignar parametros del numero que va a buscar
        Nodo chalan = cabeza; //auxiliar o comodin que guarda la direccion de memoria
        int posicion = 1;
        //WHILE???
        if(listaVacia()) {
           System.out.println("Tu lista esta vacía. No hay nada para buscar. Agrega elementos");
        } else { //no tiene tamaño porque es dinámica    
            //COMO LO RECORRERÍA???
            //chalan = chalan.getPuntero(); //get siguiente. le asigna la direccion de memoria(puntero) a chalan
            while(chalan!=null){//}
            //chalan.getValor() = n;
            if(chalan.getValor() == n){ //si ese nodo es igual a 89 escribir el numero de posicion
                System.out.println("Tu nodo "+chalan.getValor()+" esta en la posicion "+posicion); //imprime en que posición esta el nodo que se quiere mostrar
                return; //porque cualquier funcion con parametros tiene que retornar algo
            } else { //pase al siguiente nodo y aumente la posicion
                posicion++;
                chalan = chalan.getPuntero();  //que avance???
            }    
        }
            System.out.println("El valor no se encontro en la lista o no existe");
        }
    }
    
    public static void main(String[] args) {
        insertarFinal(88); //manda a llamar los metodos y los muestra
        insertarFinal(89);
        insertarFinal(23);
        insertarFinal(14);
        insertarFinal(45);
        mostrar();
        eliminarUltimo(); //elimina los 2 últimos elementos
        eliminarUltimo();
        mostrar();
        buscar(89); //y mostrar su posicion donde esta
    }
}
