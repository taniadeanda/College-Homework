package com.mycompany.ejerciciolistas1;
//clase, aqui van las funciones
public class Nodo {
    int valor;
    Nodo siguiente; //puntero se va a guardar en memoria de la misma clase nodo
    //puntero es como "siguiente", la direccion de memoria siguiente que apunta


    //contructor
    public Nodo(int valor, Nodo puntero) {
        this.valor = valor;
        this.siguiente = puntero;
    }

    //getters y setters para acceder a los atributos (variables)
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public Nodo getPuntero() { //o get siguiente
        return siguiente;
    } 

    public void setPuntero(Nodo puntero) {
        this.siguiente = puntero;
    }
    
}
