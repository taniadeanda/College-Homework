
package com.mycompany.arraylistpp;
import java.util.ArrayList; // librería para el uso de los arraylist
import java.util.InputMismatchException;
import java.util.Scanner; // librería para leer datos desde el teclado
public class ArraylistPP {
    static int opcion;
     
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Producto> productos = new ArrayList<>();

        System.out.println("Hola, hola bienvenid@ al programa de inventario de producto para comenzar"
                + "introduce el numero segun la accion que se desea hacer: ");
        do{
            System.out.println("1. Agregar productos al inventario.");
            System.out.println("2. Eliminar productos por nombre.");
            System.out.println("3. Modificar productos.");
            System.out.println("4. Buscar productos por nombre.");
            System.out.println("5. Mostrar todos los productos en el inventario.");
            System.out.println("6. Salir del programa.");
             opcion=sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                    case 1 -> { //agregar productos al inventario 
                        System.out.print("Ingrese el nombre del producto: ");
                        String nombre = sc.nextLine();
                        System.out.print("Ingrese el precio del producto: ");
                        double precio = sc.nextDouble();
                        System.out.print("Ingrese la cantidad del producto: ");
                        int cantidad = sc.nextInt();
                        productos.add(new Producto(nombre, precio, cantidad)); //agrega el nuevo producto a la lista
                        System.out.println();//imprime espacio
                      }
                    
                    case 2 -> { //eliminar productos por nombre 
                        System.out.print("Ingrese el nombre del producto a eliminar: ");
                        String eliminar = sc.nextLine();
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) { //busca el producto
                            if (productos.get(i).getNombre().equalsIgnoreCase(eliminar)) {
                                Producto productoEliminado = productos.remove(i); //elimina el producto
                                System.out.println("Producto eliminado: " + productoEliminado);
                                encontrado = true; //producto encontrado
                                break; //sale del bucle si encuentra el producto/
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto para eliminar."); //mensaje de error
                        }
                        System.out.println(); //imprime espacio
                      }
                    
                      case 3 -> { //modificar productos
                            String nuevoNombre = ""; //declaracion de variables
                            double nuevoPrecio = 0;
                            String modificar = "";
                            int nuevaCantidad = 0;
                            
                            while (true){ //bucle para que el usuario escriba el nombre del producto hasta que ingrese tipo de dato correcto
                                try {
                                    System.out.print("Ingrese el nombre del producto a modificar: ");
                                    modificar = sc.nextLine(); //reasignamos valor con lo que ingrese el usuario
                                    if (modificar.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                        break; //sale del bucle whie
                                    } else {   
                                        throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch con mensaje de error
                                     }
                                } catch (InputMismatchException error) { //sino cacha el error
                                    System.out.println(error.getMessage()); //imprime el mensaje de error
                                }
                            }
                            boolean encontrado = false; //bandera para encontrar producto
                            for (int i = 0; i < productos.size(); i++) { //busca el producto por su nombre
                                if (productos.get(i).getNombre().equalsIgnoreCase(modificar)) {
                                Producto productoModificar = productos.get(i); 
                                    
                          
                            while (true) { //bucle para que el usuario ingrese datos validos
                                try {
                                    System.out.print("Ingrese el nuevo nombre: "); //modifica el nombre
                                    nuevoNombre = sc.nextLine(); //asigna nuevoNombre a lo que ingrese el usuario
                                    if (nuevoNombre.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                        break; //sale del bucle whie
                                    } else {   
                                        throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                     }
                                } catch(InputMismatchException error){ //sino cacha el error e imprime mensaje
                                    //System.out.println("Dato incorrecto. Ingresa el nombre nuevamente");
                                    System.out.println(error.getMessage()); //imprime el dato de error
                                }
                            }
                                
                            while (!encontrado) { //definimos encontrado como false anteriormente. Este ciclo hace que se repita hasta que el usuario ingrese dato correcto
                                try { //try catch para validar dato double
                                    System.out.print("Ingrese el nuevo precio: "); //modifica el precio
                                    nuevoPrecio = sc.nextDouble();
                                    encontrado = true; //si ingresa un dato correcto encontrado se establece en true, sale del bucle while y se deja de repetir
                                } catch(InputMismatchException err) { //para detectar error de dato
                                    System.out.println("Dato incorrecto. Ingresa números únicamente");
                                    sc.next(); //limpia el buffer
                                }
                            }
                                
                            while (!encontrado){ //bucle while se ejecuta mientras !encontrado, true    
                                try { //try catch para validar dato double
                                    System.out.print("Ingrese la nueva cantidad: "); //modifica la cantidad
                                    nuevaCantidad = sc.nextInt();
                                    encontrado = true; //si ingresa un dato correcto sale del bucle while y se deja de repetir
                                } catch(InputMismatchException err) { 
                                    System.out.println("Dato incorrecto. Ingresa números únicamente");
                                    sc.next(); //limpia el buffer
                                }
                            }
                                
                                //actualiza el producto
                                productoModificar.setNombre(nuevoNombre);
                                productoModificar.setPrecio(nuevoPrecio);
                                productoModificar.setCantidad(nuevaCantidad);
                                System.out.println("Producto modificado: " + productoModificar);
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto para modificar."); //mensaje de error
                        }
                        System.out.println();//imprime espacio
                      }
                      
                      case 4 -> { //buscar productos por nombre
                        String buscar = ""; //declaracion de variable
                        
                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                            try { //try catch para validar datos e imprimir mensaje de error
                            System.out.print("Ingrese el nombre del producto a buscar: ");
                            buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                            if (buscar.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                break; //sale del bucle whie
                            } else {   
                                throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                            } 
                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                            System.out.println(error.getMessage()); //imprime el mensaje de error
                            }
                        }
                        
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) {
                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto deseado.");
                        }
                        System.out.println();//imprime espacio
                      }
                      
                      case 5 -> { //mostrar todos los productos en el inventario
                        System.out.println("El numero de productos agregados es: " + productos.size());
                        for (int i = 0; i < productos.size(); i++) {
                            System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                        }
                        System.out.println();//imprime espacio
                      }
                      
                    case 6 -> //salir
                        System.out.println("Nos vemos, espero haya sido util :)");
                    default -> System.out.println("Opcion no valida, por favor intente de nuevo.");
                }
        }while(opcion !=6);
    }
}
