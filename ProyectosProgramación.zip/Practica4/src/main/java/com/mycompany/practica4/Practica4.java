package com.mycompany.practica4;
import java.util.*;

public class Practica4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //permite ingresar datos
        int numeros [] = new int [10]; //creacion del arreglo, como objeto
        System.out.println("Ingresa 10 datos enteros. Comienza");
        for (int i = 1; i < 10; i ++) {
            numeros [i] = scanner.nextInt(); //para agregar cada numero, con el for recorre las posiciones 0 - 10 y va reemplazando ese valor
        }
        int menor = numeros[0]; //menor es el primer numero
        for (int i = 1; i < 10; i ++) { //va recorriendo el arreglo
            if (numeros[i] < menor) { //van intercambiando valores, metodo burbuja
                menor = numeros[i]; //asi se asigna menor a ese elemento de la lista
            }
        }
        
        System.out.println("El numero menor es " + menor);
    }
}
