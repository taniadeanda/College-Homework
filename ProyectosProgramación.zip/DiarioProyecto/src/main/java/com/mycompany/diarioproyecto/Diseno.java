package com.mycompany.diarioproyecto;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author danie
 */
public class Diseno extends javax.swing.JFrame {

    
    Nodo actual = null, inicio = null, fin = null;     //Crear los punteros
    String temporalrutaimagen;    // Manejo de las rutas para cargar imagene

    public Diseno() {
        initComponents();
    }

   boolean listaVacia(){
       //Forma corta de checar si esta vacia
       return inicio==null;
    }
    
      void cargarImagen(){
        try{
                // Buscar imagenes
        JFileChooser exploradorImagen = new JFileChooser();
        exploradorImagen.addChoosableFileFilter(new FileNameExtensionFilter("imagen","jpg","png"));
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile();
        temporalrutaimagen =auxFile.getAbsolutePath();
        
        JFoto.setIcon(new javax.swing.ImageIcon(temporalrutaimagen));
        setImagenLabel(JFoto, temporalrutaimagen);
        }catch(NullPointerException e){
        JOptionPane.showMessageDialog(null,"Error al cargar el archivo de imagen");
        }
    }
    
    private void setImagenLabel(JLabel label, String imagePath){
         // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(imagePath);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    label.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    label.repaint();
    }
    
    void InsertarInicio(){ //VALIDAR que el usuario haya llenado todos los campos de texto para que pueda insertar
        //String emoji = (String)CajaEmojis.getItemAt(WIDTH);
        String emoji = (String) CajaEmojis.getSelectedItem();  
    Nodo nuevo = new Nodo(temporalrutaimagen, cptNombre.getText(), cptFecha.getText(),cptDescripcion.getText(), emoji, null, null); //String rutaarchivo, String nombre, String fecha, String descripcion, String emoji, Nodo anterior, Nodo siguiente 
    if(listaVacia()){
         JOptionPane.showMessageDialog(null, "Primera Imagen agregada con exito", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo;
         fin = nuevo;
     }else{ //Conecetar los enlaces al nuevo nodo 
         nuevo.setSiguiente(inicio);
         inicio.setAnterior(nuevo);
         JOptionPane.showMessageDialog(null, "Nueva iamgen agregada con exto", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo; //Recorre el inico al nuevo nodo
       } 
        actual = inicio; //que actual apunte al nuevo nodo
        System.out.println("Nodo insertado");
    }
    
    /*void Mostrar() { //no se USA porque tenemos actualizarVisor();
    if (listaVacia() || inicio == null) {  // Validar si la lista está vacía
        JOptionPane.showMessageDialog(null, "No hay elementos en la lista", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;  // Salir de la función si no hay elementos
    }
    Nodo chalan = inicio;
    int contador = 1;
    do {
        System.out.println("Posicion " + contador + ": " + chalan.getInterprete()); // Revisa el nombre correcto del método
        InterpreteVisual.setText( chalan.getInterprete());
        chalan = chalan.getSiguiente();
        contador++;
    } while (chalan != null && chalan != inicio);  // Validar `null` en listas no circulares
    }*/
    
    
    void actualizarVisor(){ 
        // Actualizar los campos de texto con los valores del nodo actual
        JFecha.setText(actual.fecha);
        JNombre.setText(actual.nombre);
        JEmoji.setText(actual.emoji);
        //jMelodia.setText(actual.nombreMelodia);
        if (listaVacia()) {
        // Si la lista está vacía, mostrar un mensaje en el JLabel
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        } else {
            AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al tamaño del JLabel
        }
    }
    
     void mostrarDescripcion() {
    if (JFecha.getText().equals("Fecha")) { 
            JOptionPane.showMessageDialog(null, "No hay descripción disponible", "Descripción", JOptionPane.WARNING_MESSAGE);
            return;   
        }
    if (actual == null || actual.getDescripcion().isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay descripción disponible", "Descripción", JOptionPane.WARNING_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, actual.getDescripcion(), "Descripción", JOptionPane.INFORMATION_MESSAGE);
    }
}

    
       void borrarInterprete() {
    // Verificar si la lista está vacía
    if (listaVacia()) {
        JOptionPane.showMessageDialog(null, "No hay imágenes");
    } else {
        try {
            // Solicitar al usuario el nombre de la imagen a eliminar
            String inter = JOptionPane.showInputDialog(null, "Ingrese el nombre de la foto a eliminar:");

            // Verificar si el usuario ingresó un valor válido
            if (inter == null || inter.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Debe ingresar un nombre válido.");
                return;
            }

            Nodo temp = inicio;

            while (temp != null) {
                // Comparar el nombre del nodo con el ingresado
                if (temp.getNombre().equalsIgnoreCase(inter)) {
                    // Mostrar un cuadro de confirmación antes de eliminar
                    int confirmacion = JOptionPane.showConfirmDialog(null,
                        "¿Está seguro de que desea eliminar la imagen '" + inter + "'?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION);

                    // Si el usuario confirma la eliminación
                    if (confirmacion == JOptionPane.YES_OPTION) {
                        // Si es el único nodo en la lista
                        if (temp == inicio && temp == fin) {
                            inicio = null;
                            fin = null;
                        }
                        // Si el nodo a eliminar es el primero de la lista
                        else if (temp == inicio) {
                            inicio = inicio.getSiguiente();
                            if (inicio != null) {
                                inicio.setAnterior(null);
                            }
                        }
                        // Si el nodo a eliminar es el último de la lista
                        else if (temp == fin) {
                            fin = fin.getAnterior();
                            if (fin != null) {
                                fin.setSiguiente(null);
                            }
                        }
                        // Si el nodo a eliminar está en medio de la lista
                        else {
                            temp.getAnterior().setSiguiente(temp.getSiguiente());
                            temp.getSiguiente().setAnterior(temp.getAnterior());
                        }

                        JOptionPane.showMessageDialog(null, "Imagen eliminada: " + inter);
                    } else {
                        JOptionPane.showMessageDialog(null, "Eliminación cancelada.");
                    }
                    return; // Salir de la función después de procesar la eliminación
                }
                temp = temp.getSiguiente();
            }

            // Si no se encontró la imagen con el nombre ingresado
            JOptionPane.showMessageDialog(null, "No existe ninguna imagen con ese nombre.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al procesar la eliminación.");
        }
    }
}

        
        private void limpiarCampos() {
    cptNombre.setText("");
    cptDescripcion.setText("");
    cptFecha.setText("");
   // cptEmoji.setText("");
    temporalrutaimagen = null; // Limpiar la ruta de la imagen
    JFoto.setIcon(null); // Quitar la imagen del JLabel
}
        void limpiarVizor(){
            JNombre.setText("");
            JFecha.setText("Fecha");
            JEmoji.setText("Emoji");
            temporalrutaimagen = null; // Limpiar la ruta de la imagen
            JFoto.setIcon(null); // Quitar la imagen del JLabel    
        }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Imagen = new javax.swing.JLabel();
        btnCargarImagen = new javax.swing.JButton();
        cptNombre = new javax.swing.JTextField();
        cptFecha = new javax.swing.JTextField();
        JFoto = new javax.swing.JLabel();
        btnRetrocederInicio = new javax.swing.JButton();
        btnRetroceder = new javax.swing.JButton();
        btnAvanzar = new javax.swing.JButton();
        btnAvanzarFinal = new javax.swing.JButton();
        btnGuardarDatos = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        JNombre = new javax.swing.JLabel();
        JFecha = new javax.swing.JLabel();
        JEmoji = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        cptDescripcion = new javax.swing.JTextField();
        btnMostrarDescripcion = new javax.swing.JButton();
        CajaEmojis = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 28)); // NOI18N
        jLabel1.setText("Diario de Imagenes");

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 20)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 20)); // NOI18N
        jLabel3.setText("Fecha");

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 20)); // NOI18N
        jLabel4.setText("Descripcion");

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 20)); // NOI18N
        jLabel5.setText("Emoji");

        Imagen.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 20)); // NOI18N
        Imagen.setText("Imagen");

        btnCargarImagen.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnCargarImagen.setText("Cargar Imagen");
        btnCargarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarImagenActionPerformed(evt);
            }
        });

        cptNombre.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N

        cptFecha.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N

        JFoto.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        JFoto.setText("Foto");
        JFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnRetrocederInicio.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnRetrocederInicio.setText("|<");
        btnRetrocederInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederInicioActionPerformed(evt);
            }
        });

        btnRetroceder.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnRetroceder.setText("<<");
        btnRetroceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederActionPerformed(evt);
            }
        });

        btnAvanzar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnAvanzar.setText(">>");
        btnAvanzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarActionPerformed(evt);
            }
        });

        btnAvanzarFinal.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnAvanzarFinal.setText(">|");
        btnAvanzarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarFinalActionPerformed(evt);
            }
        });

        btnGuardarDatos.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnGuardarDatos.setText("Subir");
        btnGuardarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarDatosActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel6.setText("Nombre:");

        JNombre.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        JNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JFecha.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        JFecha.setText("Fecha");
        JFecha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JEmoji.setFont(new java.awt.Font("Segoe UI Emoji", 0, 18)); // NOI18N
        JEmoji.setText("Emoji");

        btnEliminar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnEliminar.setText("Eliminar Imagen");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        cptDescripcion.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N

        btnMostrarDescripcion.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        btnMostrarDescripcion.setText("Descripcion");
        btnMostrarDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDescripcionActionPerformed(evt);
            }
        });

        CajaEmojis.setFont(new java.awt.Font("Segoe UI Emoji", 0, 18)); // NOI18N
        CajaEmojis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "😁", "👍", "🤣", "😂", "😒", "🙌", "❤", "😍", "😘", "😎", "😍", "☺️" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(Imagen, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnCargarImagen)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(CajaEmojis, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(5, 5, 5))))
                            .addComponent(btnGuardarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(7, 7, 7)
                                    .addComponent(cptDescripcion))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cptFecha, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                                        .addComponent(cptNombre)))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(JEmoji, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(JFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(JNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(btnRetrocederInicio)
                                .addGap(18, 18, 18)
                                .addComponent(btnRetroceder)
                                .addGap(18, 18, 18)
                                .addComponent(btnAvanzar)
                                .addGap(18, 18, 18)
                                .addComponent(btnAvanzarFinal))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(143, 143, 143)
                        .addComponent(btnMostrarDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(34, 34, 34)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(cptNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(28, 28, 28)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel3)
                                            .addComponent(cptFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(28, 28, 28)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel4)
                                            .addComponent(cptDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(30, 30, 30)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(CajaEmojis, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addComponent(JFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(Imagen)
                                            .addComponent(btnCargarImagen)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(JNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(29, 29, 29)
                                        .addComponent(btnGuardarDatos))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(JFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(JEmoji, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(btnMostrarDescripcion)
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnEliminar)
                        .addGap(9, 9, 9)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAvanzar)
                    .addComponent(btnAvanzarFinal)
                    .addComponent(btnRetroceder)
                    .addComponent(btnRetrocederInicio))
                .addGap(121, 121, 121))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarDatosActionPerformed
        //BOTON PARA GUARDAR LAS IMAGENES
        //Revisamos que es lo que hay en el empji
        //String emoji = (String)CajaEmojis.getItemAt(WIDTH);
        String emoji = (String) CajaEmojis.getSelectedItem(); 
        //VALIDACIONES
        if (temporalrutaimagen == null || temporalrutaimagen.isEmpty()) { //verificar que se haya seleccionado una imagen
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna imagen.", "Informacion:", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        }
        
        if (cptNombre.getText().isEmpty()) { //verificar que se haya ingresado un nombre
            JOptionPane.showMessageDialog(this, "Para guardar, ingresa un nombre para la imagen.","Informacion:", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta
        }
        
        if (cptFecha.getText().isEmpty()) { //verificar que temga fecha
            JOptionPane.showMessageDialog(this, "Imagen sin fecha, por favor ingresa una fecha.", "Informacion",JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        }
        
        if (cptDescripcion.getText().isEmpty()) { //verificar que tenga una descripción
            JOptionPane.showMessageDialog(this, "Olvidaste poner una descripción,agregala para guardar.", "Informacion", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        }
        
        if (emoji == null || emoji.equals("Escoje uno")) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un emoji.","Infomacion:",JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        InsertarInicio();
        System.out.println("Insertando nodo");
        
        if (actual == null) {
            JOptionPane.showMessageDialog(this, "Error: No hay un nodo activo para guardar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        actual.emoji = emoji; //nos aseguramos que se guarda el emoji
        System.out.println("Emoji guardado "+actual.emoji);
        //InsertarInicio();
        limpiarCampos();
    }//GEN-LAST:event_btnGuardarDatosActionPerformed

    private void btnAvanzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarActionPerformed
        if (listaVacia()) {
            System.out.println("Error: La lista está vacía, no se puede avanzar.");
            return;
        }
        if (actual == null) {
            actual = inicio;  // Si 'actual' es null, lo inicializamos en 'inicio'
        } else {
            actual = actual.getSiguiente();  // Avanzamos al siguiente nodo
            if (actual == null) {
                actual = inicio;  // Si llegamos al final, volvemos al inicio (lista circular)
            }
        }
        actualizarVisor();
        JNombre.setText(actual.getNombre());
        System.out.println("Nombre: " + actual.getNombre());
    }//GEN-LAST:event_btnAvanzarActionPerformed

    private void btnCargarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarImagenActionPerformed
        //BOTON PARA CARGAR LAS IMAGENES
        cargarImagen();
    }//GEN-LAST:event_btnCargarImagenActionPerformed

    private void btnAvanzarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarFinalActionPerformed
         if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
        }
        if (fin != null) {
            actual = fin; // Nos aseguramos de que 'actual' empiece desde el final
            JFecha.setText(actual.nombre);
            JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
            JNombre.setText( actual.getNombre());
            actualizarVisor(); //para que la imagen tmbn se actualice
        } else {
            System.out.println("Error: 'fin' es null.");
        }
    }//GEN-LAST:event_btnAvanzarFinalActionPerformed

    private void btnMostrarDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDescripcionActionPerformed
        mostrarDescripcion();
    }//GEN-LAST:event_btnMostrarDescripcionActionPerformed

    private void btnRetrocederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederActionPerformed
        
        if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        JOptionPane.showMessageDialog(null, " La lista está vacía, no se puede retroceder", "Error", JOptionPane.INFORMATION_MESSAGE);
      //  System.out.println("Error: La lista está vacía, no se puede retroceder.");
        return;
        }
        
        if (actual == null) {
        System.out.println("Error: 'actual' es null, no se puede retroceder.");
        return;
    }
    if (actual.getAnterior() != null) {
        actual = actual.getAnterior(); // Retrocedemos
    } else {
        actual = fin; // Si estamos en el inicio, saltamos al final (lista circular)
    }
    actualizarVisor();
    JNombre.setText(actual.getNombre());
    System.out.println("Nombre: " + actual.getNombre());
       
    }//GEN-LAST:event_btnRetrocederActionPerformed

    private void btnRetrocederInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederInicioActionPerformed
        if (listaVacia()) {
        JFoto.setText("Lista Vacia");
         JOptionPane.showMessageDialog(null, "La lista está vacía, no hay nada para actualizar", "Error", JOptionPane.INFORMATION_MESSAGE);
      //  System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
    }
    if (inicio != null) {
        actual = inicio; // Nos aseguramos de que 'actual' empiece desde el inicio
        JFecha.setText(actual.nombre);
        JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
        JNombre.setText(actual.getNombre());
        actualizarVisor(); //para que lo muestre
    } else {
        System.out.println("Error: 'inicio' es null.");
    }
    }//GEN-LAST:event_btnRetrocederInicioActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        borrarInterprete();
        limpiarVizor();
    }//GEN-LAST:event_btnEliminarActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Diseno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseno().setVisible(true);
            }
        });
    }
    
        
// Método para ajustar el tamaño de la imagen
void AjustarImagen(JLabel lbl, String ruta) {
    // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(ruta);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    lbl.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    lbl.repaint();
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CajaEmojis;
    private javax.swing.JLabel Imagen;
    private javax.swing.JLabel JEmoji;
    private javax.swing.JLabel JFecha;
    private javax.swing.JLabel JFoto;
    private javax.swing.JLabel JNombre;
    private javax.swing.JButton btnAvanzar;
    private javax.swing.JButton btnAvanzarFinal;
    private javax.swing.JButton btnCargarImagen;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarDatos;
    private javax.swing.JButton btnMostrarDescripcion;
    private javax.swing.JButton btnRetroceder;
    private javax.swing.JButton btnRetrocederInicio;
    private javax.swing.JTextField cptDescripcion;
    private javax.swing.JTextField cptFecha;
    private javax.swing.JTextField cptNombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
