/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.diarioproyecto;

/**
 *
 * @author danie
 */
public class DiarioProyecto {

    public static void main(String[] args) {
         new Diseno().setVisible(true);
    }
}
