package com.mycompany.interfazgrafica1;
import java.awt.*;
import java.awt.event.ActionListener; //para programacion orientada a eventos
import java.awt.event.ActionEvent; //para programacion orientada a evento
import javax.swing.*; //para ventanas grraficas
//investigar minimo 5 propiedades de label, buton, text field
public abstract class InterfazGrafica1 extends JFrame implements ActionListener { //JFrame ya es una clase que tiene. implements ActionListener es para implementar acciones de escucha a los eventos, para programacion orientada a objetos

    public static void main(String[] args) {
        //1.para el FORMATO del marco de la ventana
        JFrame ventana = new JFrame("Mi primer ventana"); //creacion de la ventana con su titulo
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //con este metodo se manda a llamar el metodo exit close, significa que aparece el boton de cerrar ventan
        ventana.setBounds(100,100, 500, 200); //para que aparezca en un espacio de la pantalla. Ej al centro, a la orilla
        ventana.setSize(400,200);  //propiedades de tamanoo en pixeles
        //2.Crear contenedor, todo lo que almacenara
        JPanel contenedor = new JPanel(); //JPanel es el CONTENEDOR: el marco que contiene elementos
        JLabel etiqueta = new JLabel("Ingresa tu nombre: "); //se crea una etiqueta en el marco que imprime ingresa tu nombre
        JTextField entrada = new JTextField(20); //se declara entrada de texto con JTextField
        contenedor.add(etiqueta); //add indica que se agregue la etiqueta y entrada en el contenedor, o sea en la ventana
        contenedor.add(entrada);
        ventana.add(contenedor); //diferencia de JFrame y JPanel?
        contenedor.setBackground(Color.BLUE); //para modificar el color del contenedor
        //3.Programar botones con eventos
        JButton boton = new JButton ("Mostrar nombre"); //creacion del boton lo que queremos que imprima
        //boton.setBounds(200, 200, 40, 5); //para posicionar la ubicacion del boton
        boton.setBackground(Color.PINK);
        contenedor.add(boton); //el boton se agrega al contenedor NO A LA VENTANA
        boton.addActionListener(new ActionListener() //para que haga algo el programa con el click
        {@Override
            public void actionPerformed(ActionEvent e) { //actionPerformed es el click que se le da al boton
            etiqueta.setText(entrada.getText()); //lo que quieres que haga con el click
            //la etiqueta ahora va a tener lo que el usuario escribio en entrada 
            }});

        // que sea visible la ventana
        ventana.setVisible(true); //para que la ventana sea visible y se aparezca
        }
}
 

/*
JLabel (Etiqueta):
    Texto: El texto que muestra la etiqueta. label.setText("Hola Mundo");
    Fuente: La fuente del texto de la etiqueta. label.setFont(new Font("Serif", Font.BOLD, 20));
    Color del Texto (Foreground): El color del texto. label.setForeground(Color.RED);
    Alineación Horizontal: Alineación del texto (izquierda, centro, derecha). label.setHorizontalAlignment(SwingConstants.CENTER);
    Icono: Una imagen que se muestra con la etiqueta. label.setIcon(new ImageIcon("imagen.png"));

JButton (Botón):
    Texto: El texto que muestra el botón. button.setText("Haz clic aquí");
    Habilitado (Enabled): Si el botón está habilitado o deshabilitado. button.setEnabled(false);
    Texto de Ayuda (ToolTipText): Texto que se muestra cuando el ratón pasa por encima del botón. button.setToolTipText("Haz clic en este botón para enviar");
    Comando de Acción (Action Command): Un comando asociado con la acción del botón. button.setActionCommand("EnviarComando");
    Mnemónico: Un atajo de teclado para activar el botón. button.setMnemonic(KeyEvent.VK_C);

JTextField (Campo de Texto):
    Columnas: El número de columnas en el campo de texto (afecta al ancho preferido). textField.setColumns(20);
    Editable: Si el campo de texto es editable o no. textField.setEditable(false);
    Texto: El texto contenido en el campo de texto. textField.setText("Introduce tu nombre");
    Color del Texto (Foreground): El color del texto. textField.setForeground(Color.BLUE);
    Color de Fondo (Background): El color de fondo del campo de texto. textField.setBackground(Color.YELLOW);

*/