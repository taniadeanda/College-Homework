package com.mycompany.recursividad3;
import java.util.Scanner; //libreria para scanner leer

public class Recursividad3 {
//imprime los digitos de 1 hasta N. Se debe pasar como parametro el numero N
    
    static void Recursividad(int n, int contador){ //declaracion de funcion n
    //caso base donde tiene que parar
    //va a sustituir el bucle for y while
    //int contador = 0; //falla en que cuando se vuelve a llamar vuelve a inicializar contador en 0 y nunca aumenta
    if (contador == n+1){
        System.out.println("Tus numeros hasta "+n+" son: "+contador); //deberia imprimir recursivamente el contador de cada uno
        return; //se sale de la funcion
    } 
    else { //imprime el numero y aumenta contador
        contador = contador++; //aumenta uno en contador, imprimir de uno en uno, sumarle 1
        Recursividad(n, contador); //se manda a llamar a la funcion y ahora toma contador como contador++ como parametro en la funcion
    }
        System.out.println("¡Hasta pronto!");
    }
      
    public static void main(String[] args) {    
        int contador = 0;
        System.out.println("Escribe tu numero N hasta el que quieres imprimir");
        Scanner sc = new Scanner(System.in); //se crea una instancia para leer
        int n = sc.nextInt(); //pide el nombre al usuario
        Recursividad(n, contador); //manda a llamar la funcion
    }
}
