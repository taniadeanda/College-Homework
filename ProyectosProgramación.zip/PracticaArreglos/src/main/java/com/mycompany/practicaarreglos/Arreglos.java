package com.mycompany.practicaArreglos;

public class Arreglos { //creación de la clase y sus atributos (variables)
    private String nombrecompleto;
    private int edad;
    //creacion de constructores, con el mismo nombre uno tiene parametros y el otro esta vacio SOBRECARGA DE CONSTRUCTORES
    
    public Arreglos (String nombrecompleto, int edad) { //definicion del constructor, es como una funcion que va a usar las variables
    this.nombrecompleto = nombrecompleto; //diferencia del parámetro y valor (atributos)
    this.edad = edad;
    }
    
    public Arreglos () { // creación del constructor vacio
    this.nombrecompleto = ""; //diferencia del parámetro y valor (atributos)
    this.edad = 19;
    }
    
    public void setnombrecompleto(String nombrecompleto) { 
        this.nombrecompleto  = nombrecompleto;
    }
    
    public String getnombrecompleto() { 
        return this.nombrecompleto;
    }
    
    public void setedad(int edad) { 
        this.edad  = edad;
    }
    
    public int getedad() { 
        return this.edad;
    }
    
    void imprimir_ficha(){
        System.out.println("Tus datos son: \n - Nombre Completo: " + nombrecompleto + "\n - Fecha: " + edad);
    }
    
}
