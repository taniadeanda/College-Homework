package com.mycompany.practicaArreglos;
//import com.mycompany.practicaArreglos.Arreglos;
import java.util.*; //importa todas las librerias
//Un arreglo es un conjunto de datos. Este ayuda a organizar información como si fuera una tabla con filas y columnas. 
//static int opcion;
//static int contador = 0;
public class PracticaArreglos { //hacer menu para ingresar o imprimir datos
    
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in); //se crea una instancia para leer
            Arreglos [] arregloPersonas = new Arreglos [10]; //declaracion del arreglo, nombre de la clase, nombre del arreglo, nombre de la clase y extensión
            int opcion = sc.nextInt(); //lee datos
            int contador = 0;
            do {
            System.out.println("Bienvenido a fichas de alumnos. A continuación elige la opción que desees: \n 1.Dar de alta registros \n 2.Mostrar registros \n 3.Cerrar");
            sc.nextLine(); // Limpiar el buffer
            switch (opcion) {
                case 1 -> {
                    for (int i = contador; i < 3; i ++) {
                        arregloPersonas [i] = new Arreglos (); //posicion 0, i va incrementando
                        System.out.println("Escribe a continuación tu nombre completo");
                        arregloPersonas [i].setnombrecompleto (sc.nextLine()); //pide el nombre al usuario
                        System.out.println("Escribe a continuación tu edad");
                        arregloPersonas [i].setedad(sc.nextInt()); //pide la edad al usuario
                        sc.nextLine();
                        contador++; //incrementa el contador cuando hay un registro
                    }
                }
                case 2 -> {
                    for (int i = 0; i < contador; i ++) { //mostrar datos
                        System.out.println("Tu nombre es " + i + " " + arregloPersonas[i].getnombrecompleto());
                        System.out.println("Tu edad es " + i + " " + arregloPersonas[i].getedad());
                    }
                    //default -> System.out.println("Opcion incorrecta");
                }
                //default -> System.out.println("Opcion incorrecta");
                case 3 ->{
                    System.out.println("Finalizado");
                }
            } //declaracion del arreglo, nombre de la clase, nombre del arreglo, nombre de la clase y extensión
    } while(opcion != 3); //cierr ado 
}
}