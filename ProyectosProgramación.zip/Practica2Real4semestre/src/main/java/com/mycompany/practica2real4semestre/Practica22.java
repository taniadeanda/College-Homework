                                                                                                                                                                            package com.mycompany.practica2real4semestre;
//package com.mycompany.practica22;

public class Practica22 {
    public static void main(String[] args) {
       new Registro().setVisible(true);
    }
}
