                                                                                                                                                                package com.mycompany.practica2real4semestre;
import javax.swing.JOptionPane;
//import javax.swing.text.AbstractDocument;
public class Registro extends javax.swing.JFrame {
    // Arreglo de objetos 
    Materias alumnos[] = new Materias[6];    //
    //Materias alumnos[] = new alumnos[6];
//falto constructor de alumnos,AGREGAR 
    int indice = 1;
    double matecal=0, quimical=0, compucal=0;
   
    public Registro() {
        initComponents();
         setLocationRelativeTo(null); // Centra la ventana en la pantalla
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Matemáticas = new javax.swing.JLabel();
        Química = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cptNombre = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        CaliMate = new javax.swing.JFormattedTextField();
        CaliQuimica = new javax.swing.JFormattedTextField();
        CaliComputo = new javax.swing.JFormattedTextField();
        Matemáticas1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Segoe Script", 0, 48)); // NOI18N
        jLabel1.setText("Registro Alumnos");

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel2.setText("Nombre");

        Matemáticas.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        Matemáticas.setText("Matemáticas");

        Química.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        Química.setText("Química");

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel5.setText("Computación");

        cptNombre.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N

        btnGuardar.setBackground(new java.awt.Color(204, 255, 255));
        btnGuardar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 2, 14)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnMostrar.setBackground(new java.awt.Color(204, 255, 255));
        btnMostrar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 2, 14)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        CaliMate.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));

        CaliQuimica.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));

        CaliComputo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));

        Matemáticas1.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 1, 18)); // NOI18N
        Matemáticas1.setText("Materias");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(Matemáticas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(CaliMate, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(Matemáticas1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cptNombre)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Química, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(CaliQuimica, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CaliComputo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(83, 83, 83))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cptNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addComponent(Matemáticas1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Matemáticas)
                    .addComponent(Química)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CaliQuimica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CaliMate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CaliComputo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(81, 81, 81)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnMostrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
         //Validaciones y ventanas emergentes
        if (cptNombre.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "El nombre esta vacío.", "ERROR", JOptionPane.ERROR_MESSAGE);
         }
        //CAMBIAR POR "OR"
        if (CaliMate.getValue() == null || (double) CaliMate.getValue() > 10 || (double) CaliQuimica.getValue() > 10 || CaliQuimica.getValue() == null || CaliComputo.getValue() == null || (double) CaliComputo.getValue() > 10) {
        JOptionPane.showMessageDialog(this, "Ingresa calificaciones o calificaciones válidas.", "ERROR", JOptionPane.ERROR_MESSAGE);
        
        /*if ((double) CaliMate.getValue() > 10 || (double) CaliQuimica.getValue() > 10 || (double) CaliComputo.getValue() > 10) {
          JOptionPane.showMessageDialog(this, "Las calificaciones deben estar en un rango de 0-10.", "ERROR", JOptionPane.ERROR_MESSAGE);
        return; 
        */
        
        if ((double) CaliMate.getValue() <= 0 || (double) CaliMate.getValue() > 10 || (double) CaliQuimica.getValue() <= 0 || (double) CaliQuimica.getValue() > 10 || (double) CaliComputo.getValue() <= 0 || (double) CaliComputo.getValue() > 10) {
          JOptionPane.showMessageDialog(this, "Las calificaciones deben estar en un rango de 0-10.", "ERROR", JOptionPane.ERROR_MESSAGE);
           return;
        }

        }
        if(indice == alumnos.length){
              JOptionPane.showMessageDialog(this, "Llegaste al límite de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        }else{
        double matem = ((Number) CaliMate.getValue()).doubleValue();  // Convierte a double
        double quim = ((Number) CaliQuimica.getValue()).doubleValue();
        double computo = ((Number) CaliComputo.getValue()).doubleValue();

        matecal = matem;
        quimical = quim;
        compucal = computo;
        
        // Para calcular el promedio
        double promed = (matem + quim + computo) / 3;
        
        //Para guardar
        alumnos[indice]= new Materias(cptNombre.getText(),matem,quim,computo, promed);
        indice++;
        
        JOptionPane.showMessageDialog(this, 
            "Alumno registrado", 
            "Registro Completo", JOptionPane.INFORMATION_MESSAGE);
         
        }
        // Para limpiar datos y vaciar los campos
        cptNombre.setText("");
        CaliMate.setValue(null);
        CaliQuimica.setValue(null);
        CaliComputo.setValue(null);
    
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
      
         StringBuilder sb = new StringBuilder();
    
    for (int i = 1; i < indice; i++) {
        sb.append("Alumno #: ").append(i).append("\n");
        sb.append("Nombre: ").append(alumnos[i].getNombre()).append("\n");
        sb.append("Calificación de Matemáticas: ").append(alumnos[i].mate).append("\n");
        sb.append("Calificación de Química: ").append(alumnos[i].quimica).append("\n");
        sb.append("Calificación de Computación: ").append(alumnos[i].compu).append("\n");
        sb.append("Promedio: ").append(alumnos[i].promedio).append("\n");
        sb.append("\n"); //
    }
    
    // Mensaje con la información de los alumnos
    JOptionPane.showMessageDialog(this, sb.toString(), "Lista de Alumnos", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnMostrarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFormattedTextField CaliComputo;
    private javax.swing.JFormattedTextField CaliMate;
    private javax.swing.JFormattedTextField CaliQuimica;
    private javax.swing.JLabel Matemáticas;
    private javax.swing.JLabel Matemáticas1;
    private javax.swing.JLabel Química;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JTextField cptNombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
