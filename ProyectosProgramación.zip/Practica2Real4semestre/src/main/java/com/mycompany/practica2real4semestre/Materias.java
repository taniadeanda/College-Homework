                                                                                                                                                                                package com.mycompany.practica2real4semestre;
//package com.mycompany.practica22;
public class Materias {
    // Atributos
    String Nombre;
    double mate, quimica, compu, promedio;
    
    // Constructor
    public Materias(String Nombre, double mate, double quimica, double compu, double promedio) {
        this.Nombre = Nombre;
        this.mate = mate;
        this.quimica = quimica;
        this.compu = compu;
        this.promedio = promedio;
    }
    
    // Métodos getter y setter
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public double getMate() {
        return mate;
    }

    public void setMate(double mate) {
        this.mate = mate;
    }

    public double getQuimica() {
        return quimica;
    }

    public void setQuimica(double quimica) {
        this.quimica = quimica;
    }

    public double getCompu() {
        return compu;
    }

    public void setCompu(double compu) {
        this.compu = compu;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
   
}
