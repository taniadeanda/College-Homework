package com.mycompany.proyectodiarioplus;

public class ProyectoDiarioPlus {

    public static void main(String[] args) {
         new Diseno().setVisible(true);
    }
}
