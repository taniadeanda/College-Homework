package com.mycompany.proyectodiarioplus;

public class Nodo {
    String rutaarchivo;
    String nombre;
    String fecha; //validar fecha?
    String descripcion;
    String emoji; //ver si se escribe normal en teclado y luego se convierte a emoji
    Nodo  anterior, siguiente; /* Puteros*/
    //Constructor
    public Nodo(String rutaarchivo, String nombre, String fecha, String descripcion, String emoji, Nodo anterior, Nodo siguiente) {    
        this.rutaarchivo = rutaarchivo;
        this.nombre = nombre;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.emoji = emoji;
        this.anterior = anterior;
        this.siguiente = siguiente;
    }
    
    //Getter and Setter
    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEmoji() {
        return emoji;
    }

    public void setEmoji(String emoji) {
        this.emoji = emoji;
    } 
    
    public Nodo getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo anterior) {    
        this.anterior = anterior;
    }

    public String getRutaarchivo() {
        return rutaarchivo;
    }

    public void setRutaarchivo(String rutaarchivo) {
        this.rutaarchivo = rutaarchivo;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String interetre) {
        this.nombre = interetre;
    }
    
}
