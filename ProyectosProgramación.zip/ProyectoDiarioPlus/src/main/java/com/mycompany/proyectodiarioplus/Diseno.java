/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectodiarioplus;

import java.awt.Image;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
public class Diseno extends javax.swing.JFrame {

    
    Nodo actual = null, inicio = null, fin = null;     //Crear los punteros
    String temporalrutaimagen;    // Manejo de las rutas para cargar imagene

    public Diseno() {
        initComponents();
    }
    
     boolean listaVacia(){
       //Forma corta de checar si esta vacia
       return inicio==null;
    }
    
      void cargarImagen(){
        try{
                // Buscar imagenes
        JFileChooser exploradorImagen = new JFileChooser();
        exploradorImagen.addChoosableFileFilter(new FileNameExtensionFilter("imagen","jpg","png"));
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile();
        temporalrutaimagen =auxFile.getAbsolutePath();
        
        JFoto.setIcon(new javax.swing.ImageIcon(temporalrutaimagen));
        setImagenLabel(JFoto, temporalrutaimagen);
        }catch(NullPointerException e){
        JOptionPane.showMessageDialog(null,"Error al cargar el archivo de imagen");
        }
    }
    
    private void setImagenLabel(JLabel label, String imagePath){
         // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(imagePath);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    label.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    label.repaint();
    }
    
    
    
    void InsertarInicio(){ //VALIDAR que el usuario haya llenado todos los campos de texto para que pueda insertar
        //String emoji = (String)CajaEmojis.getItemAt(WIDTH);
      //  String emoji = (String) CajaEmojis.getSelectedItem();
    Nodo nuevo = new Nodo(temporalrutaimagen, cptNombre.getText(), cptFecha.getText(),cptDescripcion.getText(), null, null, null); //String rutaarchivo, String nombre, String fecha, String descripcion, String emoji, Nodo anterior, Nodo siguiente
    if(listaVacia()){
         JOptionPane.showMessageDialog(null, "Primera Imagen agregada con exito", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo;
         fin = nuevo;
     }else{ //Conecetar los enlaces al nuevo nodo 
         nuevo.setSiguiente(inicio);
         inicio.setAnterior(nuevo);
         JOptionPane.showMessageDialog(null, "Nueva iamgen agregada con exto", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo; //Recorre el inico al nuevo nodo
       } 
        actual = inicio; //que actual apunte al nuevo nodo
        System.out.println("Nodo insertado");
    }
    
    /*void Mostrar() { //no se USA porque tenemos actualizarVisor();
    if (listaVacia() || inicio == null) {  // Validar si la lista está vacía
        JOptionPane.showMessageDialog(null, "No hay elementos en la lista", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;  // Salir de la función si no hay elementos
    }
    Nodo chalan = inicio;
    int contador = 1;
    do {
        System.out.println("Posicion " + contador + ": " + chalan.getInterprete()); // Revisa el nombre correcto del método
        InterpreteVisual.setText( chalan.getInterprete());
        chalan = chalan.getSiguiente();
        contador++;
    } while (chalan != null && chalan != inicio);  // Validar `null` en listas no circulares
    }*/
    
    
    void actualizarVisor(){ 
        // Actualizar los campos de texto con los valores del nodo actual
        JFecha.setText(actual.fecha);
        JNombre.setText(actual.nombre);
     //   JEmoji.setText(actual.emoji);
        //jMelodia.setText(actual.nombreMelodia);
        if (listaVacia()) {
        // Si la lista está vacía, mostrar un mensaje en el JLabel
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        } else {
            AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al tamaño del JLabel
        }
    }
    
    void mostrarDescripcion() {
    if (JFecha.getText().equals("Fecha")) { 
            JOptionPane.showMessageDialog(null, "No hay descripción disponible", "Descripción", JOptionPane.WARNING_MESSAGE);
            return;   
        }
    if (actual == null || actual.getDescripcion().isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay descripción disponible", "Descripción", JOptionPane.WARNING_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, actual.getDescripcion(), "Descripción", JOptionPane.INFORMATION_MESSAGE);
    }
}

    void borrarInterprete() {
    // Verificar si la lista está vacía
    if (listaVacia()) {
        JOptionPane.showMessageDialog(null, "No hay imágenes");
    } else {
        try {
            // Solicitar al usuario el nombre de la imagen a eliminar
            String inter = JOptionPane.showInputDialog(null, "Ingrese el nombre de la foto a eliminar:");

            // Verificar si el usuario ingresó un valor válido
            if (inter == null || inter.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Debe ingresar un nombre válido.");
                return;
            }

            Nodo temp = inicio;
            while (temp != null) {
                // Comparar el nombre del nodo con el ingresado
                if (temp.getNombre().equalsIgnoreCase(inter)) {
                    // Mostrar un cuadro de confirmación antes de eliminar
                    int confirmacion = JOptionPane.showConfirmDialog(null,
                        "¿Está seguro de que desea eliminar la imagen '" + inter + "'?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION);

                    // Si el usuario confirma la eliminación
                    if (confirmacion == JOptionPane.YES_OPTION) {
                        // Si es el único nodo en la lista
                        if (temp == inicio && temp == fin) {
                            inicio = null;
                            fin = null;
                        }
                        // Si el nodo a eliminar es el primero de la lista
                        else if (temp == inicio) {
                            inicio = inicio.getSiguiente();
                            if (inicio != null) {
                                inicio.setAnterior(null);
                            }
                        }
                        // Si el nodo a eliminar es el último de la lista
                        else if (temp == fin) {
                            fin = fin.getAnterior();
                            if (fin != null) {
                                fin.setSiguiente(null);
                            }
                        }
                        // Si el nodo a eliminar está en medio de la lista
                        else {
                            temp.getAnterior().setSiguiente(temp.getSiguiente());
                            temp.getSiguiente().setAnterior(temp.getAnterior());
                        }
                        JOptionPane.showMessageDialog(null, "Imagen eliminada: " + inter);
                    } else {
                        JOptionPane.showMessageDialog(null, "Eliminación cancelada.");
                    }
                    return; // Salir de la función después de procesar la eliminación
                }
                temp = temp.getSiguiente();
            }
            // Si no se encontró la imagen con el nombre ingresado
            JOptionPane.showMessageDialog(null, "No existe ninguna imagen con ese nombre.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al procesar la eliminación.");
        }
    }
}
    
    private void limpiarCampos() {
        cptNombre.setText("");
        cptDescripcion.setText("");
        cptFecha.setText("");
        //cptEmoji.setText("");
        temporalrutaimagen = null; // Limpiar la ruta de la imagen
        JFoto.setIcon(null); // Quitar la imagen del JLabel
    }
    
    void limpiarVizor(){
        JNombre.setText("");
        JFecha.setText("Fecha");
        JEmoji.setText("Emoji");
        temporalrutaimagen = null; // Limpiar la ruta de la imagen
        JFoto.setIcon(null); // Quitar la imagen del JLabel    
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cptDescripcion = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        JFoto = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        JNombre = new javax.swing.JLabel();
        btnCargarImagen = new javax.swing.JButton();
        JEmoji = new javax.swing.JLabel();
        JFecha = new javax.swing.JLabel();
        btnRetrocederInicio = new javax.swing.JButton();
        btnRetroceder = new javax.swing.JButton();
        btnAvanzar = new javax.swing.JButton();
        btnAvanzarFinal = new javax.swing.JButton();
        btnMostrarDescripcion = new javax.swing.JButton();
        cptNombre = new javax.swing.JTextField();
        btnGuardarDatos = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        cptFecha = new javax.swing.JTextField();
        JEmoji1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 24)); // NOI18N
        jLabel1.setText("Diario de Imágenes");

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel3.setText("Fecha");

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel4.setText("Descripción");

        cptDescripcion.setColumns(20);
        cptDescripcion.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 12)); // NOI18N
        cptDescripcion.setRows(5);
        jScrollPane1.setViewportView(cptDescripcion);

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel5.setText("Imagen");

        JFoto.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        JFoto.setText("Foto");
        JFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel6.setText("Nombre:");

        JNombre.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        JNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnCargarImagen.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnCargarImagen.setText("Cargar");
        btnCargarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarImagenActionPerformed(evt);
            }
        });

        JEmoji.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        JEmoji.setText("Fecha:");

        JFecha.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        JFecha.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnRetrocederInicio.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnRetrocederInicio.setText("|<");
        btnRetrocederInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederInicioActionPerformed(evt);
            }
        });

        btnRetroceder.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnRetroceder.setText("<<");
        btnRetroceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederActionPerformed(evt);
            }
        });

        btnAvanzar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnAvanzar.setText(">>");
        btnAvanzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarActionPerformed(evt);
            }
        });

        btnAvanzarFinal.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnAvanzarFinal.setText(">|");
        btnAvanzarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarFinalActionPerformed(evt);
            }
        });

        btnMostrarDescripcion.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnMostrarDescripcion.setText("Descripción");
        btnMostrarDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDescripcionActionPerformed(evt);
            }
        });

        cptNombre.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N

        btnGuardarDatos.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnGuardarDatos.setText("Guardar");
        btnGuardarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarDatosActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        cptFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cptFechaActionPerformed(evt);
            }
        });

        JEmoji1.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        JEmoji1.setText("Emoji:");

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 14)); // NOI18N
        jLabel7.setText("Emoji (se modifica al final)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cptNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cptFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCargarImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnRetrocederInicio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRetroceder)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAvanzar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAvanzarFinal))
                    .addComponent(btnMostrarDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(JFoto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(JEmoji, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(28, 28, 28)
                            .addComponent(JFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(JNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(JEmoji1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnGuardarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cptNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cptFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addComponent(jLabel4))
                    .addComponent(JFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JEmoji)
                            .addComponent(JFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(JEmoji1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(btnMostrarDescripcion))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnRetrocederInicio)
                                    .addComponent(btnRetroceder)
                                    .addComponent(btnAvanzar)
                                    .addComponent(btnAvanzarFinal))
                                .addGap(33, 33, 33))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminar)
                            .addComponent(btnCargarImagen)
                            .addComponent(btnGuardarDatos))))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarDatosActionPerformed
        //BOTON PARA GUARDAR LAS IMAGENES
        //Revisamos que es lo que hay en el empji
        //String emoji = (String)CajaEmojis.getItemAt(WIDTH);
        //String emoji = (String) CajaEmojis.getSelectedItem();
        //VALIDACIONES
        if (temporalrutaimagen == null || temporalrutaimagen.isEmpty()) { //verificar que se haya seleccionado una imagen
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna imagen.", "Informacion:", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        }
        
        if (cptNombre.getText().isEmpty()) { //verificar que se haya ingresado un nombre
            JOptionPane.showMessageDialog(this, "Para guardar, ingresa un nombre para la imagen.","Informacion:", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta
        }
        
        if (cptFecha.getText().isEmpty()) { //verificar que temga fecha
            JOptionPane.showMessageDialog(this, "Imagen sin fecha, por favor ingresa una fecha.", "Informacion",JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        } else if (!esFechaValida(cptFecha.getText())) { // Llamar a la función de validación
            JOptionPane.showMessageDialog(this, "Fecha inválida. Asegúrate de ingresar una fecha válida en formato dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (cptDescripcion.getText().isEmpty()) { //verificar que tenga una descripción
            JOptionPane.showMessageDialog(this, "Olvidaste poner una descripción,agregala para guardar.", "Informacion", JOptionPane.INFORMATION_MESSAGE);
            return;  //detener la ejecución si falta 
        }
        /*
        if (emoji == null || emoji.equals("Escoje uno")) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un emoji.","Infomacion:",JOptionPane.INFORMATION_MESSAGE);
            return;
        }*/
        InsertarInicio();
        System.out.println("Insertando nodo");
        
        if (actual == null) {
            JOptionPane.showMessageDialog(this, "Error: No hay un nodo activo para guardar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        //actual.emoji = emoji; //nos aseguramos que se guarda el emoji
        System.out.println("Emoji guardado "+actual.emoji);
        //InsertarInicio();
        limpiarCampos();
    }//GEN-LAST:event_btnGuardarDatosActionPerformed

    private void btnCargarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarImagenActionPerformed
         //BOTON PARA CARGAR LAS IMAGENES
        cargarImagen();
    }//GEN-LAST:event_btnCargarImagenActionPerformed

    private void btnRetrocederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederActionPerformed
        if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        JOptionPane.showMessageDialog(null, " La lista está vacía, no se puede retroceder", "Error", JOptionPane.INFORMATION_MESSAGE);
      //  System.out.println("Error: La lista está vacía, no se puede retroceder.");
        return;
        }
        
        if (actual == null) {
        System.out.println("Error: 'actual' es null, no se puede retroceder.");
        return;
    }
    if (actual.getAnterior() != null) {
        actual = actual.getAnterior(); // Retrocedemos
    } else {
        actual = fin; // Si estamos en el inicio, saltamos al final (lista circular)
    }
    actualizarVisor();
    JNombre.setText(actual.getNombre());
    System.out.println("Nombre: " + actual.getNombre());
       
    }//GEN-LAST:event_btnRetrocederActionPerformed

    private void btnAvanzarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarFinalActionPerformed
        if (listaVacia()) {
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
        }
        if (fin != null) {
            actual = fin; // Nos aseguramos de que 'actual' empiece desde el final
            JFecha.setText(actual.nombre);
            JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
            JNombre.setText( actual.getNombre());
            actualizarVisor(); //para que la imagen tmbn se actualice
        } else {
            System.out.println("Error: 'fin' es null.");
        }
    }//GEN-LAST:event_btnAvanzarFinalActionPerformed

    private void btnMostrarDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDescripcionActionPerformed
       mostrarDescripcion();
    }//GEN-LAST:event_btnMostrarDescripcionActionPerformed

    private void btnRetrocederInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederInicioActionPerformed
         if (listaVacia()) {
        JFoto.setText("Lista Vacia");
         JOptionPane.showMessageDialog(null, "La lista está vacía, no hay nada para actualizar", "Error", JOptionPane.INFORMATION_MESSAGE);
      //  System.out.println("La lista está vacía, no hay nada para actualizar");
        return;
    }
    if (inicio != null) {
        actual = inicio; // Nos aseguramos de que 'actual' empiece desde el inicio
        JFecha.setText(actual.nombre);
        JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));
        JNombre.setText(actual.getNombre());
        actualizarVisor(); //para que lo muestre
    } else {
        System.out.println("Error: 'inicio' es null.");
    }
    }//GEN-LAST:event_btnRetrocederInicioActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
         borrarInterprete();
        limpiarVizor();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnAvanzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarActionPerformed
                if (listaVacia()) {
            System.out.println("Error: La lista está vacía, no se puede avanzar.");
            return;
        }
        if (actual == null) {
            actual = inicio;  // Si 'actual' es null, lo inicializamos en 'inicio'
        } else {
            actual = actual.getSiguiente();  // Avanzamos al siguiente nodo
            if (actual == null) {
                actual = inicio;  // Si llegamos al final, volvemos al inicio (lista circular)
            }
        }
        actualizarVisor();
        JNombre.setText(actual.getNombre());
        System.out.println("Nombre: " + actual.getNombre());
    }//GEN-LAST:event_btnAvanzarActionPerformed

    public static boolean esFechaValida(String fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy"); //define el formato segun la libreria
        formatoFecha.setLenient(false); // No permitir fechas raras
        try {
            Date fechaParseada = formatoFecha.parse(fecha);//convertimos la fecha a fomato de fecha y validamos si existe el día, mes y año correctamente
            return true; // La fecha es válida
        } catch (ParseException e) {
            return false; // Si no se puede parsear, la fecha es inválida
        }
    }
    
    public static void validarEntradaFecha(javax.swing.JTextField cptFecha) {
    //String fechaIngresada = cptFecha.getText(); // Leer el texto del cuadro de texto
        if (esFechaValida(cptFecha.getText())) {
            JOptionPane.showMessageDialog(null, "La fecha es válida: " + cptFecha.getText());
        } 
        if (cptFecha.getText().trim().isEmpty()) {  //validaciones
            JOptionPane.showMessageDialog(null, "Error: El campo de fecha esta vacio" + cptFecha.getText());
        }
        else {
            JOptionPane.showMessageDialog(null, "Error: Ingresa una fecha válida en el formato dd/MM/yyyy.");
        }
    }
    
    private void cptFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cptFechaActionPerformed
        //validarEntradaFecha(cptFecha); //validar la fecha con el parametro del cuadro de texto
    }//GEN-LAST:event_cptFechaActionPerformed
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseno().setVisible(true);
            }
        });
    }
 
// Método para ajustar el tamaño de la imagen
void AjustarImagen(JLabel lbl, String ruta) {
    // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(ruta);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    lbl.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    lbl.repaint();
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JEmoji;
    private javax.swing.JLabel JEmoji1;
    private javax.swing.JLabel JFecha;
    private javax.swing.JLabel JFoto;
    private javax.swing.JLabel JNombre;
    private javax.swing.JButton btnAvanzar;
    private javax.swing.JButton btnAvanzarFinal;
    private javax.swing.JButton btnCargarImagen;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarDatos;
    private javax.swing.JButton btnMostrarDescripcion;
    private javax.swing.JButton btnRetroceder;
    private javax.swing.JButton btnRetrocederInicio;
    private javax.swing.JTextArea cptDescripcion;
    private javax.swing.JTextField cptFecha;
    private javax.swing.JTextField cptNombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
