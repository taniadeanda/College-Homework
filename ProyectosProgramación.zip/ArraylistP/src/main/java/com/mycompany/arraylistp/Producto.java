public class Producto {
    //variables del programa
    private String nombre;//variable nombre 
    private double precio;// variable precio 
    private int cantidad;// variable cantidad 
    
    //constructor de todas las variables de parámetros
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getNombre() {//get de la variable nombre
        return nombre;
    }

    public void setNombre(String nombre) {//set de la variable nombre
        this.nombre = nombre;
    }

    public double getPrecio() {//get de la variable precio
        return precio;
    }

    public void setPrecio(double precio) {//set de la variable precio
        this.precio = precio;
    }

    public int getCantidad() {//get de la variable cantidad
        return cantidad;
    }

    public void setCantidad(int cantidad) {//set de la variable cantidad
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nPrecio: ").append(precio);
        sb.append("\nCantidad: ").append(cantidad);
        return sb.toString();
    }
}