import java.util.ArrayList; // librería para el uso de los arraylist
import java.util.Scanner; // librería para leer datos desde el teclado
public class ArraylistP {
    static int opcion;
     
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Producto> productos = new ArrayList<>();

        System.out.println("Hola, hola bienvenid@ al programa de inventario de producto para comenzar"
                + "introduce el numero segun la accion que se desea hacer: ");
        do{
            System.out.println("1. Agregar productos al inventario.");
            System.out.println("2. Eliminar productos por nombre.");
            System.out.println("3. Modificar productos.");
            System.out.println("4. Buscar productos por nombre.");
            System.out.println("5. Mostrar todos los productos en el inventario.");
            System.out.println("6. Salir del programa.");
             opcion=sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                    case 1 -> { //agregar productos al inventario 
                        System.out.print("Ingrese el nombre del producto: ");
                        String nombre = sc.nextLine();
                        System.out.print("Ingrese el precio del producto: ");
                        double precio = sc.nextDouble();
                        System.out.print("Ingrese la cantidad del producto: ");
                        int cantidad = sc.nextInt();
                        productos.add(new Producto(nombre, precio, cantidad)); //agrega el nuevo producto a la lista
                        System.out.println();//imprime espacio
                      }
                    
                    case 2 -> { //eliminar productos por nombre 
                        System.out.print("Ingrese el nombre del producto a eliminar: ");
                        String eliminar = sc.nextLine();
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) { //busca el producto
                            if (productos.get(i).getNombre().equalsIgnoreCase(eliminar)) {
                                Producto productoEliminado = productos.remove(i); //elimina el producto
                                System.out.println("Producto eliminado: " + productoEliminado);
                                encontrado = true; //producto encontrado
                                break; //sale del bucle si encuentra el producto/
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto para eliminar."); //mensaje de error
                        }
                        System.out.println(); //imprime espacio
                      }
                    
                      case 3 -> { //modificar productos
                        System.out.print("Ingrese el nombre del producto a modificar: ");
                        String modificar = sc.nextLine();
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) { //busca el producto por su nombre
                            if (productos.get(i).getNombre().equalsIgnoreCase(modificar)) {
                                Producto productoModificar = productos.get(i); 

                                System.out.print("Ingrese el nuevo nombre: "); //modifica el nombre
                                String nuevoNombre = sc.nextLine();

                                System.out.print("Ingrese el nuevo precio: "); //modifica el precio
                                double nuevoPrecio = sc.nextDouble();

                                System.out.print("Ingrese la nueva cantidad: "); //modifica la cantidad
                                int nuevaCantidad = sc.nextInt();

                                //actualiza el producto
                                productoModificar.setNombre(nuevoNombre);
                                productoModificar.setPrecio(nuevoPrecio);
                                productoModificar.setCantidad(nuevaCantidad);
                                System.out.println("Producto modificado: " + productoModificar);
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto para modificar."); //mensaje de error
                        }
                        System.out.println();//imprime espacio
                      }
                      
                      case 4 -> { //buscar productos por nombre
                        System.out.print("Ingrese el nombre del producto a buscar: ");
                        String buscar = sc.nextLine(); 
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) {
                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto deseado.");
                        }
                        System.out.println();//imprime espacio
                      }
                      
                      case 5 -> { //mostrar todos los productos en el inventario
                        System.out.println("El numero de productos agregados es: " + productos.size());
                        for (int i = 0; i < productos.size(); i++) {
                            System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                        }
                        System.out.println();//imprime espacio
                      }
                      
                    case 6 -> //salir
                        System.out.println("Nos vemos, espero haya sido util :)");
                    default -> System.out.println("Opcion no valida, por favor intente de nuevo.");
                }
        }while(opcion !=6);
    }
}