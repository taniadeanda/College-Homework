package com.mycompany.ejercicio; //los ArrayLists pueden cambiar de tamaño automáticamente cuando se añaden o eliminan elementos
import java.util.ArrayList; //importar libreria de array list
import java.util.Collections;//clase collection: ordenar, buscar, copiar y llenar una colección
public class Ejercicio {

    public static void main(String[] args) {
        ArrayList <String> lista = new ArrayList<>(); // o ArrayList <String> lista = new ArrayList<String>();
        lista.add("Mexico");
        lista.add("Brasil");
        lista.add("Canada");
        System.out.println(lista); //imprime la lista en una sola linea
        lista.remove(1);  //elimina la posicion 1 con .remove
        lista.add(1, "Tailandia"); //agrega elemento en posicion 2, 1 porque comienza de 0
        lista.add(2, "Polonia"); //agrega elemento en posicion 3
        //eliminar elemento manualmente, agregar elemento en posicion 2 Y 3 TODO antes de ordenar, mostrar el elemento de la posición 4
        System.out.println("El elemento en la posición 4 es: " + lista.get(3)); //muestra el elemento de la posición 4 , (3) porque comienza en 0
        Collections.sort(lista); //sintaxis Collections.sort(nombrelista); ordena la lista
        /*
        for (int i = 0; i < lista.size(); i ++) { //lista.size() para ver tamano en array
            System.out.println(lista.get(i)); //para imprimir lista
        }
        */
        for (String pais:lista) //recorre la lista y lo imprime, for (Tipo de dato donde se guarda el dato, y lista
        System.out.println(pais);
    }
}
