package com.mycompany.ejemplotrycash;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejemplotrycash {

    public static void main(String[] args) {
        try{
        Scanner sc=new Scanner(System.in); //para que lea
        System.out.println("Bienvenido a la calculadora de divisiones. A continuacion escribe el numero que quieres dividir");
        int numero=sc.nextInt(); //lee el numero que ingresa el usuario
        System.out.println("Ahora escribe el divisor");
        int divisor=sc.nextInt(); //lee el divisor que ingresa el usuario y lo guarda en la variable divisor
        System.out.println("División"+numero/divisor);
        } catch (ArithmeticException e) { //se pone ArithmeticException para validar la operacion
        //} catch(InputMismatchException e){ //e es el nombre de la excepcion, InputMismatchException es para validar tipo de dato
        System.out.println("Error aritmetico "+ e); //se guarda en e el error
        }
       
    }
}
