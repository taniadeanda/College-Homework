package com.mycompany.act4pilas;
import java.util.Scanner;
public class Act4Pilas {
    
    public static void main(String[] args) {
    //Menu con opciones
    int option;
    //creacion del array con datos tipo entero y 10 elementos
    //int ArregloPila[] = new int[10]; //se puede usar 0
    Integer[] ArregloPila = new Integer[10]; //se puede usar null
    Scanner scanner = new Scanner(System.in);
        
    do {
        System.out.println("Bienvenido. Escribe la opción de tu agrado: \n 1.Push (apilar) \n 2.Peek (mostrar cima) y todo \n 3.Pop (desapilar) \n 4.Salir");
        
        while (!scanner.hasNextInt()){ //validación para permitir entrada de datos numericos unicamente
            System.out.println("Dato inválido. Ingresa solo datos numéricos");
            scanner.next();
        }
        option = scanner.nextInt();
        switch (option) {
            case 1: //agregar elemento al final, hacer validacion de que si esta llen@ no pueda agregar elementos
                if (lleno(ArregloPila)) { //==true
                    System.out.println("Tu arreglo ya esta lleno, no puedes agregar más elementos. Elimina elementos");
                    break;
                } else {
                System.out.println("Escribe el elemento que desees agregar. Recuerda que se agregan en pila");
                for (int i= 0; i<ArregloPila.length; i++){ //elimina el ultimo dato de la pila
                    if (ArregloPila[i] == null) { //si el elemento apunta a null, eliminalo, = null;?
                    //ArregloPila[i - 1] = scanner.nextInt(); //lee el elemento
                    ArregloPila[i] = scanner.nextInt(); //lee el elemento
                    System.out.println("Elemento agregado");
                    break;
                    }
                }
                } //cierra else
                break;
            case 2: //mostrar TODO?, validar que tenga elementos
                if (vacio(ArregloPila)) { //==false
                    System.out.println("Tu arreglo no tiene elementos. Agrega elementos");
                //break;
                } else {
                    int contador = 1;
                    for (int i = ArregloPila.length -1; i >=0; i--){ //lo recorre del ifnal al inicio
                        if (ArregloPila[i] != null){ //asi imprime solo los valores llenos
                            System.out.println("Tu elemento "+contador+" de tu arreglo es: "+ArregloPila[i]);
                            contador++;
                        }
                    }
                }//
                break;
            case 3: //eliminar ultimo elemento agregado, validar que tenga elementos para eliminar
                if (vacio(ArregloPila)) {
                    System.out.println("Tu arreglo no tiene elementos para eliminar");
                    break;
                } else {
                    for (int i= 0; i<ArregloPila.length; i++){ //elimina el ultimo dato de la pila
                       if (ArregloPila[i] == null) { //si el elemento apunta a null, eliminalo, = null;?
                           ArregloPila[i - 1] = null;
                           //break;  
                        } 
                    }//
                    System.out.println("Último elemento eliminado correctamente");
                }//
                break;
            default:
                System.out.println("Opcion inválida");
        } //cierra switch
     }while (option != 4); //???? caso 4 es para salir
        System.out.println("Gracias por usar el programa. Hasta pronto");
 //hacer metodos push, peek y pop    
    }
    
    
    //funciones public static fuera del main con parametros para que actuen con el arreglo
    public static boolean lleno(Integer[] ArregloPila){
          for (Integer elemento : ArregloPila) {
            if (elemento == null) {
                return false; // Si hay al menos un null, no está lleno
            }
        }
        return true; // Si ningún elemento es null, está lleno
    }
    
    public static boolean vacio(Integer[] ArregloPila){
               for (Integer elemento : ArregloPila) {
            if (elemento != null) {
                return false; // Si hay al menos un elemento no nulo, no está vacío
            }
        }
        return true; // Si todos los elementos son null, está vacío 
    }
    
      
    //boolean lleno = true, vacio = true;
    //para recorrer el arreglo y hacer validaciones de cuantos espacios estan ocupados
    /*boolean tamañoArreglo(Integer[] ArregloPila)) { //esta vacio
        for (int i = 0; i<ArregloPila.length; i++) {
            if (ArregloPila[i] != null) {
                return false; //si esta lleno
            } 
        }
        return true;
    }*/
    
           
}
