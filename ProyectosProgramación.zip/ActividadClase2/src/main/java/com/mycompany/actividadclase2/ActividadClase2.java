package com.mycompany.actividadclase2;
public class ActividadClase2 {

    public static void main(String[] args) {
        new TomaTurno().setVisible(true); //hacer visible ventana de toma turno clase
    }
}
