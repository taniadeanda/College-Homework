package com.mycompany.actividadclase2;
import javax.swing.JOptionPane;
//arreglar que esta imprimiendo NULL como primer elemento y como segundo el primero y asi, se retrasa

public class TomaTurno extends javax.swing.JFrame {
    //creacion del array list con 10 elementos
    String cola[] = new String [10];
    //elementos de la cola
    int frente = 0, fin = 0, turnos = 1; //capacidad es el numero de elementos de la lista
    //metodo estatico para insertar, sin parametros
    
    void insertar() {
        if (colaLlena()) {
            JOptionPane.showMessageDialog(null, "La cola esta llena");
            //System.out.println("La cola esta llena");
            /*cola[fin] = jNombre.getText(); //se inserta siempre al final (elemento del fin) y se extrae por enfrente (el primer elemento)
            //se necesitan 2 indices, uno para el inicio y otro para el final
            //Toma el nombre y lo acomoda al final de la fila
            jCola.append(cola[fin]+"Turno "+(fin+1)+"\n"); //hacer que lo muestre y que agregue el texto que
            fin++; //fin se va recorriendo
        */
        } else {
            //JOptionPane.showMessageDialog(null, "Cola llena"); //ventana emergente para mostrar mensaje de error
            cola[fin] = "Turno " + turnos + ": " + jNombre.getText(); //lee el elemento
            turnos++; //contador de turnos para ver donde va
            if ((fin + 1) % cola.length != frente) {
                fin = (fin + 1) % cola.length; //avanza circlarmente
            }
            //mostrar();
            }
        }
    
    void eliminar() { //se necesita verificar/validar que tenga un elemento que se puede eliminar
        if (colaVacia()) {
            System.out.println("Cola vacía. Agrega elementos para poder eliminar");
        } else {
            cola[fin] = null; //(""); //vacio o null
            frente = (frente + 1) % cola.length; //avanza circularmente
            /*if (frente == fin) { //si la cola esta vacia entonces
                frente = 0;
                fin = 0;
                turnos = 1; //reinicia el contador de turnos
            }*/
            mostrar();
        }
        /*if ((colaVacia() == false) && (frente<= cola.length)) { //si la cola vacia ESTA vacia (que SI haya un elemento para eliminar 
            //y que no se vaya a desbordar, que llegue hasta 10 (como limite que es el tamano)
            // si el frente es diferente del tamaño de la lista o de la posicion del final de la lista
            cola[frente] = ""; //se ira a la posicion de frente y la va a vaciar. eliminación FiFo
            frente ++; //avanza y se recorre
        //} //sino
        //else {
            if(frente == cola.length) { //si el frente esta llegando al limite (o sea en la ultima posicion) significa que vamos a reiniciar la cola
                //si frente esta al final
                System.out.println("Reiniciando cola");
                frente = 0; fin = 0; //ahora 
            }
        }
            else //{
                JOptionPane.showMessageDialog(null, "Cola vacía");
            //}
        //}
        */
    }
    
    void mostrar() { //validar que haya elementos
        jCola.setText(""); //limpia el area de texto para mostrar el nuevo elemento
        if (colaVacia()) { 
            JOptionPane.showMessageDialog(null, "Cola vacia. Agrega elementos");
        } else {
            //jCola.setText(""); //limpia el area de texto para mostrar el nuevo elemento
            int comodin = frente;
            //while (comodin != fin) {
            do {
            jCola.append(cola[comodin] + "\n");
            comodin = (comodin + 1) % cola.length;
            } while (comodin != fin);
            //}
        }
      
        /*else //sino esta vacia va a recorrer la lista y la va a imprimir con un for
            {
                for (int i=frente; i<fin; i++) { //MODIFICAR AQUI PORQUE IMPRIME 2 VECES
                    jCola.append(cola[i]+"Turno "+(i+1)+"\n"); //hacer que lo muestre y que agregue el texto que
                }
            }*/
    }
    
    boolean colaVacia(){
        /*if (frente == 0 && fin == 0) 
            return true;
        else
            return false;*/
        //return tamaño == 0;
        return frente == fin;
        //return fin == fin && cola[frente] == null;
    }
    
    boolean colaLlena(){
        /*if (fin == cola.length) // SI esta llena, porque el fin es la posicion del tamaño
            return true;
        else
            return false;*/
        //return tamaño == cola.length; //caapacidad o tamano del arreglo 10 elementos de cola
        return (fin + 1) % cola.length == frente; //condicion de la cola circular
        //return frente == fin && cola[frente] != null;
    }
            
    public TomaTurno() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jNombre = new javax.swing.JTextField();
        BotonAgregarTurno = new javax.swing.JButton();
        BotonMostrarTurno = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jCola = new javax.swing.JTextArea();
        BotonLiberarTurnos = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 204, 153));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 2, 24)); // NOI18N
        jLabel1.setText("Toma Turno");

        jLabel2.setText("Nombre:");

        BotonAgregarTurno.setText("Agregar Turno");
        BotonAgregarTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAgregarTurnoActionPerformed(evt);
            }
        });

        BotonMostrarTurno.setText("Mostrar Turnos");
        BotonMostrarTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonMostrarTurnoActionPerformed(evt);
            }
        });

        jCola.setColumns(20);
        jCola.setRows(5);
        jScrollPane1.setViewportView(jCola);

        BotonLiberarTurnos.setText("Liberar Turnos");
        BotonLiberarTurnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonLiberarTurnosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(BotonLiberarTurnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jNombre))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BotonMostrarTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonAgregarTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(44, 44, 44))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonAgregarTurno))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                    .addComponent(BotonMostrarTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(BotonLiberarTurnos)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonMostrarTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonMostrarTurnoActionPerformed
        jCola.setText(""); // o (null) para limpiar el campo de texto
        mostrar();
    }//GEN-LAST:event_BotonMostrarTurnoActionPerformed

    private void BotonLiberarTurnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonLiberarTurnosActionPerformed
        eliminar();
        //jCola.setText(""); // o (null) para limpiar el campo de texto
        //mostrar();
    }//GEN-LAST:event_BotonLiberarTurnosActionPerformed

    private void BotonAgregarTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAgregarTurnoActionPerformed
        insertar();
        //mostrar();
    }//GEN-LAST:event_BotonAgregarTurnoActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TomaTurno().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonAgregarTurno;
    private javax.swing.JButton BotonLiberarTurnos;
    private javax.swing.JButton BotonMostrarTurno;
    private javax.swing.JTextArea jCola;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField jNombre;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
