package com.mycompany.practica2;
//clases para importar archivos
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class VentanaPrincipal extends javax.swing.JFrame {
    //SINTAXIS Arreglo: tipo de dato, nombre del arreglo, corchetes, new y longitud
    ListaReproduccion musica [] = new ListaReproduccion[4];//musica=x en codigo de la maestra
    //variables que necesitamos
    int indice = 0; //para recorrer el arreglo
    String temporalmp3, temporalimagen; //comodin temporal
    
    //Constructor
    public VentanaPrincipal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Melodia = new javax.swing.JLabel();
        NombreMelodia = new javax.swing.JTextField();
        Interprete = new javax.swing.JLabel();
        CapturaArchivo = new javax.swing.JLabel();
        Imagen = new javax.swing.JLabel();
        Buscarmp3 = new javax.swing.JButton();
        BuscarImagen = new javax.swing.JButton();
        NombreInterprete = new javax.swing.JTextField();
        Insertar = new javax.swing.JButton();
        Musica = new javax.swing.JLabel();
        Visualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));

        Melodia.setText("Melodía");

        NombreMelodia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreMelodiaActionPerformed(evt);
            }
        });

        Interprete.setText("Intérprete");

        CapturaArchivo.setText("Capturar archivo mp3");

        Imagen.setText("Imagen");

        Buscarmp3.setText("Buscar mp3");
        Buscarmp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Buscarmp3ActionPerformed(evt);
            }
        });

        BuscarImagen.setText("Buscar imagen");
        BuscarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarImagenActionPerformed(evt);
            }
        });

        NombreInterprete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreInterpreteActionPerformed(evt);
            }
        });

        Insertar.setText("Insertar");
        Insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertarActionPerformed(evt);
            }
        });

        Musica.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        Musica.setText("MÚSICA");

        Visualizar.setText("Visualizar");
        Visualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Musica)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Insertar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(CapturaArchivo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                                .addComponent(Buscarmp3, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Melodia)
                                    .addComponent(Interprete))
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(NombreMelodia, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                                    .addComponent(NombreInterprete))))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(Imagen)
                            .addGap(213, 213, 213)
                            .addComponent(BuscarImagen)))
                    .addComponent(Visualizar))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Melodia)
                    .addComponent(NombreMelodia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Interprete)
                    .addComponent(NombreInterprete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CapturaArchivo)
                    .addComponent(Buscarmp3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BuscarImagen)
                    .addComponent(Imagen))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(Visualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Musica)
                    .addComponent(Insertar))
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void BuscarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarImagenActionPerformed
    //importar archivos, se crea un objeto de la clase JFileChooser (libreria)
        JFileChooser exploradorImagen = new JFileChooser();
        //agregar filtros para el buscador
        exploradorImagen.addChoosableFileFilter
        (new FileNameExtensionFilter("jpg", "png")); //jpg como descripcion y png como extension de audio
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile(); //comodin auxilidar tipo File para guardar el archivo que viene el ezplorador 
        temporalimagen = auxFile.getAbsolutePath();
        Imagen.setIcon((new javax.swing.ImageIcon(temporalimagen)));
    }//GEN-LAST:event_BuscarImagenActionPerformed

    private void NombreMelodiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreMelodiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreMelodiaActionPerformed

    private void NombreInterpreteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreInterpreteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreInterpreteActionPerformed

    private void InsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertarActionPerformed
    //omstanciar componentes y datos delarreglo
    //musica[indice] = new ListaReproduccion(
    //NombreMelodia.getText(), temporalmp3, temporalimagen, NombreInterprete.getText(), //JMelodia en codigo de la maesta, es el nombre de la variable
    //validar infica
        if(indice>=musica.length)
            System.out.println("Error, no se pueden agregar más datos");
        else
            {musica[indice] = 
                    new ListaReproduccion(NombreMelodia.getText(), temporalmp3, temporalimagen, NombreInterprete.getText());
            indice ++;
            }    
    }//GEN-LAST:event_InsertarActionPerformed

    private void Buscarmp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Buscarmp3ActionPerformed
        //importar archivos, se crea un objeto de la clase JFileChooser (libreria)
        JFileChooser explorador = new JFileChooser();
        //agregar filtros para el buscador
        explorador.addChoosableFileFilter
        (new FileNameExtensionFilter("mp3", "wav", "mpeg"));
        explorador.showOpenDialog(null);
        File auxFile = explorador.getSelectedFile(); //comodin auxilidar tipo File para guardar el archivo que viene el ezplorador 
        temporalmp3 = auxFile.getAbsolutePath(); //extrae la ruta absoluta del archivo
    }//GEN-LAST:event_Buscarmp3ActionPerformed

    private void VisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VisualizarActionPerformed
    //boton4 maestra
        for(int i=0; i<indice; i++)
        {
            System.out.println("Índice 1");
            System.out.println("Melodía"+musica[i].melodia); //variables donde se va a guardar NO SON LOS CAMPOS DEL DISEÑO
            System.out.println("Interprete"+musica[i].interprete);
            System.out.println("Ruta Música"+musica[i].rutaArchivo);
            System.out.println("Ruta Imagen"+musica[i].stringRutaImagen);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_VisualizarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscarImagen;
    private javax.swing.JButton Buscarmp3;
    private javax.swing.JLabel CapturaArchivo;
    private javax.swing.JLabel Imagen;
    private javax.swing.JButton Insertar;
    private javax.swing.JLabel Interprete;
    private javax.swing.JLabel Melodia;
    private javax.swing.JLabel Musica;
    private javax.swing.JTextField NombreInterprete;
    private javax.swing.JTextField NombreMelodia;
    private javax.swing.JButton Visualizar;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
