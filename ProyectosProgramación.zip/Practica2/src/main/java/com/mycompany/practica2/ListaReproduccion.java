package com.mycompany.practica2;
//clase lista de reproduccion
public class ListaReproduccion {
//Atributos del objeto
String melodia;    
String rutaArchivo;
String stringRutaImagen;
String interprete;
 //Arreglos de objetos: Es una matriz donde se almacenan clases-objetos (con atributos) y sus constructores para donde cada renglon es un objeto
//constructor: inicializa el objeto y sus atributos    
    public ListaReproduccion(String melodia, String rutaArchivo, String stringRutaImagen, String interprete) {
        this.melodia = melodia; //nombreMelodia maestra
        this.rutaArchivo = rutaArchivo;
        this.stringRutaImagen = stringRutaImagen;
        this.interprete = interprete;
    }


    //Getters y setters para acceder a atributos y modificarlos
       public String getInterprete() {
        return interprete;
    }

    public void setInterprete(String interprete) {
        this.interprete = interprete;
    }

    public String getMelodia() {
        return melodia;
    }

    public void setMelodia(String melodia) {
        this.melodia = melodia;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getStringRutaImagen() {
        return stringRutaImagen;
    }

    public void setStringRutaImagen(String stringRutaImagen) {
        this.stringRutaImagen = stringRutaImagen;
    }


 
}
