package com.mycompany.calculadora2;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.*;

public abstract class Calculadora2 extends JFrame implements ActionListener {
 
    public static void main(String[] args) {
        
        //1.para el marco de la ventana
        JFrame ventana = new JFrame("Calculadora de Tania"); //creacion de la ventana con su titulo
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //con este metodo se manda a llamar el metodo exit close, significa que aparece el boton de cerrar ventan
        ventana.setSize(600,800);  //propiedades de tamanoo en pixeles
        ventana.setBounds(100,100, 500, 200); //para que aparezca en un espacio de la pantalla. Ej al centro, a la orilla
        ventana.setLocationRelativeTo(null); //par que aparezca al centro
        ventana.setBackground(Color.BLACK);
        //2.Crear contenedor, todo lo que almacenara
        JPanel contenedor = new JPanel(); //JPanel es el CONTENEDOR: el marco que contiene elementos
        //contenedor.setBackground(Col); //color de fondo del contenedor
        
        //ImageIcon FondoPrograma = new ImagenIcon("C:\\Users\\Yes\\Downloads\\doggy.jpg"); // Asegúrate de poner la ruta correcta de tu imagen
        
        JLabel etiqueta = new JLabel("Valor 1: "); //se crea una etiqueta en el marco que imprime ingresa tu nombre
        JTextField entrada = new JTextField(10); //se declara entrada de texto con JTextField SE SUPONE QUE AQUI SE ESCRIBEN LOS NUMEROS QUE PRESIONA EN LA CALC.      
        JLabel etiqueta2 = new JLabel("Valor 2: "); //se crea una etiqueta en el marco que imprime ingresa tu nombre
        JTextField entrada2 = new JTextField(10); //se declara entrada de texto con JTextField SE SUPONE QUE AQUI SE ESCRIBEN LOS NUMEROS QUE PRESIONA EN LA CALC.      
        JLabel etiquetaResultado = new JLabel("="+""); //etiqueta vacia para imprimir el resultado
        //JTextField entrada = new JTextField(20); //se declara entrada de texto con JTextField
        contenedor.add(etiqueta); //add indica que se agregue la etiqueta y entrada en el contenedor, o sea en la ventana
        contenedor.add(entrada); //para que agregue los espacios para leer text
        //boton de SUMA
        JButton botonSuma = new JButton ("+"); //creacion del boton lo que queremos que imprima
        botonSuma.setBackground(Color.GREEN);
        contenedor.add(botonSuma); //el boton se agrega al contenedor NO A LA VENTANA
        //boton RESTA
        JButton botonResta = new JButton ("-"); //creacion del boton lo que queremos que imprima
        contenedor.add(botonResta); //el boton se agrega al contenedor
        botonResta.setBackground(Color.RED);
        //boton MULTIPLICACIÓN
        JButton botonMultiplicacion = new JButton ("x"); //creacion del boton lo que queremos que imprima
        contenedor.add(botonMultiplicacion); //el boton se agrega al contenedor
        botonMultiplicacion.setBackground(Color.YELLOW);
        //boton DIVISION
        JButton botonDivision = new JButton ("/"); //creacion del boton lo que queremos que imprima
        contenedor.add(botonDivision); //el boton se agrega al contenedor
        botonDivision.setBackground(Color.BLUE);
        
        contenedor.add(etiqueta2); //add indica que se agregue la etiqueta y entrada en el contenedor, o sea en la ventana
        contenedor.add(entrada2);
        contenedor.add(etiquetaResultado); //agredar los contenedores en orden que queremos que aparezcan
        ventana.add(contenedor); //diferencia de JFrame y JPanel?

        //Eventos acción boton SUMA
        botonSuma.addActionListener(new ActionListener() //para que haga algo el programa con el click
        {@Override
            public void actionPerformed(ActionEvent e) { //actionPerformed es el click que se le da al boton
            int resultadoSuma;
            resultadoSuma = Integer.parseInt(entrada.getText()) + Integer.parseInt(entrada2.getText()); //Interger.parseInt para convertir string a entero con get.Text toma el texto ingresado por el usuario
            //se tiene que convertir el entero nuevamente a string para que se pueda imprimir
            etiquetaResultado.setText("= "+(String.valueOf(resultadoSuma))); //la etiqueta ahora va a tener lo que el usuario escribio en entrada 
            }});       
    
        //Eventos acción boton RESTA
        botonResta.addActionListener(new ActionListener() //para que haga algo el programa con el click
        {@Override
            public void actionPerformed(ActionEvent e) { //actionPerformed es el click que se le da al boton
            int resultadoResta;
            resultadoResta = Integer.parseInt(entrada.getText()) - Integer.parseInt(entrada2.getText()); //Interger.parseInt para convertir string a entero con get.Text toma el texto ingresado por el usuario
            //se tiene que convertir el entero nuevamente a string para que se pueda imprimir
            etiquetaResultado.setText("= "+(String.valueOf(resultadoResta))); //la etiqueta ahora va a tener lo que el usuario escribio en entrada 
            }});
        
        //Eventos acción boton DIVISION
        botonMultiplicacion.addActionListener(new ActionListener() //para que haga algo el programa con el click
        {@Override
            public void actionPerformed(ActionEvent e) { //actionPerformed es el click que se le da al boton
            double resultadoMultiplicacion;
            resultadoMultiplicacion = (double)Integer.parseInt(entrada.getText()) * Integer.parseInt(entrada2.getText()); //Interger.parseInt para convertir string a entero con get.Text toma el texto ingresado por el usuario
            //se tiene que convertir el entero nuevamente a string para que se pueda imprimir
            etiquetaResultado.setText("= "+(String.valueOf(resultadoMultiplicacion))); //la etiqueta ahora va a tener lo que el usuario escribio en entrada 
            }});
        
        //Eventos acción boton DIVISION
        botonDivision.addActionListener(new ActionListener() //para que haga algo el programa con el click
        {@Override
            public void actionPerformed(ActionEvent e) { //actionPerformed es el click que se le da al boton
            double resultadoDivision;
            resultadoDivision = Double.parseDouble(entrada.getText()) / Double.parseDouble(entrada2.getText()); //Interger.parseInt para convertir string a entero con get.Text toma el texto ingresado por el usuario
            //resultadoDivision = (double)Integer.parseInt(entrada.getText()) / Integer.parseInt(entrada2.getText()); //Interger.parseInt para convertir string a entero con get.Text toma el texto ingresado por el usuario
            //se tiene que convertir el entero nuevamente a string para que se pueda imprimir
            etiquetaResultado.setText("= "+(String.valueOf(resultadoDivision))); //la etiqueta ahora va a tener lo que el usuario escribio en entrada 
            }});        
        
        ventana.setVisible(true); //para que la ventana sea visible y se aparezca

    }    
}
