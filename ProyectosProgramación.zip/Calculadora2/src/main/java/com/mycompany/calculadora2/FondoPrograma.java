package com.mycompany.calculadora2;
import javax.swing.*;
import java.awt.*;

public class FondoPrograma extends JPanel {
    private final Image imagen;

    public FondoPrograma(String rutaImagen) {
        this.imagen = new ImageIcon(rutaImagen).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
    }
}
