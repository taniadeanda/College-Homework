package com.mycompany.proyectofinal;
public class ProyectoFinal {

    public static void main(String[] args) {
        new Inicio().setVisible(true); //para que haga visible el JFrame 
    }
}
