/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Casa
 */
public class Nodo {
    String nombreMelodia;
    String interprete;
    String rutaArchivo;
    String rutaImagen;
    Nodo siguiente; //puntero

    public Nodo(String nombreMelodia, String interprete, String rutaArchivo, String rutaImagen, Nodo siguiente) {
        this.nombreMelodia = nombreMelodia;
        this.interprete = interprete;
        this.rutaArchivo = rutaArchivo;
        this.rutaImagen = rutaImagen;
        this.siguiente = siguiente;
    }

    public String getNombreMelodia() {
        return nombreMelodia;
    }

    public void setNombreMelodia(String nombreMelodia) {
        this.nombreMelodia = nombreMelodia;
    }

    public String getInterprete() {
        return interprete;
    }

    public void setInterprete(String interprete) {
        this.interprete = interprete;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}
