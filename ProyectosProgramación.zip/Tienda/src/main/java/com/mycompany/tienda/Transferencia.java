package com.mycompany.tienda;
//import com.mycompany.tienda.Pago;

public class Transferencia extends Pago {

    public Transferencia(String nombre, int numero, String fecha, int codigo, String correo, double monto) {
        super(nombre, numero, fecha, codigo, correo, monto);
    }
    
    @Override
    public void pedirDatos() {
        super.pedirDatos(); //extiende el metodo de clase padre para pedir datos
        System.out.println("Seleccionaste pagar con transferencia");
        super.validarNombre(); //valida el nombre con el metodo de la clase padre pago
        //sc.nextLine(); //limpiar buffer
        validarCLABE();
        sc.nextLine(); //limpiar buffer
        super.validarMonto(); //valida el monto ingresado
        sc.nextLine(); //limpiar buffer
        super.validarCorreo(); //validar correo electronico
    }
    
    @Override
    public void realizarPago() {   //se ejecutan las lineas de mas abajo
        
            System.out.println("El pago se hizo existosamente mediante transferencia");
            System.out.println("Nombre del titular: "+getNombre());
            System.out.println("Correo: "+getCorreo());
            System.out.println("Cantidad pagada: $"+getMonto());
        
    }
    
public boolean validarCLABE() {
    while (true) {
        System.out.println("Ingresa la CLABE de la tarjeta a la que deseas transferir (18 dígitos): ");
        String numeroStr = sc.next(); // Leer como String

        if (numeroStr != null && numeroStr.matches("\\d{18}")) { // Verificar que solo contiene dígitos y tiene exactamente 18 caracteres
            System.out.println("La CLABE de tarjeta es válida.");
            return true; // Sale del bucle si la CLABE es válida
        } else {
            System.out.println("La CLABE de tarjeta no es válida. Recuerda que debe contener 18 dígitos ÚNICAMENTE numéricos.");
        }
    }
}
 
    
    
}