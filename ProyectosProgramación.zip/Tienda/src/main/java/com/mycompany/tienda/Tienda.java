/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tienda;

import java.util.ArrayList;

/**
 *
 * @author Yes
 */
public class Tienda {

    public static void main(String[] args) {
       MenuInicio menuInicioVentana=new MenuInicio();
       menuInicioVentana.setVisible(true);
    }
    
}
