package com.mycompany.tienda;

import java.util.ArrayList;



public class Producto {  //clase producto
    //variables del programa
    private String nombre;//variable nombre 
    private double precio;// variable precio 
    private int cantidad;// variable cantidad 
    ArrayList<Producto> productos = new ArrayList<>();   //creacion de una instancia de nuestra clase
        ArrayList<Producto> cesta = new ArrayList<>();  //cesta para los productos del comprador
        
    //constructor de todas las variables de parámetros
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
   

    public String getNombre() {//get de la variable nombre
        return nombre;
    }

    public void setNombre(String nombre) {//set de la variable nombre
        this.nombre = nombre;
    }

    public double getPrecio() {//get de la variable precio
        return precio;
    }

    public void setPrecio(double precio) {//set de la variable precio
        this.precio = precio;
    }

    public int getCantidad() {//get de la variable cantidad
        return cantidad;
    }

    public void setCantidad(int cantidad) {//set de la variable cantidad
        this.cantidad = cantidad;
    }

    public String getcantidadStr() {
        return Integer.toString(cantidad); //devuelve la cantidad como String
    }
    
    public void reducirCantidad(int cantidadComprada) { //método para actualizar la cantidad después de una compra
        if (cantidadComprada <= cantidad) {
            cantidad -= cantidadComprada;  // Reducir la cantidad en el inventario
        } else {
            System.out.println("No hay suficiente stock disponible.");
        }
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nPrecio: ").append(precio);
        sb.append("\nCantidad: ").append(cantidad);
        return sb.toString();
    }
    
}
