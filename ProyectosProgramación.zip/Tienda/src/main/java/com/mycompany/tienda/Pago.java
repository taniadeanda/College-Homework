package com.mycompany.tienda;
import java.util.Scanner;
import java.util.InputMismatchException;


abstract class Pago { //clase
    Scanner sc = new Scanner(System.in); //instanciar para leer
    protected String nombre;
    protected int numero;
    protected String fecha;
    protected int codigo;
    protected String correo;
    protected double monto;
       
    public Pago(String nombre, int numero, String fecha, int codigo, String correo, double monto) {
        this.nombre = nombre;
        this.numero = numero;
        this.fecha = fecha;
        this.codigo = codigo;
        this.correo = correo;
        this.monto = monto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
    
    public void pedirDatos() { //pide datos al usuario
    }
    
    public void validarNombre(){
     while (true) { //bucle para que el usuario ingrese datos validos
            System.out.print("Ingrese el nombre: "); //modifica el nombre
            try {
                nombre = sc.nextLine(); //asigna nuevoNombre a lo que ingrese el usuario
                if (nombre.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                    break; //sale del bucle whie
                    } else {   
                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                }
            } catch(InputMismatchException error){ //sino cacha el error e imprime mensaje
            System.out.println(error.getMessage()); //imprime el dato de error
            }
        }
    }
    
    public boolean validarCorreo() {
        while (true) {
            System.out.println("Ingresa tu correo electrónico: ");
            correo = sc.next(); // Leer el correo como String
            if (correo.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) { // Validar el formato del correo
            //esta parte [\\w-\\.] permite letras, numeros, caracteres. + ya que se puede repetir lo anterior. @ ya que es obligatorio en el correo para que sea valido
            //[\\w-]+\\. representa el dominio gmail, hotmail, etc. luego [\\w-] permite letras, numeros en la parte final del dominio
            //{2,4} esto significa q debe haber de 2 a 4 caracteres en la parte final .com, .org y el $ marca el fin de la cadena
                System.out.println("El correo es válido.");
                return false; // Sale del bucle si el correo es válido
            } else {
                System.out.println("Formato de correo inválido. Inténtalo de nuevo.");
            }
        }
    } 
    
    public boolean validarMonto(){
        while(true){
            System.out.println("Ingresa el monto: ");
            try{   //valida la entrada de datos numericos
                monto = sc.nextDouble();
                return false; //sale del bucle si el dato ingresado es correcto
            } catch(InputMismatchException datoNum){ //e es el nombre de la excepcion, InputMismatchException es para validar tipo de dato
            System.out.println("Ingresa unicamente datos numéricos"+ datoNum); //se imprime el error junto con mensaje y no sale del bucle
            sc.nextLine(); //limpiar buffer
            }
        }    
    }
    
    @Override
    public String toString() { //para imprimir datos
        StringBuilder sb = new StringBuilder();
        sb.append("\nNombre: ").append(nombre);
        sb.append("\nNumero de la tarjeta: ").append(numero);
        sb.append("\nFecha de expiracion: ").append(fecha);
        sb.append("\nCVV: ").append(codigo);
        sb.append("\nCorreo: ").append(correo);
        return sb.toString();
    }
    
    public abstract void realizarPago();

}