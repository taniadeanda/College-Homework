package com.mycompany.tienda;

public class Paypal extends Pago {

    public Paypal(String correo, double monto) {
        super(null, 0, null, 0, correo, monto); //0 y null valores que no se usan en paypal
    }

   @Override
    public void pedirDatos() {
        super.pedirDatos(); //extiende el metodo de clase padre para pedir datos
        //Scanner sc = new Scanner(System.in);
        System.out.println("Seleccionaste pagar con paypal");
        super.validarNombre(); //valida el nombre
        //sc.nextLine(); //limpiar buffer
        super.validarCorreo();
        sc.nextLine(); //limpiar buffer
        super.validarMonto(); //valida el monto ingresado
        sc.nextLine(); //limpiar buffer
    }
    
    @Override
    public void realizarPago() {

            System.out.println("El pago se realizo exitosamente mediante Paypal");
            System.out.println("Nombre del titular: "+getNombre());
            System.out.println("Correo: "+getCorreo());
            System.out.println("Cantidad pagada: $"+getMonto());
 
    }    
}