package com.mycompany.tienda;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import java.util.ArrayList; // librería para el uso de los arraylist
import java.util.HashMap;
import java.util.InputMismatchException;  //libreria para utilizar el try-catch
import java.util.Map;

public class MenuInicio extends javax.swing.JFrame {
    private ArrayList<Producto> productos = new ArrayList<>();
    private ArrayList<Producto> cesta = new ArrayList<>();

    public MenuInicio() { //aqui lo que hace el programa
        initComponents();
        

        PanelMenuComprador.setVisible(false);
        PanelMenuVendedor.setVisible(false);
    }
Scanner sc = new Scanner(System.in);     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BotonComprador = new javax.swing.JButton();
        BotonVendedor = new javax.swing.JButton();
        PanelMenuComprador = new javax.swing.JPanel();
        EtiquetaMenuComprador = new javax.swing.JLabel();
        EtiquetaPresionaOp = new javax.swing.JLabel();
        BotonCompradorBuscarProductos = new javax.swing.JButton();
        BotonCompradorMostrarProductos = new javax.swing.JButton();
        BotonCompradorAgregarProductos = new javax.swing.JButton();
        BotonCompradorMostrarCarrito = new javax.swing.JButton();
        BotonCompradorPagar = new javax.swing.JButton();
        BotonCompradorSalir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        PanelMenuVendedor = new javax.swing.JPanel();
        EtiquetaBienvenidoMenuV = new javax.swing.JLabel();
        BotonVendedorAgregarProductos = new javax.swing.JButton();
        EtiquetaPresionaOpt = new javax.swing.JLabel();
        BotonVendedorEliminarProductos = new javax.swing.JButton();
        BotonVendedorModificarProductos = new javax.swing.JButton();
        BotonVendedorBuscarProductos = new javax.swing.JButton();
        BotonVendedorMostrarProductos = new javax.swing.JButton();
        BotonVendedorSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BotonComprador.setText("Comprador");
        BotonComprador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorActionPerformed(evt);
            }
        });

        BotonVendedor.setText("Vendedor");
        BotonVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorActionPerformed(evt);
            }
        });

        PanelMenuComprador.setBackground(new java.awt.Color(204, 255, 204));

        EtiquetaMenuComprador.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        EtiquetaMenuComprador.setText("Bienvenido al menú del comprador");

        EtiquetaPresionaOp.setText("Presiona la opción que desees");

        BotonCompradorBuscarProductos.setText("Buscar productos por nombre");
        BotonCompradorBuscarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorBuscarProductosActionPerformed(evt);
            }
        });

        BotonCompradorMostrarProductos.setText("Mostrar todos los productos");
        BotonCompradorMostrarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorMostrarProductosActionPerformed(evt);
            }
        });

        BotonCompradorAgregarProductos.setText("Agregar productos al carrito");
        BotonCompradorAgregarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorAgregarProductosActionPerformed(evt);
            }
        });

        BotonCompradorMostrarCarrito.setText("Mostrar carrito de compras");
        BotonCompradorMostrarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorMostrarCarritoActionPerformed(evt);
            }
        });

        BotonCompradorPagar.setText("Pagar");
        BotonCompradorPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCompradorPagarActionPerformed(evt);
            }
        });

        BotonCompradorSalir.setText("Salir");

        javax.swing.GroupLayout PanelMenuCompradorLayout = new javax.swing.GroupLayout(PanelMenuComprador);
        PanelMenuComprador.setLayout(PanelMenuCompradorLayout);
        PanelMenuCompradorLayout.setHorizontalGroup(
            PanelMenuCompradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuCompradorLayout.createSequentialGroup()
                .addGroup(PanelMenuCompradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMenuCompradorLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(EtiquetaMenuComprador))
                    .addGroup(PanelMenuCompradorLayout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(EtiquetaPresionaOp))
                    .addGroup(PanelMenuCompradorLayout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addGroup(PanelMenuCompradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BotonCompradorMostrarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonCompradorBuscarProductos)
                            .addComponent(BotonCompradorAgregarProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonCompradorMostrarCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonCompradorPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonCompradorSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        PanelMenuCompradorLayout.setVerticalGroup(
            PanelMenuCompradorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuCompradorLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(EtiquetaMenuComprador)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EtiquetaPresionaOp)
                .addGap(27, 27, 27)
                .addComponent(BotonCompradorBuscarProductos)
                .addGap(18, 18, 18)
                .addComponent(BotonCompradorMostrarProductos)
                .addGap(18, 18, 18)
                .addComponent(BotonCompradorAgregarProductos)
                .addGap(18, 18, 18)
                .addComponent(BotonCompradorMostrarCarrito)
                .addGap(18, 18, 18)
                .addComponent(BotonCompradorPagar)
                .addGap(18, 18, 18)
                .addComponent(BotonCompradorSalir)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Bienvenido a la tienda en línea");

        PanelMenuVendedor.setBackground(new java.awt.Color(204, 204, 255));

        EtiquetaBienvenidoMenuV.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        EtiquetaBienvenidoMenuV.setText("Bienvenido al menú del vendedor");

        BotonVendedorAgregarProductos.setText("Agregar productos al inventario");
        BotonVendedorAgregarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorAgregarProductosActionPerformed(evt);
            }
        });

        EtiquetaPresionaOpt.setText("Presiona la opción que desees");

        BotonVendedorEliminarProductos.setText("Eliminar productos por nombre");
        BotonVendedorEliminarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorEliminarProductosActionPerformed(evt);
            }
        });

        BotonVendedorModificarProductos.setText("Modificar productos");
        BotonVendedorModificarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorModificarProductosActionPerformed(evt);
            }
        });

        BotonVendedorBuscarProductos.setText("Buscar productos por nombre");
        BotonVendedorBuscarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorBuscarProductosActionPerformed(evt);
            }
        });

        BotonVendedorMostrarProductos.setText("Mostrar productos del inventario");
        BotonVendedorMostrarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorMostrarProductosActionPerformed(evt);
            }
        });

        BotonVendedorSalir.setText("Salir");
        BotonVendedorSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVendedorSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMenuVendedorLayout = new javax.swing.GroupLayout(PanelMenuVendedor);
        PanelMenuVendedor.setLayout(PanelMenuVendedorLayout);
        PanelMenuVendedorLayout.setHorizontalGroup(
            PanelMenuVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuVendedorLayout.createSequentialGroup()
                .addGroup(PanelMenuVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMenuVendedorLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(EtiquetaBienvenidoMenuV))
                    .addGroup(PanelMenuVendedorLayout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(EtiquetaPresionaOpt))
                    .addGroup(PanelMenuVendedorLayout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addGroup(PanelMenuVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(BotonVendedorEliminarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonVendedorAgregarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonVendedorModificarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonVendedorBuscarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BotonVendedorMostrarProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                            .addComponent(BotonVendedorSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(9, Short.MAX_VALUE))
        );
        PanelMenuVendedorLayout.setVerticalGroup(
            PanelMenuVendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuVendedorLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(EtiquetaBienvenidoMenuV)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EtiquetaPresionaOpt)
                .addGap(30, 30, 30)
                .addComponent(BotonVendedorAgregarProductos)
                .addGap(18, 18, 18)
                .addComponent(BotonVendedorEliminarProductos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BotonVendedorModificarProductos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BotonVendedorBuscarProductos)
                .addGap(18, 18, 18)
                .addComponent(BotonVendedorMostrarProductos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BotonVendedorSalir)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PanelMenuComprador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PanelMenuVendedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(46, 46, 46))
            .addGroup(layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(BotonComprador, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BotonVendedor)
                .addGap(197, 197, 197))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonComprador)
                    .addComponent(BotonVendedor))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PanelMenuComprador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PanelMenuVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void BotonCompradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorActionPerformed
        // TODO add your handling code here:
        BotonComprador.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                PanelMenuComprador.setVisible(!PanelMenuComprador.isVisible());
               PanelMenuVendedor.setVisible(false);
            }
        });
    }//GEN-LAST:event_BotonCompradorActionPerformed

    private void BotonCompradorBuscarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorBuscarProductosActionPerformed
        String buscar = ""; //declaracion de variable
                                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                                            try { //try catch para validar datos e imprimir mensaje de error
                                                System.out.print("Ingrese el nombre del producto a buscar: ");
                                                buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                                                if (buscar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                }
                                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) {
                                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto deseado.");
                                        }
                                        System.out.println();//imprime espacio
        
    }//GEN-LAST:event_BotonCompradorBuscarProductosActionPerformed

    private void BotonCompradorMostrarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorMostrarCarritoActionPerformed
        if(cesta.isEmpty()){ //si eseta vacia indica
                                            System.out.println("Cesta vacia, comience a agregar productos!!");
                                        }else{
                                            double total = 0;
                                            System.out.println("Resumen de la compra: ");
                                            Map<Producto, Integer> cantidadesSelec = new HashMap<>();
                                            for(Producto p : cesta){ //recorre el arraylist 
                                                System.out.println("Ingresa las piezas que quieres de cada producto. " +p.getNombre()+ ": ");
                                                int cantidadSelec = sc.nextInt();
                                                sc.nextLine();  //limpiar buffer
                                                cantidadesSelec.put(p, cantidadSelec);
                                            }
                                            for(Producto p : cesta){ //recorre el arraylist
                                                int cantidad = cantidadesSelec.get(p);
                                                double subtotal = p.getPrecio() * cantidad;
                                                total += subtotal;
                                                System.out.println(p.toString() + "\nPiezas seleccionadas: " +cantidad + "\nSubtotal: $" +subtotal);
                                            }
                                            System.out.println("Monto total a pagar: $" + total);
                                        }    
    }//GEN-LAST:event_BotonCompradorMostrarCarritoActionPerformed

    private void BotonVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorActionPerformed
        // TODO add your handling code here:
          BotonVendedor.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                PanelMenuVendedor.setVisible(!PanelMenuComprador.isVisible());
              PanelMenuComprador.setVisible(false);
            }
        });
    }//GEN-LAST:event_BotonVendedorActionPerformed

    private void BotonVendedorAgregarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorAgregarProductosActionPerformed
        // TODO add your handling code here:
         String nombre;
                                        double precio;
                                        int cantidad;    //declaramos nuestras variables
                                        while (true) {   //validamos nombre, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {   //validar entrada de datos
                                                System.out.print("Ingrese el nombre del producto: ");
                                                nombre = sc.nextLine();
                                                if (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) {   //valida que el nombre solo tenga letras
                                                    throw new IllegalArgumentException("El nombre solo puede tener letras!! ");
                                                }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                break; // Sale del ciclo si el nombre es valido
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage());   //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }

                                        while (true) {  //validamos precio, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {    //validar entrada de datos
                                                System.out.print("Ingrese el precio del producto: ");
                                                String precioStr = sc.nextLine();   //almacenamos el valor de precio en tipo string antes de convertirlo a double
                                                if (!precioStr.matches("\\d+(\\.\\d+)?")) {  // Validar que el precio sea un numero valido
                                                    throw new IllegalArgumentException("El precio solo puede tener numeros.");
                                                }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                precio = Double.parseDouble(precioStr);   //metodo estatico que convierte cadena de texto a tipo double(numerico)
                                                break; // Sale del ciclo si el precio es valido
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage());//sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }

                                        while (true) { //validamos cantidad, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try {  //validar entrada de datos
                                                System.out.print("Ingrese la cantidad del producto: ");
                                                String cantidadStr = sc.nextLine(); //almacenamos el valor de precio en tipo string antes de convertirlo a double
                                                if (!cantidadStr.matches("\\d+")) { // Validamos que la cantidad sea un numero entero válido
                                                    throw new IllegalArgumentException("La cantidad solo puede tener numeros enteros.");
                                                } //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                                                cantidad = Integer.parseInt(cantidadStr);
                                                break; // Sale del ciclo si la cantidad es válida
                                            } catch (IllegalArgumentException e) {
                                                System.out.println("Error!! " + e.getMessage()); //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                                            }
                                        }
                                        // se agrega el nuevo producto a la lista
                                        productos.add(new Producto(nombre, precio, cantidad));
                                        System.out.println("Producto agregado exitosamente.");
                                        System.out.println(); // Imprime espacio
    }//GEN-LAST:event_BotonVendedorAgregarProductosActionPerformed

    private void BotonVendedorMostrarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorMostrarProductosActionPerformed
        // TODO add your handling code here:
        if(productos.isEmpty())
            System.out.println("Aun no hay ningun producto, intente mas tarde");
            else{
                System.out.println("El numero de productos agregados es: " + productos.size());
                for (int i = 0; i < productos.size(); i++) {
                System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                }
            }
        System.out.println();//imprime espacio                            
    }//GEN-LAST:event_BotonVendedorMostrarProductosActionPerformed

    private void BotonVendedorEliminarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorEliminarProductosActionPerformed
        // TODO add your handling code here:
         String eliminar;
                                        while (true) { //validamos eliminar, bucle infinito hasta que se ingresen los tipos de datos correctos
                                            try { //validar entrada de datos
                                                System.out.print("Ingrese el nombre del producto que quieres eliminar: ");
                                                eliminar = sc.nextLine();
                                                if (!eliminar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { // Valida que el nombre solo contenga letras
                                                    throw new IllegalArgumentException("Error!! El nombre solo puede tener letras."); //excepción si el nombre no es válido
                                                }
                                                break; //si no lanza excepcion, el nombre es valido, el bucle se acaba
                                            } catch (IllegalArgumentException e) {
                                                System.out.println(e.getMessage()); //Se muestra el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar el producto

                                        for (int i = 0; i < productos.size(); i++) { //busca el producto
                                            if (productos.get(i).getNombre().equalsIgnoreCase(eliminar)) {
                                                Producto productoEliminado = productos.remove(i); //elimina el producto
                                                System.out.println("Producto eliminado " + productoEliminado);
                                                encontrado = true; //producto encontrado
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }

                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto para eliminar."); //mensaje de error
                                        }

                                        System.out.println(); //imprime espacio
    }//GEN-LAST:event_BotonVendedorEliminarProductosActionPerformed

    private void BotonVendedorModificarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorModificarProductosActionPerformed
        // TODO add your handling code here:
        String nuevoNombre = ""; //declaracion de variables
                                        double nuevoPrecio = 0;
                                        String modificar = "";
                                        int nuevaCantidad = 0;

                                        while (true){ //bucle para que el usuario escriba el nombre del producto hasta que ingrese tipo de dato correcto
                                            try {
                                                System.out.print("Ingrese el nombre del producto a modificar: ");
                                                modificar = sc.nextLine(); //reasignamos valor con lo que ingrese el usuario
                                                if (modificar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch con mensaje de error
                                                }
                                            } catch (InputMismatchException error) { //sino cacha el error
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) { //busca el producto por su nombre
                                            if (productos.get(i).getNombre().equalsIgnoreCase(modificar)) {
                                                Producto productoModificar = productos.get(i);

                                                while (true) { //bucle para que el usuario ingrese datos validos
                                                    try {
                                                        System.out.print("Ingrese el nuevo nombre: "); //modifica el nombre
                                                        nuevoNombre = sc.nextLine(); //asigna nuevoNombre a lo que ingrese el usuario
                                                        if (nuevoNombre.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                            break; //sale del bucle whie
                                                        } else {
                                                            throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                        }
                                                    } catch(InputMismatchException error){ //sino cacha el error e imprime mensaje
                                                        System.out.println(error.getMessage()); //imprime el dato de error
                                                    }
                                                }

                                                while (!encontrado) { //definimos encontrado como false anteriormente. Este ciclo hace que se repita hasta que el usuario ingrese dato correcto
                                                    try { //try catch para validar dato double
                                                        System.out.print("Ingrese el nuevo precio: "); //modifica el precio
                                                        nuevoPrecio = sc.nextDouble();
                                                        encontrado = true; //si ingresa un dato correcto encontrado se establece en true, sale del bucle while y se deja de repetir
                                                    } catch(InputMismatchException err) { //para detectar error de dato
                                                        System.out.println("Dato incorrecto. Ingresa numeros unicamente");
                                                        sc.next(); //limpia el buffer
                                                    }
                                                }

                                                encontrado = false;
                                                while (!encontrado){ //bucle while se ejecuta mientras !encontrado, true
                                                    try { //try catch para validar dato double
                                                        System.out.print("Ingrese la nueva cantidad: "); //modifica la cantidad
                                                        nuevaCantidad = sc.nextInt();
                                                        encontrado = true; //si ingresa un dato correcto sale del bucle while y se deja de repetir
                                                    } catch(InputMismatchException err) {
                                                        System.out.println("Dato incorrecto. Ingresa numeros unicamente");
                                                        sc.next(); //limpia el buffer
                                                    }
                                                }

                                                //actualiza el producto
                                                productoModificar.setNombre(nuevoNombre);
                                                productoModificar.setPrecio(nuevoPrecio);
                                                productoModificar.setCantidad(nuevaCantidad);
                                                System.out.println("Producto modificado: " + productoModificar);
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto a modificar."); //mensaje de error
                                        }
                                        System.out.println();//imprime espacio
    }//GEN-LAST:event_BotonVendedorModificarProductosActionPerformed

    private void BotonVendedorBuscarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorBuscarProductosActionPerformed
        // TODO add your handling code here:
        String buscar = ""; //declaracion de variable
                                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                                            try { //try catch para validar datos e imprimir mensaje de error
                                                System.out.print("Ingrese el nombre del producto a buscar: ");
                                                buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                                                if (buscar.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) { //si buscar contiene letras del abecedario
                                                    break; //sale del bucle whie
                                                } else {
                                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                                }
                                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                                                System.out.println(error.getMessage()); //imprime el mensaje de error
                                            }
                                        }

                                        boolean encontrado = false; //bandera para encontrar producto
                                        for (int i = 0; i < productos.size(); i++) {
                                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                                encontrado = true;
                                                break; //sale del bucle si encuentra el producto
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("No se encontro el producto deseado.");
                                        }
                                        System.out.println();//imprime espacio
    }//GEN-LAST:event_BotonVendedorBuscarProductosActionPerformed

    private void BotonVendedorSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVendedorSalirActionPerformed
        // TODO add your handling code here:
        System.out.println("Esto ha sido todo en el menu del vendedor:)");
    }//GEN-LAST:event_BotonVendedorSalirActionPerformed

    private void BotonCompradorMostrarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorMostrarProductosActionPerformed
        // TODO add your handling code here:
        if(productos.isEmpty()){
                                                System.out.println("Aun no hay ningun producto, intente mas tarde");
                                    }else{
                                        System.out.println("El numero de productos agregados es: " + productos.size());
                                            for (int i = 0; i < productos.size(); i++) {
                                                System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                                            }
                                        }
                                        System.out.println();//imprime espacio
    }//GEN-LAST:event_BotonCompradorMostrarProductosActionPerformed

    private void BotonCompradorAgregarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorAgregarProductosActionPerformed
System.out.print("Ingrese el nombre del producto que desea agregar a la cesta: ");
                                        String nombreProducto = sc.nextLine();
                                        boolean encontrado = false;
                                        for (Producto p : productos) {
                                            if (p.getNombre().equalsIgnoreCase(nombreProducto)) {
                                                cesta.add(p);
                                                System.out.println("Producto agregado a la cesta.");
                                                encontrado = true;
                                                break;
                                            }
                                        }
                                        if (!encontrado) {
                                            System.out.println("Producto no encontrado.");
                                        }        // TODO add your handling code here:
    }//GEN-LAST:event_BotonCompradorAgregarProductosActionPerformed

    private void BotonCompradorPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCompradorPagarActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_BotonCompradorPagarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuInicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonComprador;
    private javax.swing.JButton BotonCompradorAgregarProductos;
    private javax.swing.JButton BotonCompradorBuscarProductos;
    private javax.swing.JButton BotonCompradorMostrarCarrito;
    private javax.swing.JButton BotonCompradorMostrarProductos;
    private javax.swing.JButton BotonCompradorPagar;
    private javax.swing.JButton BotonCompradorSalir;
    private javax.swing.JButton BotonVendedor;
    private javax.swing.JButton BotonVendedorAgregarProductos;
    private javax.swing.JButton BotonVendedorBuscarProductos;
    private javax.swing.JButton BotonVendedorEliminarProductos;
    private javax.swing.JButton BotonVendedorModificarProductos;
    private javax.swing.JButton BotonVendedorMostrarProductos;
    private javax.swing.JButton BotonVendedorSalir;
    private javax.swing.JLabel EtiquetaBienvenidoMenuV;
    private javax.swing.JLabel EtiquetaMenuComprador;
    private javax.swing.JLabel EtiquetaPresionaOp;
    private javax.swing.JLabel EtiquetaPresionaOpt;
    private javax.swing.JPanel PanelMenuComprador;
    private javax.swing.JPanel PanelMenuVendedor;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
 
