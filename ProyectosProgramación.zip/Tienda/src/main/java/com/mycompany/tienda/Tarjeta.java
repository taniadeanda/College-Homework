package com.mycompany.tienda;
import com.mycompany.tienda.Pago;
import java.util.InputMismatchException;

public class Tarjeta extends Pago {
    
    public Tarjeta(String nombre, int numero, String fecha, int codigo, String correo, double monto) {
        super(nombre, numero, fecha, codigo, correo, monto);
    }

    /*Tarjeta(String juan_Perez, int i, String string, int i0, String juanperezexamplecom, double d) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
    
    @Override
    public void pedirDatos() {
        super.pedirDatos();
        System.out.println("Has seleccionado pagar con tarjeta");
        super.validarNombre(); //usa el metodo de la clase padre pago
        
        boolean numeroValido = false;  //indica si el numero es valido
        while(!numeroValido){ //pedir numero de la tarjeta
            System.out.println("Ingresa el numero de la tarjeta, son 16 digitos");
            String numeroStr = sc.nextLine();   //el numero se leera como String
            if(validarNumero(numeroStr)){
                this.numero = Integer.parseInt(numeroStr); //si el numero es valido, se convierte a entero
                numeroValido = true;
            }else{
                System.out.println("El numero que ingresaste es invalido");
            }
        }
        
        validarFecha();
        validarCodigo();  //para validar el codigo
        super.validarCorreo(); //validar correo electronico
        sc.nextLine(); //limpiar buffer
        super.validarMonto(); //valida el monto ingresado
        sc.nextLine(); //limpiar buffer
    }
    
    @Override
    public void realizarPago() {
               
                System.out.println("El pago se hizo exitosamente mediante tarjeta");
                System.out.println("Nombre del titular: "+getNombre());
                System.out.println("Correo: "+getCorreo());
                System.out.println("Cantidad pagada: $"+getMonto());
    }
    
    public boolean validarNumero(String numero){ //se valida que el numero de tarjeta tenga 16 digitos
        //String numeroStr = String.valueOf(getNumero()); //se convierte en cadena de texto para poder medir la longitud
        //return numero.length()==16; //con esto se verifica si la longitud de la cadena es 16 -- .length para cadenas de texto, no numericos //16 ya que es el numero que normalmente se piden para las compras con tarjeta
        if (numero != null && numero.matches("\\d{16}")) { //devuelve true si el número de tarjeta tiene 16 dígitos y false en caso contrario
            System.out.println("El numero de tarjeta es valido.");
        return true; 
        } else {
            System.out.println("El numero de tarjeta no es valido. Recuerda que debe contener 16 digitos UNICAMENTE numericos");
        return false; //necesita return el metodo ya que tiene parametros
        }
    }
    
    public boolean validarFecha(){ //la fecha debe estar en formato MM/AA (mes/año con dos ultimos digitos)
    
            boolean fechaValida = false;  //nos indica si la fecha es valida
        while(!fechaValida){
            System.out.println("Ingresa el mes de vencimiento (MM)");
            int mes = sc.nextInt();
            while(mes<1 || mes>12){
                System.out.println("Mes invalido. Vuelve a ingresarlo");
                mes = sc.nextInt();
            }
            System.out.println("Ingresa el anio de vencimiento (YYYY)");
            int anio = sc.nextInt();
            while(anio < 2000 || anio > 2099) { // Ajustar según un rango de años razonable
                System.out.println("Año invalido. Intentalo de nuevo.");
                anio = sc.nextInt();
            } 
            //Comprueba si la fecha es razonable    
            //Calendar.getInstance() este crea un objeto donde esta la fecha y hora actual, tomado de nuestro sistema
            java.util.Calendar fechaActual = java.util.Calendar.getInstance(); //fechaActual obtiene la informacion de la fecha y hora actual
            int mesActual = fechaActual.get(java.util.Calendar.MONTH) + 1; //se obtiene el mes actual pero al guardarse los meses se inicia desde la posicion 0-11
            //se le suma 1 para que los meses se acomoden al 1-12 para hacer la comparacion correctamente y no salga error 
            int anioActual = fechaActual.get(java.util.Calendar.YEAR); //obtiene el año actual y en formato completo por eso se le suma 2000 para validar
            if ((anio > anioActual) || (anio == anioActual && mes >= mesActual)) {
                System.out.println("La fecha es valida.");
                fechaValida = true;
            } else {
                System.out.println("La fecha de vencimiento no es valida. Intentalo de nuevo.");
            }
        //return(anio>anioActual) || (anio==anioActual && mes>= mesActual); //nos ayuda a saber si la fecha es valida a comparacion de la fecha actual       
        }
         return true;   
    }
    
    public boolean validarCodigo(){
         boolean codigoValido = false;
         while(!codigoValido){
             System.out.println("Ingresa el CVV: ");
             try{
                 codigo = sc.nextInt();
                 if(String.valueOf(codigo).length()==3){
                     System.out.println("El CVV es valido");
                     codigoValido = true;
                 }else{
                     System.out.println("El CVV debe tener unicamente 3 digitos");
                 }
             }catch(InputMismatchException datoNum){
                 System.out.println("Ingresa solo datos numericos: "+datoNum);
                 sc.nextLine(); //limpiar buffer
             }
         }
         return true;
    }
    
}