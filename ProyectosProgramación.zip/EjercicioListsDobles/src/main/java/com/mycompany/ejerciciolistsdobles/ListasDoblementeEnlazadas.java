
package com.mycompany.ejerciciolistsdobles;

public class ListasDoblementeEnlazadas {

    public static void main(String[] args) {
         new ListasDoblesEnlazadas().setVisible(true);
    }
}
