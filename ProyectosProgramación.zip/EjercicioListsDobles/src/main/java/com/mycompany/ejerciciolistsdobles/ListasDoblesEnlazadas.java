package com.mycompany.ejerciciolistsdobles;
import java.awt.HeadlessException;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
public class ListasDoblesEnlazadas extends javax.swing.JFrame {
    //FLECHAS ULTIMO Y PRIMER ELEMENTO LA IMAGEN NO SE AJUSTA
    public ListasDoblesEnlazadas() {
        initComponents();
    }
    Nodo actual = null, inicio = null, fin = null;     //Crear los punteros
    String temporalrutaimagen;    // Manejo de las rutas para cargar imagene

    boolean listaVacia(){     //Revisa si la lista esya vacio 
       return inicio==null;        //Forma corta de checar si esta vacia
    }
    
      void cargarImagen(){
        try{// Buscar imagenes
        JFileChooser exploradorImagen = new JFileChooser();
        exploradorImagen.addChoosableFileFilter(new FileNameExtensionFilter("imagen","jpg","png"));
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile();
        temporalrutaimagen =auxFile.getAbsolutePath();
        JFoto.setIcon(new javax.swing.ImageIcon(temporalrutaimagen));
        setImagenLabel(JFoto, temporalrutaimagen);
        }catch(NullPointerException e){
        JOptionPane.showMessageDialog(null,"Error al cargar el archivo de imagen");
        }
    }
    
    private void setImagenLabel(JLabel label, String imagePath){ // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(imagePath);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH));
    // Establecer la imagen redimensionada en el JLabel
    label.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    label.repaint();
    }
    
    void InsertarInicio(){
        Nodo nuevo = new Nodo( temporalrutaimagen ,cmtInterprete.getText(),null, null);
     if(listaVacia()){
         JOptionPane.showMessageDialog(null, "Primer Nodo Creado con Exito", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo;
         fin = nuevo;
     }else{         //Conecetar los enlaces al nuevo nodo 
         nuevo.setSiguiente(inicio);
         inicio.setAnterior(nuevo);
         JOptionPane.showMessageDialog(null, "Nuevo Nodo Insertado por el Inicio Exitosamente", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo; //Recorre el inico al nuevo nodo
       } 
    }
    
    void InsertarFinal(){
        Nodo nuevo = new Nodo( temporalrutaimagen ,cmtInterprete.getText(),null, null);
        if(listaVacia()){
         JOptionPane.showMessageDialog(null, "Primer Nodo Creado con Exito", "Info",JOptionPane.INFORMATION_MESSAGE);
         inicio = nuevo;
         fin = nuevo;
     }else{
         //Conecetar los enlaces al nuevo nodo 
         fin.setSiguiente(nuevo);
         nuevo.setAnterior(fin);
        JOptionPane.showMessageDialog(null, "Nuevo Nodo Insertado por el fin Exitosamente", "Info",JOptionPane.INFORMATION_MESSAGE);
        fin = nuevo; //Recorre el inico al nuevo nodo
       }  
    }
    
    void Insertar(int posicion){
        /*
        PSEUDOCODIGO
        1. Si (Esta vacio)
        1.1 Crear nodo en la posicion 1
        1.2 Mensaje de que se creo el nodo inicial
        2 SiNo
        2.1 Preguntar la posicion 
        2.2 Crear el nodo
        2.3 Declarar un auxiliar = inicio
        2.4 Con un MIENTRAS ( auxiliar =! null && contador < Posicion 
            mientras eso pasa se hace que auxiliar = auxiliar.siguiente
            y al contador le aumentamos contador ++
        MODIFICACION DE LOS ENLACES
        3 Si ( posicion == posicion && auxiliar != null)
        3.1 nuevo.anterior = auxiliar.anterior
        3.2 nuevo.siguiente = auxiliar
        3.3 auxiliar.anterior = Nuevo
        3.4 nuevo.anterior .sigiuiente = Nuevo
        */
    Nodo nuevo = new Nodo(temporalrutaimagen, cmtInterprete.getText(), null, null);
    if(listaVacia()){
        JOptionPane.showMessageDialog(null, "Primer Nodo Creado con Exito", "Info", JOptionPane.INFORMATION_MESSAGE);
        inicio = nuevo;
        fin = nuevo;
    } else {
       if(posicion == 0) {  // Insertar al principio
            nuevo.setSiguiente(inicio); // El siguiente de nuevo es el inicio actual
            inicio.setAnterior(nuevo);  // El anterior de inicio es el nuevo nodo
            inicio = nuevo;             // El nuevo nodo pasa a ser el inicio
        } else {
            Nodo Auxiliar = inicio;
            int contador = 0;
            // Navegar hasta la posición indicada
            while(Auxiliar != null && contador < posicion - 1) {
                Auxiliar = Auxiliar.getSiguiente();
                contador++;
            }
            if(Auxiliar == null) {  // Si llegamos al final de la lista sin encontrar la posición
                if(contador == posicion - 1) { // Si es la última posición, insertamos al final
                    nuevo.setAnterior(fin);  // El anterior del nuevo nodo es el fin
                    fin.setSiguiente(nuevo);  // El siguiente del fin es el nuevo nodo
                    fin = nuevo;              // El nuevo nodo pasa a ser el fin
                    JOptionPane.showMessageDialog(null, "Nodo agregado al final", "Info", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Posición fuera de rango", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                // Insertar en una posición válida dentro de la lista
                nuevo.setSiguiente(Auxiliar.getSiguiente());
                if(Auxiliar.getSiguiente() != null) {
                    Auxiliar.getSiguiente().setAnterior(nuevo); // Ajustar el anterior del nodo siguiente
                }
                Auxiliar.setSiguiente(nuevo);  // Enlazar el nodo Auxiliar con el nuevo nodo
                nuevo.setAnterior(Auxiliar);   // Enlazar el nuevo nodo con el nodo Auxiliar
                JOptionPane.showMessageDialog(null, "Nodo insertado correctamente", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}
/*FUNCION DE LA MAESTRA
    void Insetar(int posicion){
    Nodo auxiliar = inicio, nuevo; 
    int auziliarP=0;
    if(listaVacia(){
        nuevo = new Nodo(temporalrutaimagen, cmtInterprete.getText(), null, null);
        System.out.println("Primer nodo creado con exito");
    }else{
          nuevo = new Nodo(temporalrutaimagen, cmtInterprete.getText(), null, null);          
          while(auxiliar != null && auxiliarP < posicion){
          auxiliarP ++;
          auxiliar = auxilai.getSiguiente()
    }
         if(auxilairP == pocisicon){
             nuevo.setAnterios = auxiliar.getAnterio();
         nuevo.setSiguiente(auxiliar);
         auxiliar.setAnterior(Nuevo);
         Nuevo.getAnterior.setSiguiente(Nuevo);
        }
          System.out.println("Nodo insetado con exito");
      }
    }*/
    
    void Mostrar() { //no se USA porque tenemos actualizarVisor();
    if (listaVacia() || inicio == null) {  // Validar si la lista está vacía
        JOptionPane.showMessageDialog(null, "No hay elementos en la lista", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;  // Salir de la función si no hay elementos
    }
    Nodo chalan = inicio;
    int contador = 1;
    do {
        System.out.println("Posicion " + contador + ": " + chalan.getInterprete()); // Revisa el nombre correcto del método
        InterpreteVisual.setText( chalan.getInterprete());
        chalan = chalan.getSiguiente();
        contador++;
    } while (chalan != null && chalan != inicio);  // Validar `null` en listas no circulares
    }

    void EliminarTodo(){
        if(listaVacia()){
            JOptionPane.showMessageDialog(null, "No hay elementos en la lista", "Aviso", JOptionPane.WARNING_MESSAGE);      
        }else{  /* En lugar de recorer nodo por nodo simplemente asignamos null a inicio y al fin lo que vacia la lista 
            Se meustra un mensaje de confirmacion*/
            inicio = null;
            fin=null;
            actual = null; //para que funcione al imprimirse
            temporalrutaimagen = null; //para que se borre esa imagen
            JOptionPane.showMessageDialog(null, "Lista eliminada con exito", "Aviso", JOptionPane.WARNING_MESSAGE);
        }  
    }
  
    void eliminarPosicion(int position){
    try{
        // Validar que la lista no esté vacía y que la posición sea válida
        if(listaVacia()) throw new Exception("La lista está vacía");
        if(position < 0) throw new Exception("Posición inválida");
        // Si la posición es 0, eliminar el primer nodo
        if(position == 0){
            if(inicio == fin){
                listaVacia(); // Método para manejar la lista vacía
            }else{
                inicio = inicio.getSiguiente();
                inicio.setAnterior(null);
                JOptionPane.showMessageDialog(null, "Se ha eliminado el primer elemento", "Información", JOptionPane.INFORMATION_MESSAGE);
            }
        }else{
            // Recorrer la lista hasta la posición deseada o hasta el final de la lista
            Nodo temp = inicio;
            int count = 0;

            while(temp != null && count < position){
                temp = temp.getSiguiente();
                count++;
            }
            // Validar que la posición es válida
            if(temp == null){
                throw new Exception("Posición inválida");
            }else{
                // Eliminar el nodo en la posición específica
                if(temp == fin){
                    fin = fin.getAnterior();
                    fin.setSiguiente(null);
                    JOptionPane.showMessageDialog(null, "Se ha eliminado el último elemento", "Información", JOptionPane.INFORMATION_MESSAGE);
                }else{
                    temp.getAnterior().setSiguiente(temp.getSiguiente());
                    temp.getSiguiente().setAnterior(temp.getAnterior());
                    JOptionPane.showMessageDialog(null, "Se ha eliminado el elemento en la posición " + position, "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    void eliminarInicio(){
    try {
            if (listaVacia()) {
                System.out.println("Esta vacia");
                JOptionPane.showMessageDialog(null, "No se puede eliminar, la lista esta vacia", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
            if (inicio == fin) {// Si inicio y fin son lo mismo eliminamos el único nodo. HAY SOLO 1 ELEMENTO
                inicio = null;
                fin = null;
                JOptionPane.showMessageDialog(null, "Unico nodo eliminado", "Mensaje", JOptionPane.WARNING_MESSAGE);
            }  
            else { //Estamos en el 2 nodo
                inicio = inicio.getSiguiente(); //Traemos el enlace anterior y ponemos el enlace al siguiente que sea null
                inicio.getAnterior().setSiguiente(null);//Aqui el enlace anterior apuntara a null 
                inicio.setAnterior(null);
                System.out.println("Nodo eliminado");
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, "ERROR", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
        
    void eliminarFinal(){
    if (listaVacia()){
        JOptionPane.showMessageDialog(null, "La lista esta vacía. No hay nada para eliminar");
    }
    if (inicio.getSiguiente() == null) { // La lista solo tiene un nodo
        JOptionPane.showMessageDialog(null, "El único nodo se ha eliminado");
        inicio = null;
        fin = null;
    } else { 
        //Nodo chalan = fin; // Apuntamos al último nodo
        fin = fin.getAnterior(); // Actualizamos fin al nodo anterior
        fin.setSiguiente(null); // Desconectamos el último nodo
        JOptionPane.showMessageDialog(null, "El último nodo se ha eliminado");
        //System.out.println("El nodo " + chalan.getInterprete() + "se elimino"); //mensaje de confirmacion
    }
    }
    
void borrarInterprete(){ //
    if(listaVacia()) {
        JOptionPane.showMessageDialog(null, "no hay nodos");
    }else{
    try{
    String inter = JOptionPane.showInputDialog(this, "Ingrese el Intérprete a eliminar:");
    Nodo temp = inicio;
    while (temp != null) {
        if (temp.getInterprete().equalsIgnoreCase(inter)) { 
            if (temp == inicio && temp == fin) {
                inicio = null;
                fin = null;
            } 
            else if (temp == inicio) {
                inicio = inicio.getSiguiente();
                inicio.setAnterior(null);
            } 
            else if (temp == fin) {
                fin = fin.getAnterior();
                fin.setSiguiente(null);
            } 
            else {
                temp.getAnterior().setSiguiente(temp.getSiguiente());
                temp.getSiguiente().setAnterior(temp.getAnterior());
            }
            JOptionPane.showMessageDialog(null, "Interprete eliminado: " + inter);
            return;
        }
        temp = temp.getSiguiente();
    }
    }catch(NumberFormatException e){
    JOptionPane.showMessageDialog(this,"El interprete no se encontro");
    }
    }
}    
    
    public void buscar(){ //por artista, busqueda secuencial
    if (listaVacia()) {
        JOptionPane.showMessageDialog(null, "La lista está vacía");
        return;
    }
    String artista = JOptionPane.showInputDialog("¿Cuál es el nombre del artista?");  
    if (artista == null || artista.trim().isEmpty()) { //si tiene solo espacios o esta vacio
        JOptionPane.showMessageDialog(null, "No ingresaste ningún nombre");
        return;
    }
    artista = artista.trim(); // Elimina espacios al principio y al final
    Nodo chalan = inicio;
    int i = 1;
    boolean encontrado = false;
    String mensaje = "";
  do {
        if (artista.equalsIgnoreCase(chalan.getInterprete().trim())) {
            mensaje += "Artista: " + chalan.getInterprete() + "\n";
            //mensaje += "Canción: " + chalan.getMel() + "\n";
            mensaje += "Posición: " + i + "\n";
            encontrado = true;
            actual = chalan;
            actualizarVisor();
        }
        chalan = chalan.getSiguiente();
        i++;
       // if (chalan == inicio) break; //evistamos un bucle infinito
    }   while (chalan != inicio && chalan != null);
    if (encontrado) {
        JOptionPane.showMessageDialog(null, mensaje, "Artista Encontrado", JOptionPane.INFORMATION_MESSAGE);
        //actualizarVisor();
    } else {
        JOptionPane.showMessageDialog(null, "El artista no se encuentra en la lista");
    }
}
    
    void actualizarVisor(){ //NO FUNCIONA con un solo elemento, hacerla circular
        /*if (actual == inicio && actual.getSiguiente() == null) {// Lista con un solo elemento
            if (actual.getRutaarchivo() != null && !actual.getRutaarchivo().isEmpty()) {
                AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al JLabel usando la ruta del archivo del nodo actual
            } else {
                JFoto.setIcon(null); // Limpiar la imagen si la ruta del archivo es null o está vacía
            }
        }
        if (actual == null) {
            InterpreteVisual.setText(""); // Limpia el campo de texto si actual es null
            JFoto.setText("Tu lista está vacía. No hay nada para visualizar");
            cmtInterprete.setText(""); //limpia el campo donde escribimos
            InterpreteVisual.setText(""); // Limpia el campo de texto si actual es null
            JFoto.setIcon(null); //limpia la casilla de la imagen
        return;
        } //validacion para que funcione con las otras
        InterpreteVisual.setText(actual.getInterprete()); //limpiamos las ccasillas para que aparezcan en blanco
        JFoto.setText(""); //limpiar el texto de la foto
        if(listaVacia()) {
            JFoto.setText("Tu lista esta VACIA. No hay nada para visualizar");
            JFoto.setIcon(null); //limpia la casilla de la imagen
        } else { //no tiene tamaño porque es dinámica
            //JFoto.setIcon(new javax.swing.ImageIcon(actual.getRutaarchivo()));//insertar la ULTIMA(que se agrego) imagen en el cuadro de texto "imagen"
            JFoto.setText(""); // Limpiar el texto de la foto
            if (actual.getRutaarchivo()!=null && !actual.getRutaarchivo().isEmpty()) {
                AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al JLabel usando la ruta del archivo del nodo actual
            } else {
                JFoto.setIcon(null); // Limpia la imagen si la ruta del archivo es null o está vacía
            }
        }
        /*if (actual.getRutaarchivo() != null && !actual.getRutaarchivo().isEmpty()) {
            AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al JLabel usando la ruta del archivo del nodo actual
        } else {
            JFoto.setIcon(null); // Limpiar la imagen si la ruta del archivo es null o está vacía
        }*/
        // Actualizar los campos de texto con los valores del nodo actual
        cmtInterprete.setText(actual.interprete);
        //jMelodia.setText(actual.nombreMelodia);
        if (listaVacia()) {
        // Si la lista está vacía, mostrar un mensaje en el JLabel
        JFoto.setText("Lista Vacia");
        System.out.println("La lista está vacía, no hay nada para actualizar");
        } else {
            AjustarImagen(JFoto, actual.getRutaarchivo()); // Ajustar la imagen al tamaño del JLabel
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnArchivo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnInsertarInicio = new javax.swing.JButton();
        btnInsertarFinal = new javax.swing.JButton();
        btnInsetrarXPosicion = new javax.swing.JButton();
        btnBorrarInicio = new javax.swing.JButton();
        btnBorrarFinal = new javax.swing.JButton();
        btnBorrarElemnto = new javax.swing.JButton();
        btnMostra = new javax.swing.JButton();
        btnRetrocederTodo = new javax.swing.JButton();
        JFoto = new javax.swing.JLabel();
        btnRetroceder = new javax.swing.JButton();
        btnAvanzar = new javax.swing.JButton();
        btnAvanzarTodo = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        cmtInterprete = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        EliminarTodo = new javax.swing.JButton();
        Jlabel = new javax.swing.JLabel();
        InterpreteVisual = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BuscarArtista = new javax.swing.JButton();
        BorrarInterprete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        btnArchivo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnArchivo.setText("Buscar Archivo");
        btnArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchivoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel1.setText("Insertar Imagen");

        btnInsertarInicio.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnInsertarInicio.setText("Inicio");
        btnInsertarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarInicioActionPerformed(evt);
            }
        });

        btnInsertarFinal.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnInsertarFinal.setText("Final");
        btnInsertarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarFinalActionPerformed(evt);
            }
        });

        btnInsetrarXPosicion.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnInsetrarXPosicion.setText("Posicion");
        btnInsetrarXPosicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsetrarXPosicionActionPerformed(evt);
            }
        });

        btnBorrarInicio.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnBorrarInicio.setText("Inicio");
        btnBorrarInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarInicioActionPerformed(evt);
            }
        });

        btnBorrarFinal.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnBorrarFinal.setText("Final");
        btnBorrarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarFinalActionPerformed(evt);
            }
        });

        btnBorrarElemnto.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnBorrarElemnto.setText("Posición");
        btnBorrarElemnto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarElemntoActionPerformed(evt);
            }
        });

        btnMostra.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnMostra.setText("Visualizar toda la lista");
        btnMostra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostraActionPerformed(evt);
            }
        });

        btnRetrocederTodo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnRetrocederTodo.setText("|<");
        btnRetrocederTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederTodoActionPerformed(evt);
            }
        });

        JFoto.setBackground(new java.awt.Color(51, 255, 255));
        JFoto.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        JFoto.setText("FOTO");
        JFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnRetroceder.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnRetroceder.setText("<<");
        btnRetroceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetrocederActionPerformed(evt);
            }
        });

        btnAvanzar.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnAvanzar.setText(">>");
        btnAvanzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarActionPerformed(evt);
            }
        });

        btnAvanzarTodo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        btnAvanzarTodo.setText(">|");
        btnAvanzarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvanzarTodoActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        jLabel3.setText("Interprete");

        cmtInterprete.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        cmtInterprete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmtInterpreteActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 24)); // NOI18N
        jLabel4.setText("Insertar");

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 24)); // NOI18N
        jLabel5.setText("Borrar");

        EliminarTodo.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        EliminarTodo.setText("Todo");
        EliminarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarTodoActionPerformed(evt);
            }
        });

        Jlabel.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        Jlabel.setText("Nombre:");
        Jlabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        InterpreteVisual.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 18)); // NOI18N
        InterpreteVisual.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 24)); // NOI18N
        jLabel6.setText("Buscar");

        BuscarArtista.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BuscarArtista.setText("Por artista");
        BuscarArtista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarArtistaActionPerformed(evt);
            }
        });

        BorrarInterprete.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BorrarInterprete.setText("Interprete");
        BorrarInterprete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarInterpreteActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 24)); // NOI18N
        jLabel7.setText("DOBLEMENTE ENLAZADA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnBorrarInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnBorrarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(EliminarTodo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(27, 27, 27)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(btnArchivo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(cmtInterprete)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btnInsertarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnInsertarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnInsetrarXPosicion))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btnBorrarElemnto, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(BorrarInterprete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(0, 178, Short.MAX_VALUE))
                            .addComponent(BuscarArtista, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addGap(34, 34, 34)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JFoto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnMostra, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnRetrocederTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(btnRetroceder)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnAvanzar)
                                .addGap(31, 31, 31)
                                .addComponent(btnAvanzarTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Jlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(60, 60, 60)
                                .addComponent(InterpreteVisual, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(21, 21, 21))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cmtInterprete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnArchivo)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnInsertarInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnInsertarFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnInsetrarXPosicion))
                        .addGap(21, 21, 21)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBorrarFinal)
                            .addComponent(btnBorrarInicio)
                            .addComponent(EliminarTodo)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(InterpreteVisual, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnAvanzar)
                                    .addComponent(btnAvanzarTodo)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBorrarElemnto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Jlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BorrarInterprete))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRetrocederTodo)
                            .addComponent(btnRetroceder))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMostra, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BuscarArtista))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivoActionPerformed
       cargarImagen();
    }//GEN-LAST:event_btnArchivoActionPerformed

    private void btnRetrocederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederActionPerformed
        if (listaVacia()){
            JFoto.setText("Vacia");
            JOptionPane.showMessageDialog(null, "No hay elementos");
            return;
        }        //valida en caso de que no haya elementos
        if (actual == null) {
            actual = fin;
        }else if (actual.getAnterior()!=null){
            actual = actual.getAnterior();
    } else {
        System.out.println("Inicio de la lista");
        return;
        }
    actualizarVisor();
    InterpreteVisual.setText( actual.getInterprete());
    System.out.println("Intérprete: " + actual.getInterprete());

    }//GEN-LAST:event_btnRetrocederActionPerformed

    private void btnInsertarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarInicioActionPerformed
        //Llamamos la funcion de insettar por el inico 
        InsertarInicio();
    }//GEN-LAST:event_btnInsertarInicioActionPerformed

    private void btnMostraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostraActionPerformed
        //Mostrar(); //o visualizar???
        actualizarVisor(); //actualizar visor???
    }//GEN-LAST:event_btnMostraActionPerformed

    private void btnInsertarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarFinalActionPerformed
       //Llamamos la funcion para impleentar por el final
        InsertarFinal();
    }//GEN-LAST:event_btnInsertarFinalActionPerformed

    private void btnInsetrarXPosicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsetrarXPosicionActionPerformed
    int posicion = 0;
    boolean entradaValida = false;
    while (!entradaValida) {
    String entrada = JOptionPane.showInputDialog(null, "Introduce un número entero:", "Entrada de datos", JOptionPane.QUESTION_MESSAGE);
    if (entrada == null) { // Si el usuario cancela
        JOptionPane.showMessageDialog(null, "Operación cancelada.", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;
    }
    try {
        posicion = Integer.parseInt(entrada);
        if (posicion < 0) { // Verificación de número negativo
            JOptionPane.showMessageDialog(null, "La posición no puede ser menor a 0.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            entradaValida = true; // Solo salir si el número es válido y >= 0
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingresa un número valido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
        Insertar(posicion);   
    }//GEN-LAST:event_btnInsetrarXPosicionActionPerformed

    private void cmtInterpreteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmtInterpreteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmtInterpreteActionPerformed

    private void EliminarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarTodoActionPerformed
       // Mostrar();
        EliminarTodo();
        actualizarVisor();
     //   Mostrar();
    }//GEN-LAST:event_EliminarTodoActionPerformed

    private void btnRetrocederTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetrocederTodoActionPerformed
        if (listaVacia()){
            JFoto.setText("Vacia");
            JOptionPane.showMessageDialog(null, "No hay elementos");
            return;
        }        //valida en caso de que no haya elementos
        if (inicio != null){ //si solo hay un noto
            actual = inicio;
            //faltaria todo lo que conlleva actualizar visor
            InterpreteVisual.setText(actual.getInterprete()); //falta que actualice InterpreteVisual con nombre
            actualizarVisor();
        }
    }//GEN-LAST:event_btnRetrocederTodoActionPerformed

    private void btnAvanzarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarTodoActionPerformed
        if (listaVacia()){
            JFoto.setText("Vacia");
            JOptionPane.showMessageDialog(null, "No hay elementos");
            return;
        }        //valida en caso de que no haya elementos
        if (fin != null){ //si solo hay un noto
            actual = fin;
            //faltaria todo lo que conlleva actualizar visor
            actualizarVisor();
        } else {
            System.out.println("Error");
        }
    }//GEN-LAST:event_btnAvanzarTodoActionPerformed

    private void btnAvanzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvanzarActionPerformed
    if (listaVacia()) {
        System.out.println("Error: La lista está vacía, no se puede avanzar.");
        return;
    }
    if (actual == null) {
        actual = inicio;  // Si 'actual' es null, lo inicializamos en 'inicio'
    } else if (actual.getSiguiente()!= null){
        actual = actual.getSiguiente();
    }else {
        System.out.println("Fin de la lista");
        return; //ya no se avanza      
    }
    actualizarVisor();
    InterpreteVisual.setText( actual.getInterprete());
    System.out.println("Interprete: " + actual.getInterprete());
    }//GEN-LAST:event_btnAvanzarActionPerformed

    private void btnBorrarElemntoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarElemntoActionPerformed
    int posicion = 0;
    boolean entradaValida = false;
    while (!entradaValida) {
    String entrada = JOptionPane.showInputDialog(null, "Introduce un número entero:", "Entrada de datos", JOptionPane.QUESTION_MESSAGE);
    if (entrada == null) { // Si el usuario cancela
        JOptionPane.showMessageDialog(null, "Operación cancelada.", "Aviso", JOptionPane.WARNING_MESSAGE);
        return;
    }
    try {
        posicion = Integer.parseInt(entrada);

        if (posicion < 0) { // Verificación de número negativo
            JOptionPane.showMessageDialog(null, "La posición no puede ser menor a 0.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            entradaValida = true; // Solo salir si el número es válido y >= 0
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingresa un número valido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }    
        eliminarPosicion(posicion);
        actualizarVisor();
    }//GEN-LAST:event_btnBorrarElemntoActionPerformed

    private void btnBorrarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarFinalActionPerformed
        eliminarFinal();
        //actualizarVisor(); NO FUNCIONA
        actualizarVisor();
    }//GEN-LAST:event_btnBorrarFinalActionPerformed

    private void btnBorrarInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarInicioActionPerformed
        eliminarInicio();
        actualizarVisor();
    }//GEN-LAST:event_btnBorrarInicioActionPerformed

    private void BuscarArtistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarArtistaActionPerformed
        buscar();
    }//GEN-LAST:event_BuscarArtistaActionPerformed

    private void BorrarInterpreteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarInterpreteActionPerformed
    borrarInterprete();
    }//GEN-LAST:event_BorrarInterpreteActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListasDoblesEnlazadas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListasDoblesEnlazadas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListasDoblesEnlazadas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListasDoblesEnlazadas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListasDoblesEnlazadas().setVisible(true);
            }
        });
    }
     // Método para ajustar el tamaño de la imagen
void AjustarImagen(JLabel lbl, String ruta) {
    // Crear un ImageIcon a partir de la ruta de la imagen
    ImageIcon imagen = new ImageIcon(ruta);
    // Redimensionar la imagen para que se ajuste al tamaño del JLabel
    ImageIcon icono = new ImageIcon(
            imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_SMOOTH)
    );
    // Establecer la imagen redimensionada en el JLabel
    lbl.setIcon(icono);
    // Repintar el JLabel para asegurarse de que la imagen se actualice
    lbl.repaint();
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BorrarInterprete;
    private javax.swing.JButton BuscarArtista;
    private javax.swing.JButton EliminarTodo;
    private javax.swing.JLabel InterpreteVisual;
    private javax.swing.JLabel JFoto;
    private javax.swing.JLabel Jlabel;
    private javax.swing.JButton btnArchivo;
    private javax.swing.JButton btnAvanzar;
    private javax.swing.JButton btnAvanzarTodo;
    private javax.swing.JButton btnBorrarElemnto;
    private javax.swing.JButton btnBorrarFinal;
    private javax.swing.JButton btnBorrarInicio;
    private javax.swing.JButton btnInsertarFinal;
    private javax.swing.JButton btnInsertarInicio;
    private javax.swing.JButton btnInsetrarXPosicion;
    private javax.swing.JButton btnMostra;
    private javax.swing.JButton btnRetroceder;
    private javax.swing.JButton btnRetrocederTodo;
    private javax.swing.JTextField cmtInterprete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
