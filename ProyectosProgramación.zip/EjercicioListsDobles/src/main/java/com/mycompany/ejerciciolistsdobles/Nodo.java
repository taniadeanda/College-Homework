package com.mycompany.ejerciciolistsdobles;
public class Nodo {
    String rutaarchivo;
    String interprete;
    Nodo  anterior, siguiente; /* Puteros*/
    //Constructor
    public Nodo(String rutaarchivo, String interprete, Nodo anterior, Nodo siguiente) {    
        this.rutaarchivo = rutaarchivo;
        this.interprete = interprete;
        this.anterior = anterior;
        this.siguiente = siguiente;
    }
    
    public Nodo getAnterior() {
        return anterior;
    }

    //Getter and Setter
    public void setAnterior(Nodo anterior) {    
        this.anterior = anterior;
    }

    public String getRutaarchivo() {
        return rutaarchivo;
    }

    public void setRutaarchivo(String rutaarchivo) {
        this.rutaarchivo = rutaarchivo;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    public String getInterprete() {
        return interprete;
    }

    public void setInterprete(String interetre) {
        this.interprete = interetre;
    }
    
    
    
   
    
    
}
