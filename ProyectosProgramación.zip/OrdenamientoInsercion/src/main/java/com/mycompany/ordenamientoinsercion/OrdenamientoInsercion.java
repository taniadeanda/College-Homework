package com.mycompany.ordenamientoinsercion;
import java.util.Random;

public class OrdenamientoInsercion { //va acomodando en bloques
    public static void main(String[] args) {
        int[] numeros = new int[10]; //declaramos el array con 10 numeros 
        Random random = new Random();//generar el array con 5 aleatorios creando un objeto de tipo random
        
        for (int i=0; i<10; i++){ //agregar numeros aleatorios al arraylist
            numeros[i] = random.nextInt(101); //hace un recorrido con for y en cada posicion va agregando un numero aleatorio dependiendo de la funcion
        }
        
        System.out.print("Tu arreglo aleatorio es ");
        for (int i:numeros){ //imprimir el arreglo aleatroio, recorre el arreglo de i hasta numeros(arreglo)
            System.out.print(i+" "); //para que los imprima en una linea
        }
        
        System.out.println(" Tu arreglo ordenado es ");
        for (int i=1; i<10; i++){ //ordenar el arreglo con metodo de insercion SORT
            int comparar = numeros[i]; //asigna comparar en la posicion en la que se encuentra
            int anterior = i -1; //asigna anterior a la posicion anterior
            while(anterior>=0 && numeros[anterior]>comparar){ //mientras comparar sea mayor al siguiente entonces intercambialos
                numeros[anterior + 1]= numeros[anterior];//Desplaza el numero mayor ala izqueirda
                anterior--; //retrocede para ir comparando los demas anteriores
            }
            numeros[anterior + 1] = comparar;  //Se guarda en la posicion correcta para insertar comparar          
        }
        for(int i=0; i<10; i++) { //lo recorre y lo imprime
            System.out.print(numeros[i] + " ");
        }
    }
}
