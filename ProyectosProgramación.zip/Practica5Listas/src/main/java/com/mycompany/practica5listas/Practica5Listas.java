/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica5listas;
public class Practica5Listas {

    public static void main(String[] args) {
        new VisorMusica().setVisible(true);
    }
}
