package com.mycompany.practica5listas;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class VisorMusica extends javax.swing.JFrame {
    Nodo inicio, fin, actual=fin; //punteros para el inicio y fin de la lista, variables tipo nodo
    //asi nuestra visualizacion actual funciona como pila y se visualiza el ultimo elemento 
    String temporalmp3, temporalimagen; //comodin temporal de ruta para imagenes y archivos
    
    void cargarImagen(){
        try {
        JFileChooser exploradorImagen = new JFileChooser();  //importar archivos, se crea un objeto de la clase JFileChooser (libreria)
        exploradorImagen.addChoosableFileFilter         //agregar filtros para el buscado
        (new FileNameExtensionFilter("jpg", "png")); //jpg como descripcion y png como extension de audio
        exploradorImagen.showOpenDialog(null);
        File auxFile = exploradorImagen.getSelectedFile(); //comodin auxilidar tipo File para guardar el archivo que viene el ezplorador 
        temporalimagen = auxFile.getAbsolutePath();
        Imagen.setIcon((new javax.swing.ImageIcon(temporalimagen))); //donde esta el label de foto interprete
          } catch (NullPointerException e){
            JOptionPane.showMessageDialog(null, "Error al cargar el archivo");//(rootPane, Buscar);
        }
    }
    
    void cargarMelodia(){
        try { //para validar
        JFileChooser explorador = new JFileChooser();     //importar archivos, se crea un objeto de la clase JFileChooser (libreria
        explorador.addChoosableFileFilter         //agregar filtros para el buscador
        (new FileNameExtensionFilter("mp3", "wav", "mpeg"));
        explorador.showOpenDialog(null);
        File auxFile = explorador.getSelectedFile(); //comodin auxilidar tipo File para guardar el archivo que viene el ezplorador 
        temporalmp3 = auxFile.getAbsolutePath(); //extrae la ruta absoluta del archivo
        } catch (NullPointerException e){
            JOptionPane.showMessageDialog(null, "Error al cargar el archivo");//(rootPane, Buscar);
        }
    }

    //implementación de la lista
    
    boolean listaVacia(){ //validación
        return inicio == null; //si inicio es igual a null(vacio) entonces retorna true, de lo contrario false
    }
    
    void insertarFinal(){ //algoritmo LiFo
        String melodia = jMelodia.getText(); //tomar lo que hay en el cuadro de texto y asignarle a una variable string
        String nombre = Jnombre.getText();
        /*JFileChooser exploradorImagen = new JFileChooser();  //importar archivos, se crea un objeto de la clase JFileChooser (libreria)
        File auxFile = exploradorImagen.getSelectedFile(); //comodin auxilidar tipo File para guardar el archivo que viene el ezplorador 
        temporalimagen = auxFile.getAbsolutePath();
        String imagenRuta = temporalimagen;*/
        if(jMelodia.getText()==null || melodia.isEmpty() || Jnombre.getText()==null || nombre.isEmpty()){ //validacion. Mientras uno de los campos este vacio o sea null habra error
        //temporalimagen.isEmpty() || temporalimagen == null || auxFile.getAbsolutePath() == null || imagenRuta.isEmpty()){ //FALTA VALIDAR RUTA DE IMAGEN
            JOptionPane.showMessageDialog(null,"Uno de los campos esta vacio. Completa todos los datos requeridos de la cancion"); //mensaje de error
        } 
        else {
        //crear nuevo nodo con los datos de nombre, melodia
        //el nodo tiene 4 valores string nombre, melodia, direccion d foto, de imagenes y puntero siguiente 
        //si tenemos un solo nodo el inicio y fin se encuentran en el mismo
        Nodo nuevo = new Nodo(jMelodia.getText(), Jnombre.getText(), temporalmp3, temporalimagen,  null); //instanciacion de objeto nuevo en el constructor nuevo con n (nodo) y direccion de memoria null
        if(listaVacia()) {
            inicio = nuevo; //el inicio se recorre al siguiente nodo vacio
            inicio.setSiguiente(inicio);//para lista circular cuando solo hay un nodo, inicio es inicio
            fin = inicio; //para lista enlazada puntero de fin para no tener que usar while porque ya sabemos donde esta nuestro inicio y final y no tenemos que recorrerlo
            JOptionPane.showMessageDialog(null,"Canción creada exitosamente"); //nodo creado
            }
        else{
                /*Nodo chalan = fin; //auxiliar o comodin
                while(chalan.getSiguiente() != null) {//recorre la lista. puntero es el "siguiente". funciona para conectar los nodos
                chalan = chalan.getSiguiente(); //toma el valor que esta en puntero y avanza para recorrer la lista
                */
                fin.setSiguiente(nuevo);
                fin = nuevo;
                fin.setSiguiente(inicio); //el fin apunte a inicio
                JOptionPane.showMessageDialog(null,"Cancion insertada exitosamente"); //nodo insertado
                //}
                //chalan.setSiguiente(nuevo); //apunta la memoria del puntero de chalan al nuevo (nodo)
        }
    actual = fin;
        }
    }
    
    void Mostrar(){
        if(listaVacia()){
            //System.out.println("Tu lista esta vacía. No hay nada para imprimir. Agrega elementos");
            JOptionPane.showMessageDialog(null, "Tu lista esta vacía. No hay nada para imprimir. Agrega elementos");
        } else {
        Nodo chalan = inicio;
        int i = 1;
        //while(chalan!=null){ //mientras tenga elementos
        do {
            //System.out.println("Cancion #: "+i+" Interprete: "+chalan.getInterprete()+" Melodia: "+chalan.nombreMelodia); //imprimelo de chalan valor y su direccion de memoria
            JOptionPane.showMessageDialog(null, "Cancion #: "+i+" Interprete: "+chalan.getInterprete()+" Melodia: "+chalan.nombreMelodia);
            i++; //aumentar contador
            chalan = chalan.getSiguiente();
        } while(chalan!=inicio);
        }
    }
    
    void eliminar(){ //eliminar PRIMERO elemento cabeza
        if(listaVacia()) {
           //System.out.println("Tu lista esta vacía. No hay nada para eliminar. Agrega elementos");
           JOptionPane.showMessageDialog(null, "Tu lista esta vacía. No hay nada para eliminar. Agrega elementos");//
        } else { //no tiene tamaño porque es dinámica
            //System.out.println("Nodo eliminado "+inicio.interprete); //el nodo que se borra (el numero que quieres borrar o el dato)
            JOptionPane.showMessageDialog(null, "Nodo eliminado "+inicio.interprete); //
            inicio = inicio.getSiguiente(); //guarda la direccion de memoria que tiene cabeza para después mover su direccion de memoria a otro y que se recorra
            fin.setSiguiente(inicio); //para vincular el fin apuntando a direccion de nodo inicio y que sea circular
            Imagen.setIcon(new javax.swing.ImageIcon(inicio.RutaImagen));//insertar la imagen en el cuadro de texto "imagen"
        }
        actual=fin;
    }
    
    void actualizarVisor(){
        Jnombre.setText(actual.interprete); //limpiamos las ccasillas para que aparezcan en blanco
        jMelodia.setText(actual.nombreMelodia);
        if(listaVacia()) {
            Imagen.setText("Tu lista esta vacía. No hay nada para visualizar");
            //JOptionPane.showMessageDialog(null, "Tu lista esta vacía. No hay nada para visualizar");//
        } else { //no tiene tamaño porque es dinámica
        Imagen.setIcon(new javax.swing.ImageIcon(actual.getRutaImagen()));//insertar la ULTIMA(que se agrego) imagen en el cuadro de texto "imagen"
        }
    }
    
    /*static void eliminarUltimo(){
        Nodo chalan = cabeza; //auxiliar o comodin que guarda la direccion de memoria
        if(listaVacia()) {
           System.out.println("Tu lista esta vacía. No hay nada en el ultimo elemento para eliminar. Agrega elementos");
        } //no tiene tamaño porque es dinámica   
        else if (chalan.getPuntero()== null){ //si la direccion de memoria de chalan esta vacia se sale
                    break;
                } else { //si no eliminalo
                    //chalan.puntero
                    chalan.siguiente = null; //para eliminarlo asignale la direccion de memoria null
                    System.out.println("Último nodo eliminado "+cabeza.getValor()); //get valor da los DATOS del nodo, como el número
                    //mostrar que se haya eliminado??
                    System.out.println("Tu nueva lista con el ultimo nodo eliminado es ");
                    mostrar();
                }   
            }
        } //el chalan debe de estar antes del fin
    }*/
    
  /* void eliminarUltimo() {
    if (listaVacia()) {
        System.out.println("Tu lista está vacía. No hay nada en el último elemento para eliminar. Agrega elementos");
    } else if (cabeza.getPuntero() == null) { // Si solo hay un elemento
        System.out.println("El único nodo " + cabeza.getValor() + " ha sido eliminado");
        cabeza = null; // La lista se vacía
    } else {
        Nodo chalan = cabeza;
        while (chalan.getPuntero().getPuntero() != null) { // Encuentra el penúltimo nodo
            chalan = chalan.getPuntero();
        }
        System.out.println("Último nodo " + chalan.getPuntero().getValor() + " eliminado");
        chalan.setPuntero(null); // Elimina el último nodo
        /*System.out.println("Tu nueva lista con el último nodo eliminado es:");
        //mostrar();
    }
}*/
    
    /*static void buscar(int n){ //imprimir en que posicion esta y asignar parametros del numero que va a buscar
        Nodo chalan = inicio; //auxiliar o comodin que guarda la direccion de memoria
        int posicion = 1;
        //WHILE???
        if(listaVacia()) {
           System.out.println("Tu lista esta vacía. No hay nada para buscar. Agrega elementos");
        } else { //no tiene tamaño porque es dinámica    
            //COMO LO RECORRERÍA???
            //chalan = chalan.getPuntero(); //get siguiente. le asigna la direccion de memoria(puntero) a chalan
            while(chalan!=null){//}
            //chalan.getValor() = n;
            if(chalan.getValor() == n){ //si ese nodo es igual a 89 escribir el numero de posicion
                System.out.println("Tu nodo "+chalan.getValor()+" esta en la posicion "+posicion); //imprime en que posición esta el nodo que se quiere mostrar
                return; //porque cualquier funcion con parametros tiene que retornar algo
            } else { //pase al siguiente nodo y aumente la posicion
                posicion++;
                chalan = chalan.getPuntero();  //que avance???
            }    
        }
            System.out.println("El valor no se encontro en la lista o no existe");
        }
    }*/
    
    public VisorMusica() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        AdjuntarImagen = new javax.swing.JButton();
        AdjuntarMelodia = new javax.swing.JButton();
        Buscar = new javax.swing.JButton();
        Borrar = new javax.swing.JButton();
        Insertar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Imagen = new javax.swing.JLabel();
        RetrocederTodo = new javax.swing.JButton();
        Retroceder = new javax.swing.JButton();
        Avanzar = new javax.swing.JButton();
        AvanzarFinal = new javax.swing.JButton();
        jMelodia = new javax.swing.JTextField();
        Jnombre = new javax.swing.JTextField();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("jMenu3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setText("Nombre Interprete");

        jLabel2.setText("Melodía");

        AdjuntarImagen.setText("Adjuntar");
        AdjuntarImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdjuntarImagenActionPerformed(evt);
            }
        });

        AdjuntarMelodia.setText("Adjuntar");
        AdjuntarMelodia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdjuntarMelodiaActionPerformed(evt);
            }
        });

        Buscar.setText("Buscar");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        Borrar.setText("Borrar");
        Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarActionPerformed(evt);
            }
        });

        Insertar.setText("Insertar");
        Insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertarActionPerformed(evt);
            }
        });

        jLabel3.setText("Archivo de imagen");

        jLabel4.setText("Archivo Melodía");

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        Imagen.setText("Foto Interprete");

        RetrocederTodo.setText("<<");
        RetrocederTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetrocederTodoActionPerformed(evt);
            }
        });

        Retroceder.setText("<");
        Retroceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetrocederActionPerformed(evt);
            }
        });

        Avanzar.setText(">");
        Avanzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvanzarActionPerformed(evt);
            }
        });

        AvanzarFinal.setText(">>");
        AvanzarFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvanzarFinalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(RetrocederTodo)
                        .addGap(47, 47, 47)
                        .addComponent(Retroceder)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 202, Short.MAX_VALUE)
                        .addComponent(Avanzar)
                        .addGap(65, 65, 65)
                        .addComponent(AvanzarFinal)
                        .addGap(26, 26, 26))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(Imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RetrocederTodo)
                    .addComponent(Retroceder)
                    .addComponent(Avanzar)
                    .addComponent(AvanzarFinal))
                .addGap(18, 18, 18))
        );

        jMelodia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMelodiaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(336, 336, 336)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Insertar)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(Jnombre, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                                        .addComponent(jMelodia))
                                    .addComponent(Buscar))))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Borrar)
                                .addContainerGap(48, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(AdjuntarMelodia)
                                    .addComponent(AdjuntarImagen))
                                .addGap(0, 0, Short.MAX_VALUE))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(AdjuntarImagen)
                    .addComponent(Jnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jMelodia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(AdjuntarMelodia))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Buscar)
                    .addComponent(Borrar)
                    .addComponent(Insertar))
                .addGap(30, 30, 30)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AvanzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvanzarActionPerformed
        actual=actual.getSiguiente(); //avanzamos a siguiente
        actualizarVisor();// TODO add your handling code here:
        System.out.println("Interprete"+actual.getInterprete()); //para validar que este funcionando correctamente y llevar un control
    }//GEN-LAST:event_AvanzarActionPerformed

    private void AdjuntarImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdjuntarImagenActionPerformed
        cargarImagen();
    }//GEN-LAST:event_AdjuntarImagenActionPerformed

    private void InsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertarActionPerformed
        insertarFinal();
        Mostrar();
    }//GEN-LAST:event_InsertarActionPerformed

    private void BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarActionPerformed
        eliminar();
        actualizarVisor();
        //falta poner que se elimine de pantalla
    }//GEN-LAST:event_BorrarActionPerformed

    private void AdjuntarMelodiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdjuntarMelodiaActionPerformed
        cargarMelodia();        // TODO add your handling code here:
    }//GEN-LAST:event_AdjuntarMelodiaActionPerformed

    private void jMelodiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMelodiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMelodiaActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        //buscar();
        JOptionPane.showMessageDialog(null, "Has descubierto funciones de la version premium. No esta disponible por el momento");
    }//GEN-LAST:event_BuscarActionPerformed

    private void RetrocederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetrocederActionPerformed
        Nodo chalan = inicio; //nodo auxiliar que apunta al primer nodo de la lista
        while (chalan.getSiguiente() != actual) { //bucle para recorrer la lista
            //se ejecuta mientras chalan.getSiguiente sea diferente al actual, osea que sigue avanzando hasta
            //que encuentra el nodo que tiene como sigiente nodo el ´actual´
            chalan = chalan.getSiguiente(); //chalan va avanzando un nodo
            //asi hasta que avanza todo y recorre
        }
        actual = chalan; //se actualiza el nodo actual
        actualizarVisor();// TODO add your handling code here:
        System.out.println("Interprete"+actual.getInterprete()); //para validar que este funcionando correctamente y llevar un control
    }//GEN-LAST:event_RetrocederActionPerformed

    private void AvanzarFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvanzarFinalActionPerformed
        actual = inicio;//el nodo actual se asigna al nodo de inicio
        while (actual.getSiguiente() != inicio) { //mientras que el nodo actual.getsiguiente sea diferente
        //del nodo inicio, actual va a avanzar 1 nodo hasta que sea nodo inicio 
            actual = actual.getSiguiente();
        } //hasta que actual.getsiguiente sea igual a inicio
        actualizarVisor();
        System.out.println("Interprete"+actual.getInterprete()); //para validar que este funcionando correctamente y llevar un control
    }//GEN-LAST:event_AvanzarFinalActionPerformed

    private void RetrocederTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetrocederTodoActionPerformed
        actual=fin.getSiguiente(); //avanzamos a siguiente
        actualizarVisor();// TODO add your handling code here:
        System.out.println("Interprete"+actual.getInterprete()); //para validar que este funcionando correctamente y llevar un control
           // TODO add your handling code here:
    }//GEN-LAST:event_RetrocederTodoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VisorMusica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VisorMusica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VisorMusica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VisorMusica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
//     AdjuntarImagenditor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VisorMusica().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdjuntarImagen;
    private javax.swing.JButton AdjuntarMelodia;
    private javax.swing.JButton Avanzar;
    private javax.swing.JButton AvanzarFinal;
    private javax.swing.JButton Borrar;
    private javax.swing.JButton Buscar;
    private javax.swing.JLabel Imagen;
    private javax.swing.JButton Insertar;
    private javax.swing.JTextField Jnombre;
    private javax.swing.JButton Retroceder;
    private javax.swing.JButton RetrocederTodo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jMelodia;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
