package com.mycompany.practica5listas;

public class Nodo {

    public Nodo(String nombreMelodia, String interprete, String rutaArchivo, String RutaImagen, Nodo Siguiente) {
        this.nombreMelodia = nombreMelodia;
        this.interprete = interprete;
        this.rutaArchivo = rutaArchivo;
        this.RutaImagen = RutaImagen;
        this.Siguiente = Siguiente;
    }

    public String getNombreMelodia() {
        return nombreMelodia;
    }

    public void setNombreMelodia(String nombreMelodia) {
        this.nombreMelodia = nombreMelodia;
    }

    public String getInterprete() {
        return interprete;
    }

    public void setInterprete(String interprete) {
        this.interprete = interprete;
    }

    public String getRutaArchivo() {
        return rutaArchivo;
    }

    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public String getRutaImagen() {
        return RutaImagen;
    }

    public void setRutaImagen(String RutaImagen) {
        this.RutaImagen = RutaImagen;
    }

    public Nodo getSiguiente() {
        return Siguiente;
    }

    public void setSiguiente(Nodo Siguiente) {
        this.Siguiente = Siguiente;
    }
    
    String nombreMelodia;
    String interprete;
    String rutaArchivo;
    String RutaImagen;
    Nodo Siguiente; //puntero
}
