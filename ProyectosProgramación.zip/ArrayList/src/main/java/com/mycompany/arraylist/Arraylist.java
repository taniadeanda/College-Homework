package com.mycompany.arraylist;
import java.util.ArrayList; //importar para el uso de arraylist
import java.util.Scanner; //para leer datos

public class Arraylist { //crear un arraylist para almacenar objetos de tipo coche
    //definir variables estaticas
    static Scanner sc = new Scanner(System.in); //se crea una instancia para leer
    static ArrayList<Coche> coches = new ArrayList<>(); //para que pueda almacenar los objetos tipo coche
     
    public static void main(String[] args) { //mandar a llamar metods
        leerCoches();
        System.out.println("Coches agregados ");
        mostrarCoches();
    }
    
    public static void leerCoches(){
    String matricula;
    String marca; 
    String modelo;
    int km;
    Coche aux; //variable para almacenar temporalmente
    int N; //para numero de coches que el usuario quiera ingresar
    
    do { //para que pregunte al usuario los coches que desea agregar
        System.out.println("Bienvenido. Ingresa el numero de coches que te gustaría");
        N = sc.nextInt();
    } while (N < 0);
    sc.nextLine();
    
    for (int i = 1; i <= N; i++){     //para pedir infomacion de cada coche
        System.out.println("Estas ingresando datos al coche " + i);
        System.out.println("Ingresa el numero de tu matricula: "); //va ingresando dados
        matricula = sc.nextLine(); //lee dato
        System.out.println("Ingresa el modelo: ");
        modelo = sc.nextLine();
        System.out.println("Ingresa el nombre de tu marca: ");
        marca = sc.nextLine();
        System.out.println("Ingresa el numero de tu kilometraje: ");
        km = sc.nextInt();
        sc.nextLine(); //limpia el buffer del teclado despues de leer un numero
        
        aux = new Coche(); //crear una instancia del objeto coche
        aux.setMatricula(matricula); //asignar los valores de las variables locales al objeto coche
        aux.setMarca(marca);
        aux.setModelo(modelo);
        aux.setKm(km);
        
        coches.add(aux); //anadir el objeto referenciado al final de la lisa de coche
        
    }
  }
    
    public static void mostrarCoches(){ //metodo para imprimir los coches
        for (Coche coche : coches) { //recorre la lista y todos sus elementos
            System.out.println(coche); //llama al metodo del objeto coche y su representacion en String
        }
    }
    
}
