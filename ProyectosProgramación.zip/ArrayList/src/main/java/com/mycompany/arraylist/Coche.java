package com.mycompany.arraylist;

public class Coche { //atributos de la clase coche
    private String matricula; 
    private String modelo;
    private String marca;
    private int km; 
    
//agregar getters y setters para acceder a los atributos, seleccionar, click derecho y automatico geter y setter
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    } 
    
    @Override //para elegir como queremos que se muestre la informacion
    public String toString() {
        StringBuilder sb = new StringBuilder();
            sb.append("\nMatricula: ").append(matricula);
            sb.append("\nModelo: ").append(modelo);
            sb.append("\nMarca: ").append(marca);
            sb.append("\nKilometraje: ").append(km);
            return sb.toString();
    }
    
}
