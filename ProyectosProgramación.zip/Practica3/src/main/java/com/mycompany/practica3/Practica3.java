package com.mycompany.practica3;
import java.util.*; //importa todas las librerias

public class Practica3 { //hacer menu para ingresar o imprimir datos
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); //se crea una instancia para leer
        Persona [] arregloPersonas = new Persona [10]; //declaracion del arreglo, nombre de la clase, nombre del arreglo, nombre de la clase y extensión
        //System.out.println("Bienvenido a fichas de alumnos. A continuación elige la opción que desees: \n 1.Dar de alta registros \n 2.Mostrar registros");
        for (int i = 0; i < 3; i ++) {
            arregloPersonas [i] = new Persona(); //posicion 0, i va incrementando
            System.out.println("Escribe a continuación tu nombre completo");
            arregloPersonas [i].setNombre (sc.nextLine()); //pide el nombre al usuario
            System.out.println("Escribe a continuación tu edad");
            arregloPersonas [i].setEdad(sc.nextInt()); //pide la edad al usuario
            sc.nextLine();
        }

        for (int i = 0; i < 10; i ++) {    //mostrar datos
            System.out.println("nombre" + i + " " + arregloPersonas[i].getNombre());
            System.out.println("nombre" + i + " " + arregloPersonas[i].getEdad());
        
        }
 
        /* 
        //FichaAlumno fichaCUALTOS = new FichaAlumno ("nombreaqui", "fechaaqui", "nacionalidadaqui"); //instanciacion de objeto nombreDeClase, nombreObjeto = new NombreConstructor();
        FichaAlumno fichaCUALTOS = new FichaAlumno ("","",""); //constructor vacio
        //Clase       Objeto        constructor
        //que se tiene que llamar igual que el doc
        System.out.println("Bienvenido a tu ficha de alumno. Escribe a continuación tu nombre completo");
        fichaCUALTOS.setnombrecompleto(sc.nextLine()); //lee el nombre completo y modifica su valor con setnombre en el objeto fichaCualtos
        System.out.println("Ahora escribe a continuación la fecha con formato MM/DD/YYYY");
        fichaCUALTOS.setfecha(sc.nextLine()); //objeto fichaCUALTOS, con metodo setfecha lo guarda (edita) y metodo sc.nexline lo lee
        System.out.println("Por último, escribe a continuación tu nacionalidad");
        fichaCUALTOS.setnacionalidad(sc.nextLine());
        sc.close();  // Close Scanner
        fichaCUALTOS.imprimir_ficha();*/
    }
}
