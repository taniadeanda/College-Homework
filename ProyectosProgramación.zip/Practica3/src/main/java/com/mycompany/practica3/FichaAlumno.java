package com.mycompany.practica3;

public class FichaAlumno { //creación de la clase y sus atributos (variables)
    private String nombrecompleto, fecha, nacionalidad;
    //creacion de constructores, con el mismo nombre uno tiene parametros y el otro esta vacio SOBRECARGA DE CONSTRUCTORES
    public FichaAlumno(String nombrecompleto, String fecha, String nacionalidad) { //definicion del constructor, es como una funcion que va a usar las variables
    this.nombrecompleto = nombrecompleto; //diferencia del parámetro y valor (atributos)
    this.fecha = fecha;
    this.nacionalidad = nacionalidad;
    }
    
    public FichaAlumno() { // creación del constructor vacio
    this.nombrecompleto = ""; //diferencia del parámetro y valor (atributos)
    this.fecha = "";
    this.nacionalidad = "";
    }
    
    public void setnombrecompleto(String nombrecompleto) { 
        this.nombrecompleto  = nombrecompleto;
    }
    
    public String getnombrecompleto() { 
        return this.nombrecompleto;
    }
    
    public void setfecha(String fecha) { 
        this.fecha  = fecha;
    }
    
    public String getfecha() { 
        return this.fecha;
    }
    
    public void setnacionalidad(String nacionalidad) { 
        this.nacionalidad  = nacionalidad;
    }
    
    public String getnacionalidad() { 
        return this.nacionalidad;
    }
    
    void imprimir_ficha(){
        System.out.println("Tus datos son: \n - Nombre Completo: "+nombrecompleto+"\n - Fecha: "+fecha+"\n - Nacionalidad: "+nacionalidad);
    }
    
}
