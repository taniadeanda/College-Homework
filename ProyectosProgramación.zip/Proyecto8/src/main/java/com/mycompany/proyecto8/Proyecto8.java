
//HERENCIA: Característica de la programación orientada a objetos. Permite que una clase (hijo) herede atributos y metodos de otra clase (clase padre) ayudando a reutilizar código.
//Al crear la clase se pone la palabra extends y el nombre de la clase padre. Sintexis class<NmbreClaseHijo>
package com.mycompany.proyecto8;
public class Proyecto8 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
