package com.mycompany.ordenamientoshell;

import java.util.Random;

public class OrdenamientoShell {
    public static void main(String[] args) {
        int n = 10; //tamaño del arreglo
        int[] numeros = new int[10]; //declaramos el array con 10 numeros 
        Random random = new Random();//generar el array con 5 aleatorios creando un objeto de tipo random
        
        for (int i=0; i<10; i++){ //agregar numeros aleatorios al arraylist
            numeros[i] = random.nextInt(101); //hace un recorrido con for y en cada posicion va agregando un numero aleatorio dependiendo de la funcion
        }
        
        System.out.print("Tu arreglo aleatorio es ");
        for (int i:numeros){ //imprimir el arreglo aleatroio, recorre el arreglo de i hasta numeros(arreglo)
            System.out.print(i+" "); //para que los imprima en una linea
        }
        
        int brinco = n / 2; // va a dividir el arreglo entre 2
        while (brinco > 0) { //si es mayor a 0 entonces... (si esta en 0 significa que se redujeron los intervalos hasta ordenar TODO)
            for (int i = brinco; i < n; i++) { //ira brincando de uno en uno
                int temp = numeros[i]; //variable temporal para cuando intercambie numeros
                int j = i; //para mover elementos y grupos a la izquierda -->
                while (j >= brinco && numeros[j - brinco] > temp) { //comparamos el valor actual (temp) con brinco posiciones atras (numeros [j-brinco])
                    //j >= brinco para no salirnos del arreglo
                    //numeros[j - brinco] > temp si el numero es mayor lo movemos adelante
                    numeros[j] = numeros[j - brinco]; //el numero mayor lo pone a la derecha
                    j -= brinco; //retrocede para seguir comparando posiciones
                }
                numeros[j] = temp; //lo pone en la posicion correcta
            }
            brinco /= 2; // Reducir el intervalo y que vaya dividiendo grupos mas pequeños
        }

        System.out.println("Tu arreglo aleatorio ordenado con Shell es:");         // Imprimir el arreglo ordenado
        for (int num : numeros) {
            System.out.print(num + " "); //para que imprima en la misma linea
        }
        
    }
}
