package com.mycompany.practice2;
public class Practice2 {

    public static void main(String[] args) {
        new VentanaPrincipal().setVisible(true);
    }
}
