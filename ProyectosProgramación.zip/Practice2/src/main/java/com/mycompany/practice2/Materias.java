package com.mycompany.practice2;

public class Materias {
//1.Atributos
String nombre; 
int matematicas, calculo, quimica; 
float promedio;
//2.Insertar contructor, this, setters y getters
   public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getMatematicas() {
        return matematicas;
    }

    public void setMatematicas(int matematicas) {
        this.matematicas = matematicas;
    }

    public int getCalculo() {
        return calculo;
    }

    public void setCalculo(int calculo) {
        this.calculo = calculo;
    }

    public int getQuimica() {
        return quimica;
    }

    public void setQuimica(int quimica) {
        this.quimica = quimica;
    }

    public float getPromedio() {
        return promedio;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }

    public Materias(String nombre, int matematicas, int calculo, int quimica, float promedio) {
        this.nombre = nombre;
        this.matematicas = matematicas;
        this.calculo = calculo;
        this.quimica = quimica;
        this.promedio = promedio;
    }

//3. hacer arraylist de objetos
    
    
   
}
