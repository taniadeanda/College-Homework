package com.mycompany.trycash;
import java.util.Scanner;
import java.util.InputMismatchException;
public class Trycash {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, bandera=1; //crear objeto para el teclado
        //do {
        while(bandera==1) { //bucle para que siempre le pida el dato al usuario hasta que sea correcto, tambien se puede con do-while
        try {
            System.out.println("Ingresa un número");
            numero = sc.nextInt();
            int cuadrado = numero*numero;
            System.out.println("El cuadrado del valor ingresado es: "+ cuadrado);
            bandera=0;
        }
        //catch (Exception e){ //para leer archivos
        //System.out.println(e.getMessage()); //hacemos que valide con try catch por si el usuario ingresa un caracter diferente de numero
        catch(InputMismatchException ex){ //ex es el nombre de la excepcion
            System.out.println("Dato incorrecto. Porfavor ingresa un dato numerico"+ex); //hace que el usuario lea dato  
            sc.next(); //limpiar el buffer
        }
        //while(bandera==1);
      }
    }
}
