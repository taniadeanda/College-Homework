package com.mycompany.arraylistt;
import java.util.ArrayList; // librería para el uso de los arraylist
import java.util.InputMismatchException;  //libreria para utilizar el try-catch
import java.util.Scanner; // librería para leer datos desde el teclado

public class ArraylistT {   //clase
    static int opcion;    //opcion de tipo entero para el menu
     
    public static void main(String[] args) {    //nuestro main
        Scanner sc = new Scanner(System.in);     
        ArrayList<Producto> productos = new ArrayList<>();   //creacion de una instancia de nuestra clase

        System.out.println("Hola, hola bienvenid@ al programa de inventario de producto para comenzar "
                + "introduce el numero segun la accion que se desea hacer: ");   //mensaje inicial 
        do{   //ciclo do-while para que nos siga apareciendo el menu a menos que seleccionemos salir
            try{  //validar entrada de datos en nuestro menu
            System.out.println("1. Agregar productos al inventario.");
            System.out.println("2. Eliminar productos por nombre.");
            System.out.println("3. Modificar productos.");
            System.out.println("4. Buscar productos por nombre.");
            System.out.println("5. Mostrar todos los productos en el inventario.");
            System.out.println("6. Salir del programa.");
             opcion=sc.nextInt();   //lee nuestra opcion ingresada
            sc.nextLine();
            }catch(InputMismatchException ex){  //cerrar try y poner la excepcion
                System.out.println("Solo puedes ingresar numeros, NO letras ni otro caracter "+ex);
                sc.next();    //en caso de que se ingrese una letra-caracter aparece ese mensaje y regresa al menu
            }
                
                switch (opcion) {  //casos dependiendo de la opcion elegida
                    case 1 -> {   //caso 1 agregar productos al inventario
                    String nombre;
                    double precio;
                    int cantidad;    //declaramos nuestras variables
                        while (true) {   //validamos nombre, bucle infinito hasta que se ingresen los tipos de datos correctos
                            try {   //validar entrada de datos
                            System.out.print("Ingrese el nombre del producto: ");
                            nombre = sc.nextLine();
                            if (!nombre.matches("[a-zA-Z ]+")) {   //valida que el nombre solo tenga letras
                            throw new IllegalArgumentException("El nombre solo puede tener letras!! "); 
                            }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                            break; // Sale del ciclo si el nombre es valido
                            } catch (IllegalArgumentException e) {
                                System.out.println("Error!! " + e.getMessage());   //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                            }
                        }

                        while (true) {  //validamos precio, bucle infinito hasta que se ingresen los tipos de datos correctos
                            try {    //validar entrada de datos
                            System.out.print("Ingrese el precio del producto: ");
                            String precioStr = sc.nextLine();   //almacenamos el valor de precio en tipo string antes de convertirlo a double
                            if (!precioStr.matches("\\d+(\\.\\d+)?")) {  // Validar que el precio sea un numero valido
                            throw new IllegalArgumentException("El precio solo puede tener números.");
                            }  //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                            precio = Double.parseDouble(precioStr);   //metodo estatico que convierte cadena de texto a tipo double(numerico)
                            break; // Sale del ciclo si el precio es valido
                            } catch (IllegalArgumentException e) {
                                System.out.println("Error!! " + e.getMessage());//sirve para devolver el detalle del mensaje de error que esta en la excepcion
                            }
                        }

                        while (true) { //validamos cantidad, bucle infinito hasta que se ingresen los tipos de datos correctos
                            try {  //validar entrada de datos
                            System.out.print("Ingrese la cantidad del producto: ");
                            String cantidadStr = sc.nextLine(); //almacenamos el valor de precio en tipo string antes de convertirlo a double
                            if (!cantidadStr.matches("\\d+")) { // Validamos que la cantidad sea un numero entero válido
                            throw new IllegalArgumentException("La cantidad solo puede tener numeros enteros.");
                            } //throw es una palabra clave para lanzar una excepcion, new es para instanciar una clase excepcion, en este caso es IllegalArgumentException
                            cantidad = Integer.parseInt(cantidadStr);
                            break; // Sale del ciclo si la cantidad es válida
                            } catch (IllegalArgumentException e) { 
                            System.out.println("Error!! " + e.getMessage()); //sirve para devolver el detalle del mensaje de error que esta en la excepcion
                            }
                        }
                    // se agrega el nuevo producto a la lista
                    productos.add(new Producto(nombre, precio, cantidad)); 
                    System.out.println("Producto agregado exitosamente.");
                    System.out.println(); // Imprime espacio
                    }
                    
                    case 2 -> { // eliminar productos por nombre
                    String eliminar;
                        while (true) { //validamos eliminar, bucle infinito hasta que se ingresen los tipos de datos correctos
                            try { //validar entrada de datos
                            System.out.print("Ingrese el nombre del producto que quieres eliminar: ");
                            eliminar = sc.nextLine();
                            if (!eliminar.matches("[a-zA-Z ]+")) { // Valida que el nombre solo contenga letras
                            throw new IllegalArgumentException("Error!! El nombre solo puede tener letras."); //excepción si el nombre no es válido
                            }
                            break; //si no lanza excepcion, el nombre es valido, el bucle se acaba
                            } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage()); //Se muestra el mensaje de error
                            }
                        }

                        boolean encontrado = false; //bandera para encontrar el producto
    
                        for (int i = 0; i < productos.size(); i++) { //busca el producto
                            if (productos.get(i).getNombre().equalsIgnoreCase(eliminar)) {
                            Producto productoEliminado = productos.remove(i); //elimina el producto
                            System.out.println("Producto eliminado " + productoEliminado);
                            encontrado = true; //producto encontrado
                            break; //sale del bucle si encuentra el producto
                            }
                        }
    
                        if (!encontrado) {
                            System.out.println("No se encontró el producto para eliminar."); //mensaje de error
                        }
    
                        System.out.println(); //imprime espacio
                    }
                    
                    case 3 -> { //modificar productos
                        String nuevoNombre = ""; //declaracion de variables
                        double nuevoPrecio = 0;
                        String modificar = "";
                        int nuevaCantidad = 0;
                       
                        while (true){ //bucle para que el usuario escriba el nombre del producto hasta que ingrese tipo de dato correcto
                            try {
                                System.out.print("Ingrese el nombre del producto a modificar: ");
                                modificar = sc.nextLine(); //reasignamos valor con lo que ingrese el usuario
                                if (modificar.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                    break; //sale del bucle whie
                                } else {   
                                throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch con mensaje de error
                                }
                            } catch (InputMismatchException error) { //sino cacha el error
                              System.out.println(error.getMessage()); //imprime el mensaje de error
                            }
                        }
                        
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) { //busca el producto por su nombre
                            if (productos.get(i).getNombre().equalsIgnoreCase(modificar)) {
                                Producto productoModificar = productos.get(i);        
                          
                                while (true) { //bucle para que el usuario ingrese datos validos
                                    try {
                                        System.out.print("Ingrese el nuevo nombre: "); //modifica el nombre
                                        nuevoNombre = sc.nextLine(); //asigna nuevoNombre a lo que ingrese el usuario
                                        if (nuevoNombre.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                        break; //sale del bucle whie
                                        } else {   
                                            throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                            }
                                        } catch(InputMismatchException error){ //sino cacha el error e imprime mensaje
                                            System.out.println(error.getMessage()); //imprime el dato de error
                                    }
                                }
                                
                                while (!encontrado) { //definimos encontrado como false anteriormente. Este ciclo hace que se repita hasta que el usuario ingrese dato correcto
                                    try { //try catch para validar dato double
                                        System.out.print("Ingrese el nuevo precio: "); //modifica el precio
                                        nuevoPrecio = sc.nextDouble();
                                        encontrado = true; //si ingresa un dato correcto encontrado se establece en true, sale del bucle while y se deja de repetir
                                        } catch(InputMismatchException err) { //para detectar error de dato
                                        System.out.println("Dato incorrecto. Ingresa números únicamente");
                                        sc.next(); //limpia el buffer
                                    }
                                }
                                
                                while (!encontrado){ //bucle while se ejecuta mientras !encontrado, true    
                                    try { //try catch para validar dato double
                                        System.out.print("Ingrese la nueva cantidad: "); //modifica la cantidad
                                        nuevaCantidad = sc.nextInt();
                                        encontrado = true; //si ingresa un dato correcto sale del bucle while y se deja de repetir
                                    } catch(InputMismatchException err) { 
                                        System.out.println("Dato incorrecto. Ingresa números únicamente");
                                        sc.next(); //limpia el buffer
                                    }
                                }
                                
                                //actualiza el producto
                                productoModificar.setNombre(nuevoNombre);
                                productoModificar.setPrecio(nuevoPrecio);
                                productoModificar.setCantidad(nuevaCantidad);
                                System.out.println("Producto modificado: " + productoModificar);
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                            if (!encontrado) {
                                System.out.println("No se encontró el producto para modificar."); //mensaje de error
                            }
                        System.out.println();//imprime espacio
                    }
                      
                    case 4 -> { //buscar productos por nombre
                        String buscar = ""; //declaracion de variable  
                        while (true) { //ciclo while que se repite hasta que el usuario ingrese el dato correcto
                            try { //try catch para validar datos e imprimir mensaje de error
                                System.out.print("Ingrese el nombre del producto a buscar: ");
                                buscar = sc.nextLine();  //se reasigna el valor de la variable con lo que ingrese el usuario
                                if (buscar.matches("[a-zA-Z ]+")) { //si buscar contiene letras del abecedario
                                    break; //sale del bucle whie
                                } else {   
                                    throw new InputMismatchException("Dato incorrecto. El nombre solo puede contener letras. Vuelve a escribirlo"); //throw new, lanza una nueva exception de tipo Mismatch e imprime mensaje de error
                                } 
                            } catch (InputMismatchException error){ //toma el error de InputMismatchException
                            System.out.println(error.getMessage()); //imprime el mensaje de error
                            }
                        }
                        
                        boolean encontrado = false; //bandera para encontrar producto
                        for (int i = 0; i < productos.size(); i++) {
                            if (productos.get(i).getNombre().equalsIgnoreCase(buscar)) { //comparar el nombre
                                System.out.println("Producto encontrado en la posicion: " + (i + 1)); //muestra la posición
                                System.out.println("Detalles del producto: " + productos.get(i)); //muestra la info del producto
                                encontrado = true;
                                break; //sale del bucle si encuentra el producto
                            }
                        }
                        if (!encontrado) {
                            System.out.println("No se encontró el producto deseado.");
                        }
                        System.out.println();//imprime espacio
                      }
                      
                    case 5 -> { //mostrar todos los productos en el inventario
                        System.out.println("El numero de productos agregados es: " + productos.size());
                        for (int i = 0; i < productos.size(); i++) {
                            System.out.println((i + 1) + ". " + productos.get(i)); //muestra productos numerados
                        }
                        System.out.println();//imprime espacio
                      }
                      
                    case 6 -> //salir
                        System.out.println("Nos vemos, espero haya sido util :)");
                    default -> System.out.println("Opcion no valida, por favor intente de nuevo.");
                }
        }while(opcion !=6);
    }
}
