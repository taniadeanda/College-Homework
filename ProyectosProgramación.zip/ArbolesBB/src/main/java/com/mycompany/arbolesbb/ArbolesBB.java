package com.mycompany.arbolesbb;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class ArbolesBB {
   
    public ArbolesBB (){} //constructor vacio
    int Barbol; //bandera para arbol
    Nodo raiz; //es el objeto y N_padre es la direccion de memoria
    
    public void insertar (int valor){
        if(raiz == null){
            //System.out.println("Arbol vacio");
            raiz = new Nodo(null, null, null, valor); //crea el nuevo nodo, puntero izquierdo, puntero padre, puntero derecho y su valor
            //System.out.println("Raiz creada con "+valor);F
            JOptionPane.showMessageDialog(null, "Tu arbol estaba vacio y se ha creado la primera raiz con "+valor, null, JOptionPane.WARNING_MESSAGE);
        } 
        else {
            Nodo auxiliar = raiz;
            while(auxiliar != null){ //para recorrerlo
                if (valor <= auxiliar.valor){//condicion para evaluar la parte izquierda que siempre debe ser menor
                    if (auxiliar.izquierdo == null){ //si no tiene ningun nodo entonces crea uno en el lugar. Auxiliar en su parte izquierda...
                        auxiliar.izquierdo = new Nodo (null, auxiliar, null, valor); //raiz es auxiliar
                        //System.out.println("Nodo insertado en la izquierda");
                        JOptionPane.showMessageDialog(null, "Nodo insertado en la izquierda "+valor, null, JOptionPane.WARNING_MESSAGE);
                        break;
                    } else {
                        auxiliar = auxiliar.izquierdo; //si ya hay un nodo en su posicion, sigue bajando por la derecha ?????
                    }
                } else {//condicion para evaluar la parte derecha
                        if (auxiliar.derecho == null){ //si no tiene ningun nodo entonces crea uno en el lugar. Auxiliar en su parte derecha...
                        auxiliar.derecho = new Nodo (null, auxiliar, null, valor);
                        //System.out.println("Nodo insertado en la derecha");
                        JOptionPane.showMessageDialog(null, "Nodo insertado en la derecha "+valor, null, JOptionPane.WARNING_MESSAGE);
                        break;
                    } else {
                        auxiliar = auxiliar.derecho;
                    }
                }    
            }
        }
    }
    
    public void preorden (Nodo actual, JTextArea impresion){
        if(actual!=null){
            //System.out.println("Acomodo preorden {"+actual.valor+"} /n"); //diagonal INVERTIDA
            //JOptionPane.showMessageDialog(null, "Acomodo preorden {"+actual.valor+"} \n", null, JOptionPane.WARNING_MESSAGE);
            impresion.append("Acomodo preorden {" + actual.valor + "} \n");
            preorden(actual.izquierdo, impresion); //recursivo izquierdo, ya que imprime todo del izquierdo se va por la derecha
            preorden(actual.derecho, impresion); //recursivo derecha
        }
    }
   
    public void inorden (Nodo actual, JTextArea impresion){ //se va por la rama izquierda y llega a la penultima(1), luego se va por la izquierda
        if(actual!=null){
            inorden(actual.izquierdo, impresion);
            //System.out.println("Acomodo inorden {"+actual.valor+"} /n"); //diagonal INVERTIDA, actual es la raiz como quien dice
            //JOptionPane.showMessageDialog(null, "Acomodo inorden {"+actual.valor+"} \n", null, JOptionPane.WARNING_MESSAGE);
            impresion.append("Acomodo inorden {" + actual.valor + "} \n");
            inorden(actual.derecho, impresion);
        }
    }
    
    public void postorden (Nodo actual, JTextArea impresion){ //EDITAR
        if(actual!=null){
            postorden(actual.izquierdo, impresion); 
            postorden(actual.derecho, impresion);        
            //System.out.println("Acomodo postorden {"+actual.valor+"} \n"); //diagonal INVERTIDA, actual es la raiz como quien dice
            //JOptionPane.showMessageDialog(null, "Acomodo postorden {"+actual.valor+"} \n", null, JOptionPane.WARNING_MESSAGE);
            impresion.append("Acomodo postorden {" + actual.valor + "} \n");
        }
    }
    
    void Eliminar(int valor){
        if(raiz == null){
            JOptionPane.showMessageDialog(null, "Arbol vacío, no hay datos para buscar", null, JOptionPane.WARNING_MESSAGE);//imprime arbol vacio
        } else {
        Nodo auxiliar = raiz; 
        Nodo padre = null;
        boolean HijoIzdo = true;
        while (auxiliar!=null && auxiliar.valor != valor){
            padre = auxiliar;
            if(valor<auxiliar.valor){
            auxiliar = auxiliar.derecho;
            HijoIzdo = false;
            }
        }
        //casos para buscar el valor
        //cuando no se encuentra
        if(auxiliar == null){
        JOptionPane.showMessageDialog(null, "No se encontró tu nodo", null, JOptionPane.WARNING_MESSAGE);//imprime que no se encuentra 
        Barbol = 1; //se declara entero en geters y setters
        }
        //no tiene hijos
        if (auxiliar.izquierdo == null && auxiliar.derecho== null){
                Barbol = 2;
                if(auxiliar == raiz){
                raiz = null;
                }else if (HijoIzdo){
                padre.izquierdo=null;
                }else{
                padre.derecho= null;
            }
        JOptionPane.showMessageDialog(null, "Ya se elimino tu nodo sin hijos", null, JOptionPane.WARNING_MESSAGE);//imprime que no se encuentra 
        //con 1 hijo
        } else if (auxiliar.izquierdo == null){
            Barbol = 2;
            if (HijoIzdo){ //si tiene hijo izquierdo
                padre.izquierdo=auxiliar.derecho;
            }else {
                padre.derecho=auxiliar.derecho;
            }
            
        } else if (auxiliar.derecho == null){
            Barbol=2;
            if(HijoIzdo){
                padre.izquierdo = auxiliar.izquierdo;
            } else {
                padre.derecho = auxiliar.izquierdo;
            }
        JOptionPane.showMessageDialog(null, "Ya se elimino tu nodo con 1 hijo", null, JOptionPane.WARNING_MESSAGE);//imprime que no se encuentra 
        //Nodo con dos hijos
        }
        else{
           Barbol = 2;
           eliminarSucesor(auxiliar, padre);
           JOptionPane.showMessageDialog(null, "Ya se elimino tu nodo con 2 hijos", null, JOptionPane.WARNING_MESSAGE);//imprime que no se encuentra 
        }
        }
    }
    
    
    public int validarDato(String inputUsuario){
        try {
            int DatosUsuario = Integer.parseInt(inputUsuario); //lo convierte a entero
            //System.out.println("Número válido: " + DatosUsuario);
            return DatosUsuario;
        } catch (NumberFormatException e) { //sino dice que no es valido
        JOptionPane.showMessageDialog(null, "Escribe un tipo de dato numérico válido", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return -1;
        }
    }
    
    private void eliminarSucesor(Nodo auxiliar, Nodo padre){ //cuando se elimina un nodo se reemplaza por su nodo menor derecho y el izquierdo se queda como su hijo izqdo
    //buscar el nodo con el valor mas grande en el subarbo izquierdo
        Nodo sucesorPadre = auxiliar;
        Nodo sucesor = auxiliar.izquierdo;
        while(sucesor.derecho!= null){ //primero buscar por la parte derecha
            sucesorPadre = sucesor;
            sucesor = sucesor.derecho; 
        }
        auxiliar.valor = sucesor.valor; //remplaza el valor del nodo con el valor del sucesor
        if(sucesorPadre == auxiliar){
            sucesorPadre.izquierdo = sucesor.izquierdo;
        } else{
            sucesorPadre.derecho = sucesor.izquierdo;
        }
    }
    
    public static void main(String[] args) {
        ArbolesBB x = new ArbolesBB();
        //postorden y = new postorden();
        //inorden z = new inorden();

        new Diseño().setVisible(true);
        /*x.insertar(23);
        x.insertar(12);
        x.insertar(33);
        x.preorden(x.raiz);
        x.inorden(x.raiz);
        */
    }
    
}
