package com.mycompany.arbolesbb;

public class Nodo {
    Nodo izquierdo = null;
    Nodo N_padre = null;
    Nodo derecho = null;
    int valor; 
    
    public Nodo(Nodo izquierdo, Nodo N_Padre, Nodo derecho, int valor) {
        this.izquierdo = null;
        this.N_padre = null;
        this.derecho = null;
        this.valor = valor;
        //this.Barbol = 
    }
    
    public Nodo getIzquierdo() {
        return izquierdo;
    }

    public void setIzquierdo(Nodo izquierdo) {
        this.izquierdo = izquierdo;
    }

    public Nodo getN_padre() {
        return N_padre;
    }

    public void setN_padre(Nodo N_padre) {
        this.N_padre = N_padre;
    }

    public Nodo getDerecho() {
        return derecho;
    }

    public void setDerecho(Nodo derecho) {
        this.derecho = derecho;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

}
