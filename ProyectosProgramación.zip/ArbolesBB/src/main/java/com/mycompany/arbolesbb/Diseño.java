package com.mycompany.arbolesbb;

public class Diseño extends javax.swing.JFrame {
    //int NodosUsuario;
    private ArbolesBB x;

    public Diseño() {
        initComponents();
        x = new ArbolesBB(); // Inicializar la instancia de ArbolesBB
        //impresion = new JTextArea(); // Inicializar el JTextArea
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Preorden = new javax.swing.JButton();
        Inorden = new javax.swing.JButton();
        Postorden = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        NodosdelUsuario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Insertar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        impresion = new javax.swing.JTextArea();
        Eliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 255));

        Preorden.setText("Pre-orden");
        Preorden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreordenActionPerformed(evt);
            }
        });

        Inorden.setText("In-orden");
        Inorden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InordenActionPerformed(evt);
            }
        });

        Postorden.setText("Post-orden");
        Postorden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PostordenActionPerformed(evt);
            }
        });

        jLabel1.setText("Elige el tipo de recorrido para tu árbol");

        NodosdelUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NodosdelUsuarioActionPerformed(evt);
            }
        });

        jLabel2.setText("Escribe aquí tu nodo");

        Insertar.setText("Insertar");
        Insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertarActionPerformed(evt);
            }
        });

        impresion.setColumns(20);
        impresion.setRows(5);
        jScrollPane1.setViewportView(impresion);

        Eliminar.setText("Eliminar");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(49, 49, 49))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(Preorden)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Inorden, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(NodosdelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Insertar, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Postorden, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NodosdelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Insertar)
                    .addComponent(Eliminar))
                .addGap(34, 34, 34)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Preorden)
                    .addComponent(Inorden)
                    .addComponent(Postorden))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NodosdelUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NodosdelUsuarioActionPerformed
        String DatosUsuario = NodosdelUsuario.getText(); //guardar lo que el usuario ingrese en la variable NodosUsuario en string y convertirlo a entero
        x.validarDato(DatosUsuario);//validar para que solo ingrese datos int
    }//GEN-LAST:event_NodosdelUsuarioActionPerformed

    private void PreordenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreordenActionPerformed
        //x.preorden(x.raiz, impresion);
        impresion.setText(""); // Limpia el JTextArea antes de mostrar el recorrido
        x.preorden(x.raiz, impresion); // Llama al método preorden y pasa el JTextArea
    }//GEN-LAST:event_PreordenActionPerformed

    private void InsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertarActionPerformed
        String DatosUsuario = NodosdelUsuario.getText(); //guardar lo que el usuario ingrese en la variable NodosUsuario en string
        x.validarDato(DatosUsuario);
        int NodosUsuario = Integer.parseInt(NodosdelUsuario.getText()); //.parseInt; //guardar lo que el usuario ingrese en la variable NodosUsuario en string y convertirlo a entero
        x.insertar(NodosUsuario); // TODO add your handling code here:
    }//GEN-LAST:event_InsertarActionPerformed

    private void InordenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InordenActionPerformed
        impresion.setText(""); // Limpia el JTextArea antes de mostrar el recorrido
        x.inorden(x.raiz, impresion);
    }//GEN-LAST:event_InordenActionPerformed

    private void PostordenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PostordenActionPerformed
        impresion.setText(""); // Limpia el JTextArea antes de mostrar el recorrido
        x.postorden(x.raiz, impresion); // TODO add your handling code here:
    }//GEN-LAST:event_PostordenActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        String DatosUsuario = NodosdelUsuario.getText(); //guardar lo que el usuario ingrese en la variable NodosUsuario en string
        x.validarDato(DatosUsuario);
        int NodosUsuario = Integer.parseInt(NodosdelUsuario.getText()); //guardar lo que el usuario ingrese en la variable NodosUsuario en string y convertirlo a entero
        x.Eliminar(NodosUsuario);// 
    }//GEN-LAST:event_EliminarActionPerformed

    public static void main(String args[]) {
        //ArbolesBB x = new ArbolesBB();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Diseño().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton Inorden;
    private javax.swing.JButton Insertar;
    private javax.swing.JTextField NodosdelUsuario;
    private javax.swing.JButton Postorden;
    private javax.swing.JButton Preorden;
    private javax.swing.JTextArea impresion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
