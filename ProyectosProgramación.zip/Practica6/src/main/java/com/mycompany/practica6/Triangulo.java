package com.mycompany.practica6;
//import java.util.Scanner;
import javax.swing.JOptionPane;

public class Triangulo extends Figura { //clase hija de la clase padre Figura
    //Scanner sc = new Scanner(System.in); //se crea una instancia para leer
    private int altura;
    
    public Triangulo(String nombre, double area, double perimetro, int lado, int altura) { //constructor de la clase figura
        super(nombre, area, perimetro, lado);
        this.altura = altura; //declarar la nueva variable altura
    } //SETTERS Y GETTERS PARA ALTURA???

    @Override //se deben immplementar metodos de la clase padre también
    protected void calcularArea() {
        /*System.out.println("Calcular área de triangulo equilátero. A continuación escribe la medida de la base del triángulo");
        lado = sc.nextInt(); //lee el lado ingresado por el usuario
        System.out.println("A continuación escribe la altura del triángulo");
        altura = sc.nextInt();
        System.out.println("Area = "+((altura*lado)/2)); //operacion para el area
        */
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la base del triángulo", "Calcular área de triangulo",0)); //ventana de dialogo Input, devuelve string
        altura = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la altura del triángulo", "Calcular área del triangulo",0)); //ventana de dialogo Input, devuelve string
        area = ((altura*lado)/2);
        JOptionPane.showMessageDialog(null,"El area de tu triangulo es "+area, "Area Triangulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }

    @Override
    protected void calcularPerimetro() {
        /*System.out.println("Calcular perimetro del triangulo. A continuación escribe la medida de uno de los lados");
        lado = sc.nextInt();
        System.out.println("Perimetro = "+lado*3);*/
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de uno de los lados del triángulo", "Calcular perimetro del triangulo",0)); //ventana de dialogo Input, devuelve string
        perimetro = lado*3;
        JOptionPane.showMessageDialog(null,"El perimetro de tu triangulo es "+perimetro, "Perjimetro Triangulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }
    
    
}
