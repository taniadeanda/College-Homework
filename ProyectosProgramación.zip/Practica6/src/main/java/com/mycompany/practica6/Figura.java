package com.mycompany.practica6;
//polimorfismo lo podemos entender como un metodo que puede comportarse de diferente manera dependiendo del objeto

public abstract class Figura { 

    public Figura(String nombre, double area, double perimetro, int lado) { //constructor
        this.nombre = nombre;
        this.area = area;
        this.perimetro = perimetro;
        this.lado = lado;
    }
//como hay metodos abstractos se tiene que hacer la clase abstracta
    protected String nombre;
    protected double area;
    protected double perimetro;
    protected int lado;
    protected abstract void calcularArea(); //metodos sin cuerpo, el cuerpo se declara en cada clase hija dependiendo de lo que se necesite
    protected abstract void calcularPerimetro(); //clase abstracta es la base para las otras clases, es algo general. No se instancian objetos. Se instancian objetos con las clases hijos solamente (estos son especificos)
    //diferencia entre polimorfismo y clase abstracta
    //poliformismo es la capacidad de un objeto para tomar muchas diferentes funciones y comportarse diferente
    //clases abstractas definen una estructura que debe ser seguida por clases derivadas. No abren llaves, no se declara comportamiento, los hijos son los que le declaran la implementacion. NO SE USA NEW. Puede tener metodos abstractos o no abstractos. Se usa metodo estatido o abstracto, no ambos.
    //@Override indica el codigo que se esta reescribiendo, que se esta redefiniendo un metodo de la clase padre en la clase hijo. Se pone automatico cuando escribimos super
    //sobrecarga de constructores cuando en una clase tenrmos 2 contructores iguales con diferentes parametros.
    //super() para mandar a llamar el constructor de la super clase (clase padre)
    //sobrecarga de metodos, similar. Las clases hijos van heredando metodos de la clase padre con la palabra super.NombreMetodo. Se distingue con la palabra super.nombreDelMetodo, hace referencia a al metodo de la clase padre
    //para generar polimorfismo debe haber sobrecarga de metodos y clases abstractas
    
//Implementacion de getters y setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    public void setLado(int lado) {
        this.lado = lado;
    }

    public String getNombre() {
        return nombre;
    }

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public int getLado() {
        return lado;
    }

}