package com.mycompany.practica6;
//import java.util.Scanner;
import javax.swing.JOptionPane;

public class Circulo extends Figura {
    //Scanner sc = new Scanner(System.in); //se crea una instancia para leer

    public Circulo(String nombre, double area, double perimetro, int lado) { //constructor de la clase figura
        super(nombre, area, perimetro, lado);
    }

    @Override //se deben immplementar metodos de la clase padre también
    protected void calcularArea() {
        /*System.out.println("Calcular área de circulo. A continuación escribe la medida del radio");
        lado = sc.nextInt(); //lee el lado ingresado por el usuario
        System.out.println("Area = "+(3.1416*(lado*lado))); //operacion para el area
        */
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida del radio del circulo", "Calcular área del circulo",0)); //ventana de dialogo Input, devuelve string
        area = (3.1416*(lado*lado));
        JOptionPane.showMessageDialog(null,"El area de tu circulo es "+area, "Area Circulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }

    @Override
    protected void calcularPerimetro() {
        /*System.out.println("Calcular perímetro de cuadrado. A continuación escribe la medida de uno de los lados");
        lado = sc.nextInt();
        System.out.println("Perimetro = "+(2*(3.1416*lado)));
    }
    */
    lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida del radio", "Calcular área del circulo",0)); //ventana de dialogo Input, devuelve string
    perimetro = (2*(3.1416*(lado)));
    JOptionPane.showMessageDialog(null,"El perimetro de tu circulo es "+perimetro, "Perimetro Circulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }
    
}
