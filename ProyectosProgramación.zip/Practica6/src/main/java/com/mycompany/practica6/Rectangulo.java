package com.mycompany.practica6;
//import java.util.Scanner;
import javax.swing.JOptionPane;

public class Rectangulo extends Figura {
    //Scanner sc = new Scanner(System.in); //se crea una instancia para leer
    private int base; //declarar otra variable base
    
    public Rectangulo(String nombre, double area, double perimetro, int lado, int base) { //constructor de la clase figura
        super(nombre, area, perimetro, lado);
        this.base = base; //declarar el constructor agregando la nueva variable
    }

    //agregar getters y setters para base
    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }
    
    @Override //se deben immplementar metodos de la clase padre también
    protected void calcularArea() {
        /*System.out.println("Calcular área de rectángulo. A continuación escribe la medida de la base");
        base = sc.nextInt(); //lee el lado ingresado por el usuario
        System.out.println("A continuación escribe la medida de la altura");
        lado = sc.nextInt();
        System.out.println("Area = "+lado*base); //operacion para el area
        */
        base = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la base del rectangulo", "Calcular área de rectangulo",0)); //ventana de dialogo Input, devuelve string
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la altura del rectangulo", "Calcular área del rectangulo",0)); //ventana de dialogo Input, devuelve string
        area = (base*lado);
        JOptionPane.showMessageDialog(null,"El area de tu rectangulo es "+area, "Area Rectangulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }
    
    @Override
    protected void calcularPerimetro() {
        /*System.out.println("Calcular perímetro de rectángulo. A continuación escribe la medida de la base");
        base = sc.nextInt();
        System.out.println("A continuación escribe la medida de la altura");
        lado = sc.nextInt();
        System.out.println("Perimetro = "+((lado*2)+(base*2)));*/
        base = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la base del rectangulo", "Calcular área de rectangulo",0)); //ventana de dialogo Input, devuelve string
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de la altura del rectangulo", "Calcular área del rectangulo",0)); //ventana de dialogo Input, devuelve string
        perimetro = ((base*2)+(lado*2));
        JOptionPane.showMessageDialog(null,"El perimetro de tu rectangulo es "+perimetro, "Perimetro rectangulo", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }
    
}
