package com.mycompany.practica6;
//import static com.mycompany.practica6.Practica6.option;
//import java.util.Scanner;
import javax.swing.JOptionPane;

public class Cuadrado extends Figura { //clase hijo de clase Figura
    //Scanner sc = new Scanner(System.in); //se crea una instancia para leer

    public Cuadrado(String nombre, double area, double perimetro, int lado) { //constructor de la clase
        super(nombre, area, perimetro, lado); //super porque es de la clase padre
    }

    @Override //se deben immplementar metodos de la clase padre también
    protected void calcularArea() {
        //System.out.println("Calcular área de cuadrado. A continuación escribe la medida de uno de los lados");
        //lado = sc.nextInt(); //lee el lado ingresado por el usuario
        //System.out.println("Area = "+lado*lado); //operacion para el area
        //lado ya esta declarado en la clase padre figura aqui solo se asigna nuevamente
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de uno de los lados", "Calcular área de cuadrado",0)); //ventana de dialogo Input, devuelve string
        area = lado*lado;
        JOptionPane.showMessageDialog(null,"El area de tu cuadrado es "+area, "Area Cuadrado", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }

    @Override
    protected void calcularPerimetro() {
        //System.out.println("Calcular perímetro de cuadrado. A continuación escribe la medida de uno de los lados");
        //lado = sc.nextInt();
        //System.out.println("Perimetro = "+lado*4);
        lado = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuación escribe la medida de uno de los lados", "Calcular área de cuadrado",0)); //ventana de dialogo Input, devuelve string
        perimetro = lado*4;
        JOptionPane.showMessageDialog(null,"El perimetro de tu cuadrado es "+perimetro, "Perímetro Cuadrado", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    
    }
    
}
