package com.mycompany.practica6;
//import java.util.Scanner;
//import javax.swing.ImageIcon; para ventana de texto con imagen
import javax.swing.JOptionPane; //libreria para ventanas emergentes

public class Practica6 { //hacer todo con ventanas
    static int option;
    public static void main(String[] args) {
        //option = Integer.parseInt(JOptionPane.showInputDialog(null, "Bienvenido a la calculadora de areas y perimetros de figuras. A continuacion escribe la opcion de tu preferencia: \n1.Cuadrado \n2.Rectángulo \n3.Triángulo \n4.Circulo \n5.Salir", "",0)); //ventana de dialogo Input, devuelve string
        //Integer.parseInt para convertir int a string
        JOptionPane.showMessageDialog(null, "Bienvenidos al programa del Polimorfismo", "Inicio", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
        //JOptionPane.showMessageDialog(null, "Bienvenidos al programa del Polimorfismo", "Inicio", 0, new ImageIcon("C:\Users\Yes\Pictures")); //investigar que icono tiene cada num, 1 es el ícono aquí
        //Scanner sc = new Scanner(System.in); //se crea una instancia para leer
        do { //hacer menu en ventana 
            //System.out.println("Bienvenido a la calculadora de areas y perimetros de figuras. A continuacion escribe la opcion de tu preferencia: \n1.Cuadrado \n2.Rectángulo \n3.Triángulo \n4.Circulo \n5.Salir");
            //option = sc.nextInt(); //lee opcion del usuario
            //sc.nextLine(); //limpieza de buffer
            //cambiamos menu anterior por este de option para que sea con ventana
            option = Integer.parseInt(JOptionPane.showInputDialog(null, "A continuacion escribe la opcion de tu preferencia: \n1.Cuadrado \n2.Rectángulo \n3.Triángulo \n4.Circulo \n5.Salir", "Bienvenido a la calculadora de areas y perimetros de figuras",0)); //ventana de dialogo Input, devuelve string
            switch(option){
                case 1 -> {//Cuadrado
                    Cuadrado cuadrado = new Cuadrado("Cuadrado", 0, 0, 0); //instanciar cuadrado con sus atributos vacios
                    option = Integer.parseInt(JOptionPane.showInputDialog(null, "Escribe 1 para calcular su área y 2 para su perímetro", "Has seleccionado cuadrado",0)); //ventana de dialogo Input, devuelve string
                    //System.out.println("Has seleccionado cuadrado. Escribe 1 para calcular su área y 2 para su perímetro");
                    //option = sc.nextInt(); //lee opcion del usuario
                    //sc.nextLine(); //limpieza de buffer                  
                    switch(option){
                        case 1 -> {//calcular area cuadrado
                            cuadrado.calcularArea(); //mandar a llamar cuadrado para hacer area y perimetro???????
                            break; 
                        }
                        
                        case 2 -> { //calcular perimetro cuadrado
                            cuadrado.calcularPerimetro();
                            break;
                    }
                                                        
                        //default -> System.out.println("Opción incorrecta. Escribe 1 o 2.");
                        default -> JOptionPane.showMessageDialog(null, "Escribe 1 o 2.", "Opción incorrecta", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
                    }
                }
                
                case 2 -> { //rectangulo
                    Rectangulo rectangulo = new Rectangulo("Rectangulo", 0, 0, 0, 0); //instanciar rectangulo con sus atributos vacios
                    /*System.out.println("Has seleccionado rectángulo. Escribe 1 para calcular su área y 2 para su perímetro");
                    option = sc.nextInt(); //lee opcion del usuario
                    sc.nextLine(); //limpieza de buffer*/
                    option = Integer.parseInt(JOptionPane.showInputDialog(null, "Escribe 1 para calcular su área y 2 para su perímetro", "Has seleccionado rectangulo",0)); //ventana de dialogo Input, devuelve string
                    switch(option){
                        case 1 -> {//calcular area 
                            rectangulo.calcularArea(); //mandar a llamar para hacer area
                            break; 
                        }
                        
                        case 2 -> { //calcular perimetro 
                            rectangulo.calcularPerimetro();
                            break;
                    }
                                                        
                        //default -> System.out.println("Opción incorrecta. Escribe 1 o 2.");
                        default -> JOptionPane.showMessageDialog(null, "Escribe 1 o 2.", "Opción incorrecta", 1); //investigar que icono tiene cada num, 1 es el ícono aquí

                    }
                    
                }
                
                case 3 -> { //triangulo 
                    Triangulo triangulo = new Triangulo("Triangulo", 0, 0, 0, 0); //instanciar triangulo con sus atributos
                    /*System.out.println("Has seleccionado triángulo. Escribe 1 para calcular su área y 2 para su perímetro");
                    option = sc.nextInt(); //lee opcion del usuario
                    sc.nextLine(); //limpieza de buffer*/
                    option = Integer.parseInt(JOptionPane.showInputDialog(null, "Escribe 1 para calcular su área y 2 para su perímetro", "Has seleccionado triangulo",0)); //ventana de dialogo Input, devuelve string
                    switch(option){
                        case 1 -> {//calcular area 
                            triangulo.calcularArea(); //mandar a llamar cuadrado para hacer area
                            break; 
                        }
                        
                        case 2 -> { //calcular perimetro 
                            triangulo.calcularPerimetro();
                            break;
                    }
                                                        
                        //default -> System.out.println("Opción incorrecta. Escribe 1 o 2.");
                        default -> JOptionPane.showMessageDialog(null, "Escribe 1 o 2.", "Opción incorrecta", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
                    }
                }
                
                case 4 -> { //circulo
                    Circulo circulo = new Circulo("Circulo",0,0,0); //instanciacion de circulo con atributos vacios
                    /*System.out.println("Has seleccionado círculo. Escribe 1 para calcular su área y 2 para su perímetro");
                    option = sc.nextInt(); //lee opcion del usuario
                    sc.nextLine(); //limpieza de buffer*/
                    option = Integer.parseInt(JOptionPane.showInputDialog(null, "Escribe 1 para calcular su área y 2 para su perímetro", "Has seleccionado circulo",0)); //ventana de dialogo Input, devuelve string
                    switch(option){
                        case 1 -> {//calcular area 
                            circulo.calcularArea();
                            break; 
                        }
                        
                        case 2 -> { //calcular perimetro
                            circulo.calcularPerimetro();
                            break;
                    }
                                                        
                        //default -> {System.out.println("Opción incorrecta. Escribe 1 o 2.");}
                        default -> JOptionPane.showMessageDialog(null, "Escribe 1 o 2.", "Opción incorrecta", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
                    }
                }
                
                /*default -> {
                    JOptionPane.showMessageDialog(null, "Escribe 1 o 2.", "Opción incorrecta", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
                    //System.out.println("Opción incorrecta. Escribe una opción del menú 1 - 5");
                }*/
            }
        }while(option !=5);
        //System.out.println("Gracias por usar el programa. ¡Hasta pronto!");
        JOptionPane.showMessageDialog(null, "¡Hasta pronto!", "Gracias por usar el programa", 1); //investigar que icono tiene cada num, 1 es el ícono aquí
    }
}
